import type { ApiResponse } from '~/models/ApiResponseDTO'
import type { ProjectDTO, ProjectListDTO } from '~/models/Project/ProjectDTO'
import { FetchX } from '~/utilities/fetchX'

export const getMyProjectsService = (page = 1): Promise<ApiResponse<ProjectListDTO>> => {
  return FetchX('project/', {
    method: 'get',
    query: { page },
  })
}

export const createProjectService = (data: FormData): Promise<ApiResponse<ProjectDTO>> => {
  return FetchX('project/', {
    method: 'post',
    body: data,
  })
}

export const retrieveProjectService = (slug: string): Promise<ApiResponse<ProjectDTO>> => {
  return FetchX(`project/${slug}/`, {
    method: 'get',
  })
}

export const updateProjectService = (slug: string, data: FormData): Promise<ApiResponse<ProjectDTO>> => {
  return FetchX(`project/${slug}/`, {
    method: 'patch',
    body: data,
  })
}

export const deleteProjectService = (slug: string): Promise<ApiResponse<null>> => {
  return FetchX(`project/${slug}/`, {
    method: 'delete',
  })
}

export const getPublicProjectsService=(page=1)=>FetchX('project/projects/public/',{method:'get',query:{page}})
export const likeProjectService=(slug:string)=>FetchX(`project/${slug}/like/`,{method:'post'})
export const commentProjectService=(projectId:number,data:any)=>FetchX(`project/${projectId}/comments/`,{method:'post',body:data})
