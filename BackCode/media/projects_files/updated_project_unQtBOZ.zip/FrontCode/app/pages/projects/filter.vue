<template>
  <div class="grid grid-cols-1 min-h-screen lg:grid-cols-3 gap-8 py-8 lg:py-24">
    

    <div class="space-y-5">

  
<ProjectFiltersBoxResult :tog :filters="filters" :toggleTechnology=toggleTechnology 
:resetSearch="resetSearch" :toggle-category :toggleYears></ProjectFiltersBoxResult>

<ProjectFiltersTechnology :filters="filters" :toggleTechnology=toggleTechnology></ProjectFiltersTechnology>

<ProjectFiltersYears :filters :toggleYears="toggleYears"></ProjectFiltersYears>

  <ProjectFiltersSearch :filters="filters" :apply-filter="applyFilter"></ProjectFiltersSearch>

<ProjectFiltersCategory :filters :toggle-category></ProjectFiltersCategory>


      <div class="text-left">
        <ui-button w-full>فیلترکردن نتایج</ui-button>
      </div>
    </div>

    <div class="lg:col-span-2">
      <div class="flex flex-col space-y-0">
        
        <ProjectFiltersSort :filters></ProjectFiltersSort>
        <ProjectContainer lg-grid="2" min="true" />
        <UiPagination :totalPages="6" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { useProjectFilters } from '~/composable/useProjectFilters'
import { generateSeoMeta } from '~/utilities/seo'


const {filters,applyFilter,resetSearch,toggleTechnology,toggleYears,toggleCategory}=useProjectFilters()
const seo = generateSeoMeta({
      title: `فیلترکردن پروژه‌ها`,
      description: 'در ایند',
      image: "",
      url: ``,
      keywords: ["افزودن پروژه"],
      author:"علیرضا کشاورز",
      type: 'website'
    })
    useHead(seo)



</script>
