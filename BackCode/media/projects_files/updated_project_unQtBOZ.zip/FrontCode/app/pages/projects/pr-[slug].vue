<template>

<div class="container mx-auto px-4 py-10">

  <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">

    <main class="space-y-6 lg:col-span-2">

      <div class="backdrop-blur-md shadow-2xl bg-carb-gray/10 hover:shadow-classic-gold/30  border-white/10  transition hover:border-light-gold border-2  rounded-2xl overflow-hidden">
        <img src="/images/project-1.jpg" class="w-full h-[420px]  object-cover"/>
      </div>

     <ProjectDetailBox></ProjectDetailBox>

    <ProjectDescriptionBox></ProjectDescriptionBox>
    <ProjectShareLikeBox></ProjectShareLikeBox>

  <div class="space-y-8">

  <ProjectSendComment></ProjectSendComment>

<ProjectCommentItem></ProjectCommentItem>
  
  </div>



    </main>

    <aside class="space-y-6 lg:col-span-1">

    <ProjectAuthorBox></ProjectAuthorBox>

    <ProjectDownloadBox></ProjectDownloadBox>

    <ProjectSkillBox></ProjectSkillBox>

     

    </aside>

  </div>

</div>

</template>

<script setup lang="ts">
import { generateSeoMeta } from '~/utilities/seo'

const liked = ref(false)
const showReply = ref(false)

const seo = generateSeoMeta({
      title: `پروژه علیرضا`,
      description: 'در ایند',
      image: "",
      url: ``,
      keywords: ["افزودن پروژه"],
      author:"علیرضا کشاورز",
      type: 'website'
    })
    useHead(seo)
</script>
