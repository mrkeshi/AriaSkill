<template>
<SectionsHero/><SectionsHowWork/>
<section class='py-10'><div class='flex items-center justify-between mb-6'><h2>پروژه‌ها</h2></div>
<div class='grid gap-4'><div v-for='p in projects' :key='p.id'>{{ p.title }}</div></div>
</section></template>
<script setup lang='ts'>
import {getPublicProjectsService} from '~/services/projects/project.Service'
const {data}=await useAsyncData('home-projects',()=>getPublicProjectsService())
const projects=computed(()=>data.value?.results?.slice(0,6) || data.value?.data?.results?.slice(0,6) || [])
</script>