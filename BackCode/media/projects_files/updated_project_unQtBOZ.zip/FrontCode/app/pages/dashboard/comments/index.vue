<template>
  <UiCardBlury>
  <div class=" transition-all">

    <div class="flex items-center justify-between mb-6">
      <h2 class="text-xl font-bold text-white tracking-wide">مدیریت نظرات</h2>
      <span class="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-3 py-1 rounded-full text-xs">
        {{ comments.length }} نظر جدید
      </span>
    </div>

    <div class="overflow-x-auto rounded-xl border border-white/10 bg-white/5 backdrop-blur-md shadow-inner">
      <table class="w-full text-right whitespace-nowrap">
        
        <thead class="bg-white/5 text-gray-300 text-sm border-b border-white/10">
          <tr>
            <th class="p-4 font-medium">#</th>
            <th class="p-4 font-medium">کاربر</th>
            <th class="p-4 font-medium">پروژه</th>
            <th class="p-4 font-medium">تاریخ</th>
            <th class="p-4 font-medium">پیام</th>
            <th class="p-4 font-medium">عملیات</th>
          </tr>
        </thead>
              <SendCommentModal
  v-model="showReplyModal"
  author="علیرضا"
  comment="این مقاله خیلی عالی بود"
  on-submit="alert(hi)"
/>

        <tbody class="text-gray-200 text-sm divide-y divide-white/5">
          <tr
            v-for="item in comments"
            :key="item.id"
            class="hover:bg-white/5 transition duration-200 group"
          >
            <td class="p-4 text-gray-500 group-hover:text-gray-400 transition">{{ item.id }}</td>

            
            <td class="p-4">

              <div class="flex items-center gap-3">
                <div class="relative">
                  <img :src="item.avatar" class="w-10 h-10 rounded-full object-cover border border-white/20 shadow-lg"/>
                  <span class="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full border border-slate-900"></span>
                </div>
                <div class="flex flex-col">
                <span class="font-medium">{{ item.name }}</span>
               <span class=" text-orange-500 text-[12px] ">@Paressep28</span>

                </div>
              </div>
            </td>

            <td class="p-4">
              <span class="px-3 py-1.5 text-xs rounded-lg bg-classic-gold/10 text-classic-gold border border-purple-500/20">
                {{ item.project }}
              </span>
            </td>

            <td class="p-4 text-gray-400 text-xs">
              {{ item.date }}
            </td>

            <td class="p-4 text-gray-300 max-w-xs truncate" :title="item.message">
              {{ item.message }}
            </td>

            <td class="p-4">
              <div class="flex gap-2">
                
                <!-- View -->
                <button title="مشاهده" class="bg-white/5 hover:bg-white/10 border border-white/10 
                p-2 rounded-lg shadow-sm flex items-center justify-center text-gray-300 hover:text-white transition">
                  <Icon name="mdi:eye" class="text-lg"/>
                </button>

                <!-- Reply -->
                <button @click="showReplyModal=!showReplyModal" title="پاسخ" class="bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/30 
                p-2 rounded-lg shadow-sm flex items-center justify-center text-blue-400 hover:text-blue-300 transition">
                  <Icon name="mdi:reply" class="text-lg"/>
                </button>

                <!-- Approve -->
                <button title="تایید" class="bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 
                p-2 rounded-lg shadow-sm flex items-center justify-center text-emerald-400 hover:text-emerald-300 transition">
                  <Icon name="mdi:check" class="text-lg"/>
                </button>

              </div>
            </td>

          </tr>
        </tbody>
      </table>
    </div>

    <!-- pagination -->
    <div class="mt-6 flex justify-center">
      <UiPagination :totalPages="6" />
    </div>

  </div>
  </UiCardBlury>
</template>

<script setup>
import { generateSeoMeta } from '~/utilities/seo'


const seo = generateSeoMeta({
      title: `نظرات دریافتی`,
      description: 'در ایند',
      image: "",
      url: ``,
      keywords: ["افزودن پروژه"],
      author:"علیرضا کشاورز",
      type: 'website'
    })
    useHead(seo)
const showReplyModal=ref(false)

watch(showReplyModal, (val) => {
  if (val) {
    console.log('مودال باز شد')
  }
})
definePageMeta({
  layout: 'dashboard'
})

const comments = [
  {
    id: 1,
    name: "محمد رضایی",
    avatar: "/images/user1.jpg",
    project: "پروژه سلام زندگی",
    date: "۱۴۰۲/۰۸/۱۲",
    message: "طراحی خیلی عالی بود، ممنون از زحمات شما."
  },
  {
    id: 2,
    name: "الهام محمودی",
    avatar: "/images/user1.jpg",
    project: "اپلیکیشن فروشگاهی",
    date: "۱۴۰۲/۰۸/۱۱",
    message: "جای بعضی امکانات خالیه ولی در کل خوبه."
  },
  {
    id: 3,
    name: "مهدی صالحی",
    avatar: "/images/user1.jpg",
    project: "سیستم مدیریت محتوا",
    date: "۱۴۰۲/۰۸/۱۰",
    message: "لطفا نسخه موبایل رو هم بهبود بدید."
  },
  {
    id: 4,
    name: "نرگس کریمی",
    avatar: "/images/user1.jpg",
    project: "پنل مدیریت",
    date: "۱۴۰۲/۰۸/۰۹",
    message: "رابط کاربری خیلی تمیز طراحی شده."
  },
  {
    id: 5,
    name: "علی احمدی",
    avatar: "/images/user1.jpg",
    project: "پروژه سلام زندگی",
    date: "۱۴۰۲/۰۸/۰۸",
    message: "آیا امکان دانلود سورس وجود دارد؟"
  },
  {
    id: 6,
    name: "حسین مرادی",
    avatar: "/images/user1.jpg",
    project: "وبسایت شرکتی",
    date: "۱۴۰۲/۰۸/۰۷",
    message: "انیمیشن‌های صفحه خیلی جذاب هستند."
  }
];
</script>
