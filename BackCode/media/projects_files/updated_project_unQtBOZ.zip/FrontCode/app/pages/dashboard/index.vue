<template>
  <div class="space-y-8">

    <div>
      <h1 class="text-2xl font-bold text-bone-white">داشبورد</h1>
      <p class="text-gray-400 mt-1">خلاصه فعالیت‌های شما</p>
    </div>
  <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6">
    
    <!-- پروژه ها -->
    <div class="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-5 flex items-center gap-4 transition-all duration-300 hover:-translate-y-1 hover:bg-white/10 hover:shadow-[0_8px_30px_rgb(0,0,0,0.12)]">
      <div class="flex items-center justify-center w-12 h-12 rounded-xl bg-cyan-500/20 border border-cyan-500/30 text-cyan-400">
        <Icon name="mdi:folder-outline" size="26"/>
      </div>
      <div>
        <p class="text-2xl font-bold text-white tracking-wider">24</p>
        <p class="text-sm text-gray-400 mt-1">پروژه ها</p>
      </div>
    </div>

    <!-- دانلود -->
    <div class="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-5 flex items-center gap-4 transition-all duration-300 hover:-translate-y-1 hover:bg-white/10 hover:shadow-[0_8px_30px_rgb(0,0,0,0.12)]">
      <div class="flex items-center justify-center w-12 h-12 rounded-xl bg-purple-500/20 border border-purple-500/30 text-purple-400">
        <Icon name="mdi:download-outline" size="26"/>
      </div>
      <div>
        <p class="text-2xl font-bold text-white tracking-wider">2,430</p>
        <p class="text-sm text-gray-400 mt-1">دانلود</p>
      </div>
    </div>

    <!-- نظرات -->
    <div class="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-5 flex items-center gap-4 transition-all duration-300 hover:-translate-y-1 hover:bg-white/10 hover:shadow-[0_8px_30px_rgb(0,0,0,0.12)]">
      <div class="flex items-center justify-center w-12 h-12 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400">
        <Icon name="mdi:comment-outline" size="26"/>
      </div>
      <div>
        <p class="text-2xl font-bold text-white tracking-wider">86</p>
        <p class="text-sm text-gray-400 mt-1">نظرات</p>
      </div>
    </div>

    <!-- نوتیفیکیشن -->
    <div class="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-5 flex items-center gap-4 transition-all duration-300 hover:-translate-y-1 hover:bg-white/10 hover:shadow-[0_8px_30px_rgb(0,0,0,0.12)]">
      <div class="flex items-center justify-center w-12 h-12 rounded-xl bg-orange-500/20 border border-orange-500/30 text-orange-400">
        <Icon name="mdi:bell-outline" size="26"/>
      </div>
      <div>
        <p class="text-2xl font-bold text-white tracking-wider">5</p>
        <p class="text-sm text-gray-400 mt-1">نوتیفیکیشن</p>
      </div>
    </div>

  </div>


    <div class="grid lg:grid-cols-3 gap-8">
  <DashboardDownloadChartVisitProject></DashboardDownloadChartVisitProject>
   <DashboardCounterBox></DashboardCounterBox>

    </div>

   <DashboardRecentActive></DashboardRecentActive>

  </div>
</template>
<script lang="ts" setup>
import DownloadChartVisitProject from '~/components/Dashboard/DownloadChartVisitProject.vue';
import CardBlury from '~/components/Ui/CardBlury.vue';
import { generateSeoMeta } from '~/utilities/seo';

definePageMeta({
  layout: "dashboard"
})

const seo = generateSeoMeta({
      title: `داشبورد آریا کرفت`,
      description: 'در ایند',
      image: "",
      url: ``,
      keywords: ["افزودن پروژه"],
      author:"علیرضا کشاورز",
      type: 'website'
    })
    useHead(seo)
</script>
<style scoped>

.stat-card{
display:flex;
align-items:center;
gap:14px;
padding:20px;
border-radius:16px;
background:rgba(255,255,255,0.04);
border:1px solid rgba(255,255,255,0.08);
backdrop-filter:blur(12px);
transition:.25s
}

.stat-card:hover{
border-color:#d4af37;
background:rgba(255,255,255,0.06)
}

.stat-icon{
width:46px;
height:46px;
display:flex;
align-items:center;
justify-content:center;
border-radius:12px;
background:rgba(212,175,55,0.15);
color:#d4af37
}

.stat-number{
font-size:20px;
font-weight:700;
color:white
}

.stat-label{
font-size:14px;
color:#9ca3af
}


.project-row{
display:flex;
justify-content:space-between;
align-items:center;
padding:12px 0;
border-bottom:1px solid rgba(255,255,255,0.05)
}

.notification{
display:flex;
align-items:center;
gap:10px;
color:#d1d5db
}

.activity{
display:flex;
align-items:center;
gap:10px;
color:#d1d5db
}

.dot{
width:8px;
height:8px;
border-radius:50%;
background:#d4af37
}

</style>
