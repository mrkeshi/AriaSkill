<template>
  <div class="flex justify-center items-center min-h-screen p-4">
    <div class="w-full max-w-4xl">
      <UiCardBlury>
        <div class="p-6 max-md:p-4" dir="rtl">
          <div class="login-card w-full rounded-2xl shadow-xl overflow-hidden">
            <div class="p-10 max-md:p-8 space-y-8">

              <div class="text-center space-y-2">
                <h1 class="text-2xl font-bold text-classic-gold flex gap-1 items-center justify-center">
                  <Icon name="mdi:user" size="27" class="w-14 h-14" />
                  ویرایش پروفایل
                </h1>
                <p class="text-sm text-bone-white">
                  اطلاعات حساب کاربری خود را بروزرسانی کنید
                </p>
              </div>

              <div class="flex flex-col items-center gap-4">
                <div class="relative">

                  <img
                    v-if="avatarPreview"
                    :src="avatarPreview"
                    class="w-32 h-32 border-4 border-classic-gold rounded-full object-cover shadow-lg"
                    alt="آواتار کاربر"
                  />

                  <div 
                    v-else 
                    class="w-32 h-32 border-4 border-classic-gold rounded-full bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-md flex items-center justify-center text-3xl font-bold text-classic-gold shadow-lg select-none uppercase"
                  >
                    {{ userInitial }}
                  </div>

                  <div class="absolute -bottom-2 left-1/2 -translate-x-1/2">
                    <UiFileInput
                      name="avatar"
                      label="آپلود آواتار"
                      v-model="form.avatar"
                      :accept="['image/jpeg','image/png']"
                      :disabled="loading || pageLoading"
                    />
                  </div>

                </div>
              </div>

              <Form :validation-schema="editUserSchema" @submit="submit" class="space-y-6">

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <UiInput
                    name="first_name"
                    label="نام"
                    placeholder="مثلا علیرضا"
                    v-model="form.first_name"
                    :disabled="loading || pageLoading"
                    rtl
                  />

                  <UiInput
                    name="last_name"
                    label="نام خانوادگی"
                    placeholder="مثلا کشاورز"
                    v-model="form.last_name"
                    :disabled="loading || pageLoading"
                    rtl
                  />
                </div>

                <UiInput
                  name="username"
                  label="نام کاربری"
                  v-model="form.username"
                  :disabled="loading || pageLoading"
                  placeholder="نام کاربریت رو رد کن بیاد"
                  rtl
                />

                <UiInput
                  name="email"
                  label="ایمیل"
                  v-model="form.email"
                  disabled
                  rtl
                />

                <UiInput
                  name="job_title"
                  label="عنوان شخصی"
                  placeholder="مثلا: توسعه دهنده فول استک"
                  v-model="form.job_title"
                  :disabled="loading || pageLoading"
                  rtl
                />

                <UiInput
                  name="about_me"
                  label="درباره من"
                  placeholder="چند خط درباره خودتان بنویسید."
                  v-model="form.about_me"
                  :disabled="loading || pageLoading"
                  rtl
                />

                <div class="space-y-3">
                  <label class="text-md mb-6 text-light-gold font-bold flex items-center"> 
                    <Icon name="mdi:bird" class="-mt-1" size="23"></Icon>
                    شبکه‌های اجتماعی
                  </label>

                  <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                    <div class="w-full">
                      <UiInput
                        label="آدرس اینستاگرام"
                        name="instagram_link"
                        placeholder="instagram.com/username"
                        v-model="form.instagram_link"
                        :disabled="loading || pageLoading"
                      />
                    </div>

                    <div class="w-full">
                      <UiInput
                        label="آدرس تلگرام"
                        name="telegram_link"
                        placeholder="t.me/username"
                        v-model="form.telegram_link"
                        :disabled="loading || pageLoading"
                      />
                    </div>

                    <div class="w-full">
                      <UiInput
                        label="آدرس لینکدین"
                        name="linkedin_link"
                        placeholder="linkedin.com/in/username"
                        v-model="form.linkedin_link"
                        :disabled="loading || pageLoading"
                      />
                    </div>

                    <div class="w-full">
                      <UiInput
                        label="آدرس دیسکورد"
                        name="discord_link"
                        placeholder="discord.com/users/username"
                        v-model="form.discord_link"
                        :disabled="loading || pageLoading"
                      />
                    </div>
                  </div>
                </div>

                <UiButton
                  variant="gold"
                  type="submit"
                  full
                  :disabled="loading || pageLoading"
                  class="mt-6"
                >
                  {{ loading ? 'در حال ذخیره...' : 'ذخیره تغییرات' }}
                </UiButton>

              </Form>

            </div>
          </div>
        </div>
      </UiCardBlury>
    </div>
  </div>
</template>

<script setup lang="ts">
definePageMeta({
  layout: 'dashboard'
})

import { reactive, ref, watch, onBeforeUnmount, onMounted, computed } from 'vue'
import { Form } from 'vee-validate'
import type { EditUserDTO } from '~/models/User/EditUserDTO'
import { editUserSchema } from '~/validation/User/EditUserSchema'
import { editUserService, getEditUserService } from '~/services/user/user.Service'
import { useCustomToastify } from '~/composable/useCustomToasitify'
import { useAuthStore } from '~/stores/authStore'
import { generateSeoMeta } from '~/utilities/seo'
import { normalizeSocialLinks, resolveMediaUrl } from '~/utilities/urlHelpers'

const loading = ref(false)
const pageLoading = ref(false)

const avatarPreview = ref<string>('')

const form = reactive<EditUserDTO>({
  avatar: null,
  username: '',
  email: '',
  first_name: '',
  last_name: '',
  job_title: '',
  about_me: '',
  instagram_link: '',
  telegram_link: '',
  linkedin_link: '',
  discord_link: ''
})

// کامپیوتر متغیر برای استخراج حرف اول (اولویت با نام، سپس نام کاربری و در نهایت کلمه کاربر)
const userInitial = computed(() => {
  const name = form.first_name.trim() || form.username.trim()
  return name ? name.charAt(0) : 'U'
})

let objectUrl: string | null = null
const { showSuccess } = useCustomToastify()
const authStore = useAuthStore()

watch(
  () => form.avatar,
  (file) => {
    if (objectUrl) {
      URL.revokeObjectURL(objectUrl)
      objectUrl = null
    }

    if (file instanceof File) {
      objectUrl = URL.createObjectURL(file)
      avatarPreview.value = objectUrl
    } else if (!file) {
      avatarPreview.value = ''
    }
  }
)

onBeforeUnmount(() => {
  if (objectUrl) URL.revokeObjectURL(objectUrl)
})

const fillForm = (profile: Partial<EditUserDTO>) => {
  form.avatar = null
  form.username = profile.username ?? ''
  form.email = profile.email ?? ''
  form.first_name = profile.first_name ?? ''
  form.last_name = profile.last_name ?? ''
  form.job_title = profile.job_title ?? ''
  form.about_me = profile.about_me ?? ''
  form.instagram_link = profile.instagram_link ?? ''
  form.telegram_link = profile.telegram_link ?? ''
  form.linkedin_link = profile.linkedin_link ?? ''
  form.discord_link = profile.discord_link ?? ''
  const avatar = profile.avatar ?? profile.avatr
  avatarPreview.value = typeof avatar === 'string' && avatar ? resolveMediaUrl(avatar) : ''
}

const fetchProfile = async () => {
  pageLoading.value = true
  try {
    const res = await getEditUserService()
    if (res.data) {
      fillForm(res.data)
    }
  } catch (error) {
    console.error('خطا در دریافت اطلاعات پروفایل:', error)
  } finally {
    pageLoading.value = false
  }
}

const appendField = (formData: FormData, key: keyof EditUserDTO) => {
  const value = form[key]
  formData.append(key, typeof value === 'string' ? value : '')
}

const submit = async () => {
  loading.value = true
  try {
    const formData = new FormData()
    appendField(formData, 'username')
    appendField(formData, 'first_name')
    appendField(formData, 'last_name')
    appendField(formData, 'job_title')
    appendField(formData, 'about_me')

    const socialLinks = normalizeSocialLinks(form)
    formData.append('instagram_link', socialLinks.instagram_link)
    formData.append('telegram_link', socialLinks.telegram_link)
    formData.append('linkedin_link', socialLinks.linkedin_link)
    formData.append('discord_link', socialLinks.discord_link)

    if (form.avatar instanceof File) {
      formData.append('avatar', form.avatar)
    }

    const res = await editUserService(formData)
    if (res.data) {
      fillForm(res.data)
    }
    await authStore.fetchUser()

    showSuccess({
      title: 'ویرایش پروفایل',
      message: 'پروفایل شما با موفقیت بروزرسانی شد.',
    })
  } catch (error) {
    console.error('خطا در ویرایش پروفایل:', error)
  } finally {
    loading.value = false
  }
}

onMounted(fetchProfile)

const seo = generateSeoMeta({
  title: `ویرایش پروفایل`,
  description: 'در ایند',
  image: "",
  url: ``,
  keywords: ["افزودن پروژه"],
  author:"علیرضا کشاورز",
  type: 'website'
})
useHead(seo)
</script>