export interface SendCommentDTO{
    project:number
    parent:number|null,
    message:string
}

export interface CommentDTO{
    id:number,
    project:number,
    user:number,
    user_name:string,
    user_avatar:string
}