<template>
<UiCardBlury>
        

        <div class="flex items-center justify-between text-gray-300 text-sm">
          <span class="flex items-center gap-2">
            <Icon name="mdi:calendar" class="text-light-gold text-lg"/>
            چهارشنبه ۱۸ اسفند
          </span>
 <div class="flex items-center gap-2 text-gray-300 text-sm">
            <Icon name="mdi:shape-outline" class="text-light-gold text-lg"/>
            UI Design
          </div>
          <span class="flex items-center gap-2">
            <Icon name="mdi:comment-outline" class="text-light-gold text-lg"/>
            ۱۲ نظر
          </span>
        </div>

    </UiCardBlury>
</template>

<script lang="ts" setup>

</script>

<style>

</style>