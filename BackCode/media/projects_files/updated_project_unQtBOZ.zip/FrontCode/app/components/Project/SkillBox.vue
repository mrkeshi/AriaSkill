<template>
  <ui-card-blury>


        <h3 class="text-white font-semibold mb-4">تکنولوژی‌های استفاده شده</h3>

        <div class="flex flex-wrap gap-2">

          <a class="backdrop-blur-md transition hover:opacity-50 shadow-2xl p-2 bg-carb-gray/40 border border-white/10 rounded-md flex items-center gap-1.5">
            <img src="/images/program/css.png" class="h-5 w-5">
            <span class="text-white text-sm">CSS</span>
          </a>

          <div class="backdrop-blur-md transition hover:opacity-50 shadow-2xl p-2 bg-carb-gray/40 border border-white/10 rounded-md flex items-center gap-1.5">
            <img src="/images/program/node.png" class="h-5 w-5">
            <span class="text-white text-sm">Node.js</span>
          </div>

          <div class="backdrop-blur-md transition hover:opacity-50 shadow-2xl p-2 bg-carb-gray/40 border border-white/10 rounded-md flex items-center gap-1.5">
            <img src="/images/program/laravel.png" class="h-5 w-5">
            <span class="text-white text-sm">Laravel</span>
          </div>

        </div>

        </ui-card-blury>
</template>

<script lang="ts" setup>

</script>

<style>

</style>