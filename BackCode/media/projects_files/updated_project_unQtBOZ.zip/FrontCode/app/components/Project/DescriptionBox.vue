<template>
<ui-card-blury>


        <h2 class="text-xl font-semibold text-white mb-4">توضیحات پروژه</h2>

        <p class="text-gray-300 leading-8">
          این پروژه یک طراحی رابط کاربری مدرن برای یک وبسایت آموزشی است
          که با تمرکز بر تجربه کاربری و طراحی مینیمال ساخته شده است.
          در این پروژه از ترکیب رنگ‌های تیره و طلایی برای ایجاد حس
          لوکس و حرفه‌ای استفاده شده است.
        </p>

     </ui-card-blury>
</template>

<script lang="ts" setup>

</script>

<style>

</style>