<template>
<ui-card-blury>
        <h3 class="text-white font-semibold mb-4">درباره سازنده</h3>

        <div class="flex items-center gap-4">

          <img src="/images/user1.jpg" class="w-14 h-14 rounded-full border-2 border-classic-gold"/>

          <div>
            <p class="text-white">علی رضایی</p>
            <span class="text-gray-400 text-sm">UI Designer</span>
          </div>

        </div>

        <div class="mt-5">
          <UiButton
          variant="outline"
          full>
            مشاهده پروفایل
          </UiButton>
        </div>

      </ui-card-blury>
</template>

<script lang="ts" setup>

</script>

<style>

</style>