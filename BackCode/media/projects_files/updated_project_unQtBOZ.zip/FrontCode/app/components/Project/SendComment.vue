<template>
<UiCardBlury>



    <h3 class="text-light-gold text-lg mb-4">ثبت نظر</h3>
        <Form @submit="sendrequest" v-slot="{ meta, resetForm }" :validation-schema="SendCommentSchema" class="space-y-5">

   <UiTextarea rtl name="message"
       
             placeholder="هرچه دل تنگت میخواهد بنویس" 
              v-model="form.message"
              :disabled="loading"
              label="متن پیغام شما">
</UiTextarea >
    <div class="flex justify-end mt-4">
      <UiButton type="submit" variant="bracket" class="cursor-pointer">
        ارسال نظر
      </UiButton>
    </div>
</Form>
  </UiCardBlury>
</template>

<script lang="ts" setup>
import type { SendCommentDTO } from '~/models/Comment/SendCommentDTO';
import { SendCommentSchema } from '~/validation/Comment/SendComment';
import { Form } from 'vee-validate';
const loading = ref(false)

const props=defineProps({
replayId:{
  type:Number,
default:undefined
}
})
const form:SendCommentDTO = reactive({
  replayId: undefined,
  message: ''
})
const sendrequest = async (_: unknown, { resetForm }: any) => {
  loading.value = true

}
</script>

<style>

</style>