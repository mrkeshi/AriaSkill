<template>
<UiCardBlury>
  <div class="flex justify-between  ">
 <div class="like flex items-center gap-1 text-classic-gold">

    <svg
      class="transition cursor-pointer stroke-2 fill-none stroke-classic-gold hover:fill-classic-gold"
      width="26"
      height="26"
      viewBox="0 0 28 28"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M14.373 3.02051C17.377 -0.33962 22.2217 -0.339604 25.2256 3.02051C28.2582 6.41322 28.2585 11.9346 25.2256 15.3271L14.5938 27.2188C14.2587 27.5935 13.7413 27.5935 13.4062 27.2188L2.77441 15.3271C-0.258493 11.9346 -0.258263 6.41324 2.77441 3.02051C5.77835 -0.33962 10.623 -0.339604 13.627 3.02051L14 3.4375L14.373 3.02051Z"
      />
    </svg>

    <span class="font-black -mb-1">
      <span>۲۵</span> لایک
    </span>

  </div>


  <div class="share flex items-center gap-1 text-classic-gold cursor-pointer">

    <svg
      width="26"
      height="26"
      viewBox="0 0 28 28"
      class="fill-classic-gold"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g clip-path="url(#clip0_67_1096)">
        <path
          d="M21 18.76C20.1133 18.76 19.32 19.11 18.7133 19.6584L10.395 14.8167C10.4533 14.5484 10.5 14.28 10.5 14C10.5 13.72 10.4533 13.4517 10.395 13.1834L18.62 8.38837C19.25 8.97171 20.0783 9.33337 21 9.33337C22.9367 9.33337 24.5 7.77004 24.5 5.83337C24.5 3.89671 22.9367 2.33337 21 2.33337C19.0633 2.33337 17.5 3.89671 17.5 5.83337C17.5 6.11337 17.5467 6.38171 17.605 6.65004L9.38 11.445C8.75 10.8617 7.92167 10.5 7 10.5C5.06333 10.5 3.5 12.0634 3.5 14C3.5 15.9367 5.06333 17.5 7 17.5C7.92167 17.5 8.75 17.1384 9.38 16.555L17.6867 21.4084C17.6283 21.6534 17.5933 21.91 17.5933 22.1667C17.5933 24.045 19.1217 25.5734 21 25.5734C22.8783 25.5734 24.4067 24.045 24.4067 22.1667C24.4067 20.2884 22.8783 18.76 21 18.76Z"
        />
      </g>

      <defs>
        <clipPath id="clip0_67_1096">
          <rect width="28" height="28" fill="white"/>
        </clipPath>
      </defs>

    </svg>

    <span class="font-black -mb-1">اشتراک گذاری</span>

  </div>

  </div>
 
</UiCardBlury>
</template>

<script lang="ts" setup>

</script>

<style>

</style>