<template>
  <div :class="['grid','grid-cols-1', 'my-8 sm:grid-cols-2' , `lg:grid-cols-${lgGrid}` ,'gap-8',] ">

  <ProjectCard :min=props.min></ProjectCard>
  <ProjectCard :min=props.min></ProjectCard>
  <ProjectCard :min=props.min></ProjectCard>

  </div>
</template>

<script lang="ts" setup>
const props= defineProps({
  lgGrid:{
    type:String,
    default:3,
    
  },
  min:{
    type:String,
    default:false
  }
})
</script>

<style>

</style>