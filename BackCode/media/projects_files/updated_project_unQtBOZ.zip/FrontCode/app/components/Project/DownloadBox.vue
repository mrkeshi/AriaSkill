<template>
<ui-card-blury>
        <div class="flex justify-between mb-4">

          <div class="text-center">
            <span class="text-light-gold text-xl font-semibold ">۸۹</span>
            <p class="text-gray-400 text-sm">دانلود</p>
          </div>
  <div class="text-center">

            <span class="text-light-gold text-md font-semibold">۳ ساعت پیش</span>
            <p class="text-gray-400 text-sm">آخرین دانلود</p>
          </div>
          <div class="text-center">

            <span class="text-light-gold text-xl font-semibold">۲۳۵</span>
            <p class="text-gray-400 text-sm">بازدید</p>
          </div>
 
        </div>

      

        <UiButton
        icon="mdi:download"
        full
        variant="gold">
          دانلود پروژه
        </UiButton>

      </ui-card-blury>
</template>

<script lang="ts" setup>

</script>

<style>

</style>