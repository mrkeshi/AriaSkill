<template>
 <div class="backdrop-blur-md shadow-2xl bg-carb-gray/10 border border-white/10 rounded-2xl p-4 transition overflow-hidden hover:-translate-y-1 ease-in  ">

      <div class="w-full h-60 relative" v-show="!min">
        <img src="/images/project-1.jpg"
             alt=""
             class="w-full h-full rounded-2xl ">
            <span class="absolute bg-black -bottom-8 transition right-4 h-20 w-20 rounded-full border-[3px] border-classic-gold"></span>
             <img src="/images/user1.jpg" alt="" class="absolute -bottom-8 hover:opacity-60 transition right-4 h-20 w-20 rounded-full border-[3px] border-classic-gold">
      </div>

<div :class="['p-2','md:p-4','flex','flex-col',{ 'mt-7': !min },'mb-3']">


        <NuxtLink to="/explore" class="text-xl transition hover:text-light-gold font-semibold text-white mb-1">
         پروژه سلام زندگی
        </NuxtLink>
        <span class="text-gray-500 ">UI Design</span>
          <div class=" my-3 mb-5 h-0.5  bg-carb-gray/30 w-full"></div>
          <div class="flex flex-wrap gap-2">
            <a class="backdrop-blur-md shadow-xl p-2 transition hover:bg-carb-gray cursor-pointer bg-carb-gray/40 border border-white/10 rounded-md flex items-center gap-1.5">
              <img src="/images/program/css.png" class="h-5 w-5" alt="">
              <span class="text-white text-sm">سی اس اس</span>
            </a>
             <a class="backdrop-blur-md shadow-xl transition hover:bg-carb-gray cursor-pointer  p-2 bg-carb-gray/40 border border-white/10 rounded-md flex items-center gap-1.5">
              <img src="/images/program/node.png" class="h-5 w-5" alt="">
              <span class="text-white text-sm">نودجی‌اس</span>
             </a>
             <a class="backdrop-blur-md shadow-xl transition hover:bg-carb-gray cursor-pointer  p-2 px-3 bg-carb-gray/40 border border-white/10 rounded-md flex items-center gap-1.5">
              <img src="/images/program/laravel.png" class="h-5 w-5" alt="">
              <span class="text-white text-sm">لاراوال</span>
             </a>
          </div>

          <div class="inline-flex backdrop-blur-md shadow-xl my-3 p-2 bg-carb-gray/40 border border-white/10 rounded-md items-center gap-1.5 w-fit">
  <Icon name="mdi:calendar" class="text-xl"/>
  <span class="text-white text-sm">چهارشنبه ۱۸ اسفند</span>
</div>

         <div class=" my-3 mb-5 h-0.5  bg-carb-gray/30 w-full"></div>
        <div class="flex items-center -mb-6 justify-between">

     
          <div class="flex items-center gap-4 text-gray-300">

            <span class="flex items-center gap-1 text-sm ">
              <Icon name="mdi:heart" class="text-error  text-[18px]" />
              ۱۰ پسند
            </span>

            <span class="flex items-center gap-1 text-sm ">
              <Icon name="mdi:download" class="text-indigo-600 text-[18px]" />
              ۸۹ دانلود
            </span>

          </div>

         
          <NuxtLink to="/explore" class="bg-classic-gold  hover:bg-light-gold transition h-12 w-12 text-black px-4 py-1.5 rounded-full flex items-center gap-1 ">
            <Icon name="mdi:arrow-left" class="w-14 h-14" />
          </NuxtLink>

        </div>

      </div>
    </div>
</template>

<script lang="ts" setup>

const props=defineProps({
  min:{
    type:Boolean,
    default:false
  }
})

</script>

<style>

</style>
