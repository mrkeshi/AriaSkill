<template>
  <header
    class="sticky top-0 z-30 h-20
    backdrop-blur-md shadow-2xl bg-carb-gray/10
    border-b border-white/10"
  >
    <div class="flex h-full items-center justify-between px-6">

      <div class="flex flex-col max-lg:hidden">
        <h1 class="font-bold text-white text-2xl">
          {{ greetingText }}
          <span class="text-classic-gold">{{ displayName }}</span>
          عزیز، خوش آمدی 👋
        </h1>
      </div>

      <NuxtLink
        to="/dashboard/profile"
        class="flex items-center gap-3 rounded-2xl text-white"
      >
        <img
          v-if="user.avatar"
          :src="user.avatar"
          class="h-14 w-14 border-classic-gold border-4 rounded-full object-cover"
          :alt="displayName"
        >
        <div
          v-else
          class="h-14 w-14 border-classic-gold border-4 rounded-full bg-classic-gold/20 flex items-center justify-center text-classic-gold text-xl font-bold"
        >
          {{ avatarFallback }}
        </div>
      </NuxtLink>

    </div>
  </header>
</template>

<script setup lang="ts">
import { computed } from 'vue'

const auth = useAuthStore()
const user = auth.user

const displayName = computed(() =>
  user.first_name || user.username || 'کاربر'
)

const avatarFallback = computed(() =>
  (user.first_name?.[0] || user.username?.[0] || 'ک').toUpperCase()
)

// سلام بر اساس ساعت
const greetingText = computed(() => {
  const hour = new Date().getHours()
  if (hour < 12) return 'صبح بخیر،'
  if (hour < 17) return 'ظهر بخیر،'
  if (hour < 21) return 'عصر بخیر،'
  return 'شب بخیر،'
})
</script>
