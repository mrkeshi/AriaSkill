<template>
  <div class="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 mt-6">
    
    <!-- Header -->
    <div class="flex items-center justify-between mb-6">
      <h3 class="text-lg font-bold text-white">فعالیت‌های اخیر</h3>
      <button class="text-sm text-cyan-400 hover:text-cyan-300 transition-colors">مشاهده همه</button>
    </div>

    <!-- Horizontal Timeline -->
    <div class="relative flex items-start justify-between gap-6 pt-8">

      <!-- خط افقی -->
      <div class="absolute top-8 left-0 right-0 h-0.5 bg-white/5 rounded-full"></div>

      <!-- آیتم -->
      <div class="relative text-center group flex-1">
        <!-- نقطه -->
        <div class="w-8 h-8 mx-auto flex items-center justify-center rounded-full border border-cyan-400/40 bg-cyan-400/10 text-cyan-400 shadow-[0_0_10px_rgba(6,182,212,0.2)] group-hover:scale-110 transition-transform">
          <Icon name="mdi:cloud-upload-outline" size="18"/>
        </div>
        <!-- کارت -->
        <div class="mt-4 bg-white/5 border border-white/10 rounded-xl p-4 hover:bg-white/10 transition-all">
          <div class="text-gray-200 font-semibold mb-1">پروژه جدید</div>
          <div class="text-xs text-gray-500 mb-1">۲ ساعت پیش</div>
          <p class="text-sm text-gray-400">پروژه طراحی رابط کاربری فروشگاه منتشر شد.</p>
        </div>
      </div>

      <!-- آیتم -->
      <div class="relative text-center group flex-1">
        <div class="w-8 h-8 mx-auto flex items-center justify-center rounded-full border border-emerald-400/40 bg-emerald-400/10 text-emerald-400 shadow-[0_0_10px_rgba(16,185,129,0.2)] group-hover:scale-110 transition-transform">
          <Icon name="mdi:comment-text-outline" size="18"/>
        </div>
        <div class="mt-4 bg-white/5 border border-white/10 rounded-xl p-4 hover:bg-white/10 transition-all">
          <div class="text-gray-200 font-semibold mb-1">نظر جدید</div>
          <div class="text-xs text-gray-500 mb-1">۵ ساعت پیش</div>
          <p class="text-sm text-gray-400">علی احمدی روی پروژه شما نظر ثبت کرد.</p>
        </div>
      </div>

      <!-- آیتم -->
      <div class="relative text-center group flex-1">
        <div class="w-8 h-8 mx-auto flex items-center justify-center rounded-full border border-orange-400/40 bg-orange-400/10 text-orange-400 shadow-[0_0_10px_rgba(249,115,22,0.2)] group-hover:scale-110 transition-transform">
          <Icon name="mdi:alert-circle-outline" size="18"/>
        </div>
        <div class="mt-4 bg-white/5 border border-white/10 rounded-xl p-4 hover:bg-white/10 transition-all">
          <div class="text-gray-200 font-semibold mb-1">هشدار سرور</div>
          <div class="text-xs text-gray-500 mb-1">دیروز</div>
          <p class="text-sm text-gray-400">فضای سرور به ۸۰٪ رسیده است.</p>
        </div>
      </div>

      <!-- آیتم -->
      <div class="relative text-center group flex-1">
        <div class="w-8 h-8 mx-auto flex items-center justify-center rounded-full border border-purple-400/40 bg-purple-400/10 text-purple-400 shadow-[0_0_10px_rgba(168,85,247,0.2)] group-hover:scale-110 transition-transform">
          <Icon name="mdi:login" size="18"/>
        </div>
        <div class="mt-4 bg-white/5 border border-white/10 rounded-xl p-4 hover:bg-white/10 transition-all">
          <div class="text-gray-200 font-semibold mb-1">ورود موفق</div>
          <div class="text-xs text-gray-500 mb-1">۲ روز پیش</div>
          <p class="text-sm text-gray-400">ورود موفقیت‌آمیز از دستگاه ویندوز.</p>
        </div>
      </div>

    </div>

  </div>
</template>
