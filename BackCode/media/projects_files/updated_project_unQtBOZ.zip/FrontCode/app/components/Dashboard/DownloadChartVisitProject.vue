<template>
  <UiCardBlury class="lg:col-span-2 glass-box">
    <div class="p-4">
      <!-- هدر نمودار -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between mb-6 gap-4">
        <div>
          <h2 class="text-lg font-semibold text-white">
            آمار بازدید و دانلود
          </h2>
          <p class="text-sm text-gray-400 mt-1">روند تجمعی ۱۵ روز اخیر کل پروژه‌ها</p>
        </div>
        
        <div class="flex gap-4 text-sm">
          <div class="flex items-center gap-2">
            <span class="w-3 h-3 rounded-full bg-cyan-500 shadow-[0_0_10px_rgba(6,182,212,0.8)]"></span>
            <span class="text-gray-300">بازدید</span>
          </div>
          <div class="flex items-center gap-2">
            <span class="w-3 h-3 rounded-full bg-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.8)]"></span>
            <span class="text-gray-300">دانلود</span>
          </div>
        </div>
      </div>

      <!-- بدنه نمودار -->
      <div class="w-full h-[320px] text-black" dir="ltr">
        <ClientOnly>
          <apexchart 
            width="100%"
            height="100%"
            type="area" 
            :options="chartOptions" 
            :series="series"
          ></apexchart>
          <template #fallback>
            <div class="w-full h-full flex items-center justify-center text-gray-400">
              در حال بارگذاری نمودار...
            </div>
          </template>
        </ClientOnly>
      </div>
    </div>
  </UiCardBlury>
</template>

<script setup>
import { ref } from 'vue';

const series = ref([
  { name: 'بازدید', data: [120, 150, 140, 180, 220, 200, 250, 280, 310, 290, 350, 380, 410, 450, 500] },
  { name: 'دانلود', data: [30, 40, 35, 50, 65, 55, 80, 95, 110, 100, 130, 150, 170, 190, 220] }
]);

const chartOptions = ref({
  chart: {
    type: 'area',
    fontFamily: 'inherit',
    toolbar: { show: false },
    background: 'transparent',
    zoom: { enabled: false }
  },
  colors: ['#06b6d4', '#f97316'], 
  dataLabels: { enabled: false },
  stroke: { curve: 'smooth', width: 3 },
  fill: {
    type: 'gradient',
    gradient: {
      shadeIntensity: 1,
      opacityFrom: 0.4,
      opacityTo: 0.05,
      stops: [0, 100]
    }
  },
  xaxis: {
    categories: ['روز 1', 'روز 2', 'روز 3', 'روز 4', 'روز 5', 'روز 6', 'روز 7', 'روز 8', 'روز 9', 'روز 10', 'روز 11', 'روز 12', 'روز 13', 'روز 14', 'امروز'],
    axisBorder: { show: false },
    axisTicks: { show: false },
    labels: { style: { colors: '#9ca3af' } }
  },
  yaxis: {
    labels: { style: { colors: '#9ca3af' } }
  },
  grid: {
    borderColor: 'rgba(255, 255, 255, 0.05)',
    strokeDashArray: 4,
    yaxis: { lines: { show: true } },
    xaxis: { lines: { show: false } }
  },
  theme: { mode: 'dark' },
  legend: { show: false },
  tooltip: { theme: 'dark' }
});
</script>
