<template>
   <div class="glass-box">

        <h2 class="text-lg font-semibold text-bone-white mb-6">
          نوتیفیکیشن ها
        </h2>

        <div class="space-y-4">

          <div class="notification">
            <Icon name="mdi:download" size="20"/>
            <p>پروژه شما دانلود شد</p>
          </div>

          <div class="notification">
            <Icon name="mdi:comment-outline" size="20"/>
            <p>یک نظر جدید ثبت شد</p>
          </div>

          <div class="notification">
            <Icon name="mdi:star-outline" size="20"/>
            <p>پروژه شما امتیاز گرفت</p>
          </div>

        </div>

      </div>
</template>

<script lang="ts" setup>

</script>

<style>

</style>