<template>
  <aside
    :class="[
      'sticky top-0 h-screen transition-all duration-300 flex flex-col',
      'backdrop-blur-md shadow-2xl bg-carb-gray/10 border-l border-white/10',
      collapsed ? 'w-20' : 'w-72'
    ]"
  >
    <Confirm
      v-model="logout"
      title="خروج"
      description="آیا برای خروج مطمئن هستید؟"
      :onConfirm="auth.logout"
    />

    <!-- Top (Header) -->
    <div class="flex items-center justify-between h-20 px-4 border-b border-white/10 shrink-0">
      <button
        class="flex h-11 w-11 items-center justify-center rounded-2xl border border-white/10 bg-white/5 text-white transition-colors hover:bg-white/10"
        @click="$emit('toggle')"
      >
        <Icon name="mdi:menu" class="text-xl" />
      </button>

      <span v-if="!collapsed" class="text-xl font-bold text-classic-gold pr-2">
        SkillSphere
      </span>
    </div>

    <!-- Middle (Menus) -->
    <div class="flex-1 overflow-y-auto py-4 px-3 custom-scrollbar flex flex-col gap-1">
      
      <!-- User Menu -->
      <NuxtLink
        to="/dashboard"
        class="flex items-center gap-3 px-4 py-3 rounded-xl transition border border-transparent text-white/70 hover:bg-white/10 hover:text-white"
        :class="isActiveDSH('/dashboard') ? 'bg-classic-gold/20 text-classic-gold border-classic-gold/30' : ''"
      >
        <Icon name="mdi:view-dashboard" class="text-xl shrink-0" />
        <span v-if="!collapsed" class="truncate">داشبورد</span>
      </NuxtLink>

      <NuxtLink
        to="/dashboard/projects"
        class="flex items-center gap-3 px-4 py-3 rounded-xl transition border border-transparent text-white/70 hover:bg-white/10 hover:text-white"
        :class="isActive('/dashboard/projects') ? 'bg-classic-gold/20 text-classic-gold border-classic-gold/30' : ''"
      >
        <Icon name="mdi:folder-outline" class="text-xl shrink-0" />
        <span v-if="!collapsed" class="truncate">پروژه‌ها</span>
      </NuxtLink>

      <NuxtLink
        to="/dashboard/notifications"
        class="flex items-center gap-3 px-4 py-3 rounded-xl transition border border-transparent text-white/70 hover:bg-white/10 hover:text-white"
        :class="isActive('/dashboard/notifications') ? 'bg-classic-gold/20 text-classic-gold border-classic-gold/30' : ''"
      >
        <Icon name="mdi:bell-outline" class="text-xl shrink-0" />
        <span v-if="!collapsed" class="truncate">نوتیفیکیشن</span>
      </NuxtLink>

      <NuxtLink
        to="/dashboard/comments"
        class="flex items-center gap-3 px-4 py-3 rounded-xl transition border border-transparent text-white/70 hover:bg-white/10 hover:text-white"
        :class="isActive('/dashboard/comments') ? 'bg-classic-gold/20 text-classic-gold border-classic-gold/30' : ''"
      >
        <Icon name="mdi:comment-outline" class="text-xl shrink-0" />
        <span v-if="!collapsed" class="truncate">نظرات</span>
      </NuxtLink>

      <NuxtLink
        to="/dashboard/profile"
        class="flex items-center gap-3 px-4 py-3 rounded-xl transition border border-transparent text-white/70 hover:bg-white/10 hover:text-white"
        :class="isActive('/dashboard/profile') ? 'bg-classic-gold/20 text-classic-gold border-classic-gold/30' : ''"
      >
        <Icon name="mdi:account-circle-outline" class="text-xl shrink-0" />
        <span v-if="!collapsed" class="truncate">پروفایل</span>
      </NuxtLink>


      <div v-if="auth.isAdmin" class="mt-4 pt-4 border-t border-white/10 flex flex-col gap-1">
        <p v-if="!collapsed" class="px-4 text-xs font-semibold text-white/40 mb-2 mt-1">
          سطح دسترسی: مدیر
        </p>

        <NuxtLink
          to="/dashboard/admin/users"
          class="flex items-center gap-3 px-4 py-3 rounded-xl transition border border-transparent text-white/70 hover:bg-white/10 hover:text-white"
          :class="isActive('/dashboard/admin/users') ? 'bg-classic-gold/20 text-classic-gold border-classic-gold/30' : ''"
        >
          <Icon name="mdi:account-group-outline" class="text-xl shrink-0" />
          <span v-if="!collapsed" class="truncate">مدیریت کاربران</span>
        </NuxtLink>

        <NuxtLink
          to="/dashboard/admin/projects"
          class="flex items-center gap-3 px-4 py-3 rounded-xl transition border border-transparent text-white/70 hover:bg-white/10 hover:text-white"
          :class="isActive('/dashboard/admin/projects') ? 'bg-classic-gold/20 text-classic-gold border-classic-gold/30' : ''"
        >
          <Icon name="mdi:folder-cog-outline" class="text-xl shrink-0" />
          <span v-if="!collapsed" class="truncate">مدیریت پروژه‌ها</span>
        </NuxtLink>
     
        <NuxtLink
          to="/dashboard/admin/comments"
          class="flex items-center gap-3 px-4 py-3 rounded-xl transition border border-transparent text-white/70 hover:bg-white/10 hover:text-white"
          :class="isActive('/dashboard/admin/comments') ? 'bg-classic-gold/20 text-classic-gold border-classic-gold/30' : ''"
        >
          <Icon name="mdi:comment-processing-outline" class="text-xl shrink-0" />
          <span v-if="!collapsed" class="truncate">مدیریت نظرات</span>
        </NuxtLink>

        <NuxtLink
          to="/dashboard/admin/skills"
          class="flex items-center gap-3 px-4 py-3 rounded-xl transition border border-transparent text-white/70 hover:bg-white/10 hover:text-white"
          :class="isActive('/dashboard/admin/skills') ? 'bg-classic-gold/20 text-classic-gold border-classic-gold/30' : ''"
        >
          <Icon name="mdi:tag-multiple-outline" class="text-xl shrink-0" />
          <span v-if="!collapsed" class="truncate">مدیریت مهارت‌ها</span>
        </NuxtLink>
      </div>

    </div>

    <div class="p-4 border-t border-white/10 shrink-0">
      <button
        class="w-full flex items-center justify-center gap-3 px-4 py-3 rounded-xl transition text-red-400 hover:bg-red-500/20 border border-transparent hover:border-red-500/40"
        @click="logout = true"
      >
        <Icon name="mdi:logout" class="text-xl shrink-0" />
        <span v-if="!collapsed" class="font-medium">خروج از حساب</span>
      </button>
    </div>
  </aside>
</template>

<script setup>
import { useRoute } from 'vue-router'

defineProps({ collapsed: Boolean })
const auth = useAuthStore()

const route = useRoute()
const logout = ref(false)

const isActive = (path) => route.path.startsWith(path)
const isActiveDSH = (path) => route.path === path
</script>

<style scoped>

.custom-scrollbar::-webkit-scrollbar {
  width: 4px;
}
.custom-scrollbar::-webkit-scrollbar-track {
  background: transparent;
}
.custom-scrollbar::-webkit-scrollbar-thumb {
  background-color: rgba(255, 255, 255, 0.1);
  border-radius: 10px;
}
</style>
