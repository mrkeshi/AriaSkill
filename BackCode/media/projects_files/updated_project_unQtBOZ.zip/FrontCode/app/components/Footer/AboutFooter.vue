<template>
    <div class="flex flex-col gap-5">
          <h2 class="text-classic-gold text-2xl font-bold">
            Aria Craft
          </h2>

    
          <p class="text-bone-white/70 text-sm leading-7">
            لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ
            و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه
            روزنامه و مجله در ستون و سطرآنچنان که لازم است.
          </p>

     
                  <span class="text-bone-white text-sm ">
با آریاکرفت
<span class="text-light-gold ">عالی باشید   >> </span>
</span>
<div class="flex gap-4  justify-end ml-3">
<FooterSocialLink></FooterSocialLink>
</div>




        </div>
</template>

<script lang="ts" setup>

</script>

<style>

</style>