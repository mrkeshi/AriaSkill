/**
 * dateHelpers.ts
 *
 * Jalali / Shamsi date utilities.
 *
 * Strategy: use the browser-native `Intl.DateTimeFormat` with
 * `calendar: 'persian'` and `numberingSystem: 'latn'` (Latin digits).
 * This requires zero external dependencies and is consistent with how
 * the project already uses Intl for locale formatting.
 *
 * If you ever need Arabic-Indic numerals instead of Latin, change
 * `numberingSystem` to `'arab'`.
 */

const persianFormatter = new Intl.DateTimeFormat('fa-IR', {
  calendar: 'persian',
  numberingSystem: 'latn',
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
})

const persianFormatterLong = new Intl.DateTimeFormat('fa-IR', {
  calendar: 'persian',
  numberingSystem: 'latn',
  year: 'numeric',
  month: 'long',
  day: 'numeric',
})

/**
 * Convert an ISO 8601 date string (or Date object) to a short Jalali
 * date string like `۱۴۰۳/۰۹/۱۵` (YYYY/MM/DD).
 *
 * Returns `'-'` for null / undefined / invalid input.
 */
export const toJalali = (value?: string | Date | null): string => {
  if (!value) return '-'
  const date = value instanceof Date ? value : new Date(value)
  if (isNaN(date.getTime())) return '-'
  return persianFormatter.format(date)
}

/**
 * Convert an ISO 8601 date string (or Date object) to a long Jalali
 * date string like `۱۵ آذر ۱۴۰۳`.
 *
 * Returns `'-'` for null / undefined / invalid input.
 */
export const toJalaliLong = (value?: string | Date | null): string => {
  if (!value) return '-'
  const date = value instanceof Date ? value : new Date(value)
  if (isNaN(date.getTime())) return '-'
  return persianFormatterLong.format(date)
}
