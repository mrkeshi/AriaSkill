import * as Yup from 'yup'

export const ResetPassowrdWithEmailSchema = Yup.object().shape({
  email: Yup.string().email("ایمیل باید معتبر باشد").required("احمق لطفا ایمیل خودت رو درست وارد کن."),


})

export const SendCommentSchema=Yup.object().shape({
    message:Yup.string().min(10,"طول کامنت حداقل باید ده کاراکتر باشد").max(300,"طول کامنت باید حداکثر سیصد کاراکتر باشد")
})