import tailwindcss from "@tailwindcss/vite";
import Icons from 'unplugin-icons/vite'

 export default defineNuxtConfig({
   compatibilityDate: "2025-07-15",
   devtools: { enabled: true },
   css: ["@/assets/css/main.css"],
   runtimeConfig: {
     public: {
       googleClientId: process.env.NUXT_PUBLIC_GOOGLE_CLIENT_ID || '',
     },
   },
   
   modules: ['@nuxt/icon',
     'nuxt-toastify',
     "@pinia/nuxt"
   ],




   vite: {
     plugins: [tailwindcss()],
   },



 });
