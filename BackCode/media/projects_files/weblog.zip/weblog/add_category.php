<?php
require 'config.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: login_register.php');
    exit;
}

$error = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    if ($title === '') {
        $error = 'عنوان دسته بندی نمی تواند خالی باشد.';
    } else {
        $title = $conn->real_escape_string($title);
        $check = $conn->query("SELECT id FROM categories WHERE title = '$title'");
        if ($check->num_rows > 0) {
            $error = 'این عنوان قبلاً وجود دارد.';
        } else {
            $conn->query("INSERT INTO categories (title) VALUES ('$title')");
            $success = 'دسته بندی با موفقیت اضافه شد.';
        }
    }
}
?>
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <title>افزودن دسته بندی</title>
    <style>
        body{font-family:Tahoma;background:#f0f2f5;margin:0;padding:20px;}
        .container{max-width:500px;margin:auto;background:#fff;padding:20px;border-radius:8px;}
        input,button{width:100%;padding:8px;margin:8px 0;border-radius:4px;}
        button{background:#007bff;color:white;border:none;cursor:pointer;}
        .error{background:#f8d7da;color:#721c24;padding:10px;}
        .success{background:#d4edda;color:#155724;padding:10px;}
    </style>
</head>
<body>
<div class="container">
    <h2>دسته بندی جدید</h2>
    <?php if($error) echo "<div class='error'>$error</div>"; ?>
    <?php if($success) echo "<div class='success'>$success</div>"; ?>
    <form method="post">
        <input type="text" name="title" placeholder="عنوان دسته" required>
        <button type="submit">ذخیره</button>
    </form>
    <p><a href="dashboard.php">← بازگشت به پنل</a></p>
</div>
</body>
</html>