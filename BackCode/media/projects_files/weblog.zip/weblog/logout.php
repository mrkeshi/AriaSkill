<?php
require 'config.php';
session_destroy();
header('Location: login_register.php');
exit;
?>