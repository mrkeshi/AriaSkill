<?php
require 'config.php';
$cat_id = (int)($_GET['cat_id'] ?? 0);
$cat = $conn->query("SELECT title FROM categories WHERE id = $cat_id");
if ($cat->num_rows == 0) die('دسته بندی نامعتبر است.');
$cat_title = $cat->fetch_assoc()['title'];

$posts = $conn->query("
    SELECT p.id, p.title, p.created_at, u.first_name, u.last_name
    FROM posts p
    JOIN users u ON p.author_id = u.id
    JOIN post_category pc ON p.id = pc.post_id
    WHERE pc.category_id = $cat_id
    ORDER BY p.created_at DESC
");
?>
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($cat_title) ?></title>
    <style>
        body{font-family:Tahoma;background:#f0f2f5;margin:0;padding:20px;}
        table{width:100%;border-collapse:collapse;background:#fff;}
        th,td{border:1px solid #ddd;padding:10px;text-align:right;}
        th{background:#007bff;color:white;}
        a{text-decoration:none;color:#007bff;}
    </style>
</head>
<body>
<h2>پست‌های دسته: <?= htmlspecialchars($cat_title) ?></h2>
<?php if($posts->num_rows == 0): ?>
    <p>هیچ پستی در این دسته وجود ندارد.</p>
<?php else: ?>
    <table>
        <tr><th>عنوان پست</th><th>نویسنده</th><th>تاریخ درج</th></tr>
        <?php while($row = $posts->fetch_assoc()): ?>
            <tr>
                <td><a href="post.php?post_id=<?= $row['id'] ?>"><?= htmlspecialchars($row['title']) ?></a></td>
                <td><?= htmlspecialchars($row['first_name'] . ' ' . $row['last_name']) ?></td>
                <td><?= htmlspecialchars($row['created_at']) ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
<?php endif; ?>
<p><a href="index.php">← بازگشت به صفحه اصلی</a></p>
</body>
</html>