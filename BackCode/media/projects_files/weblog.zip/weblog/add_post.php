<?php
require 'config.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: login_register.php');
    exit;
}

$error = '';
$success = '';
$categories = $conn->query("SELECT * FROM categories ORDER BY title");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $selected_cats = $_POST['categories'] ?? [];

    if (empty($title) || empty($content)) {
        $error = 'عنوان و متن پست الزامی هستند.';
    } elseif (empty($selected_cats)) {
        $error = 'حداقل یک دسته را انتخاب کنید.';
    } else {
        $title = $conn->real_escape_string($title);
        $content = $conn->real_escape_string($content);
        $author_id = $_SESSION['user_id'];

        // آپلود تصویر
        $image_path = '';
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = 'uploads/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $new_name = time() . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
            $dest = $upload_dir . $new_name;
            if (move_uploaded_file($_FILES['image']['tmp_name'], $dest)) {
                $image_path = $dest;
            } else {
                $error = 'خطا در آپلود تصویر.';
            }
        }

        if (!$error) {
            $conn->query("INSERT INTO posts (title, content, image_path, author_id) VALUES ('$title', '$content', '$image_path', $author_id)");
            $post_id = $conn->insert_id;

            foreach ($selected_cats as $cat_id) {
                $cat_id = (int)$cat_id;
                $conn->query("INSERT INTO post_category (post_id, category_id) VALUES ($post_id, $cat_id)");
            }
            $success = 'پست با موفقیت اضافه شد.';
        }
    }
}
?>
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <title>نوشتن پست جدید</title>
    <style>
        body{font-family:Tahoma;background:#f0f2f5;margin:0;padding:20px;}
        .container{max-width:700px;margin:auto;background:#fff;padding:20px;border-radius:8px;}
        input,textarea,select,button{width:100%;padding:8px;margin:8px 0;border-radius:4px;border:1px solid #ccc;}
        button{background:#007bff;color:white;border:none;cursor:pointer;}
        .error{background:#f8d7da;color:#721c24;padding:10px;}
        .success{background:#d4edda;color:#155724;padding:10px;}
    </style>
</head>
<body>
<div class="container">
    <h2>ایجاد پست جدید</h2>
    <?php if($error) echo "<div class='error'>$error</div>"; ?>
    <?php if($success) echo "<div class='success'>$success</div>"; ?>
    <form method="post" enctype="multipart/form-data">
        <input type="text" name="title" placeholder="عنوان پست" required>
        <textarea name="content" placeholder="متن پست ..." rows="8" required></textarea>
        <label>تصویر (اختیاری):</label>
        <input type="file" name="image" accept="image/*">
        <label>دسته بندی ها (چند انتخاب):</label>
        <select name="categories[]" multiple size="5" required>
            <?php while($cat = $categories->fetch_assoc()): ?>
                <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['title']) ?></option>
            <?php endwhile; ?>
        </select>
        <button type="submit">انتشار پست</button>
    </form>
    <p><a href="dashboard.php">← بازگشت به پنل</a></p>
</div>
</body>
</html>