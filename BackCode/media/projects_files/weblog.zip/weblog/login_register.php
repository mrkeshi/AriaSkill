<?php
require 'config.php';

$error = '';
$old_first_name = '';
$old_last_name = '';

// ثبت نام
if (isset($_POST['register'])) {
    $first_name = $conn->real_escape_string(trim($_POST['first_name']));
    $last_name = $conn->real_escape_string(trim($_POST['last_name']));
    $email = $conn->real_escape_string(trim($_POST['email']));
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $check = $conn->query("SELECT id FROM users WHERE email = '$email'");
    if ($check->num_rows > 0) {
        $error = 'این ایمیل قبلاً ثبت شده است.';
        $old_first_name = $_POST['first_name'];
        $old_last_name = $_POST['last_name'];
    } else {
        $conn->query("INSERT INTO users (first_name, last_name, email, password) VALUES ('$first_name', '$last_name', '$email', '$password')");
        $_SESSION['user_id'] = $conn->insert_id;
        $_SESSION['user_name'] = $first_name . ' ' . $last_name;
        header('Location: dashboard.php');
        exit;
    }
}

// ورود
if (isset($_POST['login'])) {
    $email = $conn->real_escape_string(trim($_POST['email']));
    $password = $_POST['password'];

    $result = $conn->query("SELECT * FROM users WHERE email = '$email'");
    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
            header('Location: dashboard.php');
            exit;
        } else {
            $error = 'رمز عبور اشتباه است.';
        }
    } else {
        $error = 'ایمیل یافت نشد.';
    }
}
?>
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <title>ورود / ثبت نام</title>
    <style>
        body{font-family:Tahoma;background:#f0f2f5;margin:0;padding:20px;}
        .container{max-width:500px;margin:auto;background:#fff;padding:20px;border-radius:8px;}
        .form-box{margin-bottom:30px;border-bottom:1px solid #ddd;padding-bottom:20px;}
        input,button{width:100%;padding:8px;margin:8px 0;border:1px solid #ccc;border-radius:4px;}
        button{background:#007bff;color:white;border:none;cursor:pointer;}
        button:hover{background:#0056b3;}
        .error{background:#f8d7da;color:#721c24;padding:10px;border-radius:4px;margin:10px 0;}
    </style>
</head>
<body>
<div class="container">
    <div class="form-box">
        <h2>ثبت نام</h2>
        <?php if($error && isset($_POST['register'])) echo "<div class='error'>$error</div>"; ?>
        <form method="post">
            <input type="text" name="first_name" placeholder="نام" value="<?= htmlspecialchars($old_first_name) ?>" required>
            <input type="text" name="last_name" placeholder="نام خانوادگی" value="<?= htmlspecialchars($old_last_name) ?>" required>
            <input type="email" name="email" placeholder="ایمیل" required>
            <input type="password" name="password" placeholder="رمز عبور" required>
            <button type="submit" name="register">ثبت نام</button>
        </form>
    </div>
    <div class="form-box">
        <h2>ورود</h2>
        <?php if($error && isset($_POST['login'])) echo "<div class='error'>$error</div>"; ?>
        <form method="post">
            <input type="email" name="email" placeholder="ایمیل" required>
            <input type="password" name="password" placeholder="رمز عبور" required>
            <button type="submit" name="login">ورود</button>
        </form>
    </div>
</div>
</body>
</html>