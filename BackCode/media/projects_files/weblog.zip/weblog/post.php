<?php
require 'config.php';
$post_id = (int)($_GET['post_id'] ?? 0);
$post = $conn->query("
    SELECT p.*, u.first_name, u.last_name
    FROM posts p
    JOIN users u ON p.author_id = u.id
    WHERE p.id = $post_id
");
if ($post->num_rows == 0) die('پست یافت نشد.');
$post = $post->fetch_assoc();

$cats = $conn->query("
    SELECT c.id, c.title
    FROM categories c
    JOIN post_category pc ON c.id = pc.category_id
    WHERE pc.post_id = $post_id
");
?>
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($post['title']) ?></title>
    <style>
        body{font-family:Tahoma;background:#f0f2f5;margin:0;padding:20px;}
        article{max-width:800px;margin:auto;background:#fff;padding:20px;border-radius:8px;}
        .meta{color:#666;margin-bottom:20px;border-bottom:1px solid #eee;padding-bottom:10px;}
        .post-image img{max-width:100%;border-radius:8px;margin:15px 0;}
        .post-content{line-height:1.6;margin:20px 0;}
        .categories{margin-top:20px;padding:10px;background:#f0f2f5;border-radius:5px;}
        .categories a{margin-left:10px;background:#007bff;color:white;padding:5px 10px;border-radius:3px;text-decoration:none;}
    </style>
</head>
<body>
<article>
    <h1><?= htmlspecialchars($post['title']) ?></h1>
    <div class="meta">
        <span>نویسنده: <?= htmlspecialchars($post['first_name'] . ' ' . $post['last_name']) ?></span> |
        <span>تاریخ: <?= htmlspecialchars($post['created_at']) ?></span>
    </div>
    <?php if($post['image_path']): ?>
        <div class="post-image"><img src="<?= htmlspecialchars($post['image_path']) ?>" alt="تصویر پست"></div>
    <?php endif; ?>
    <div class="post-content"><?= nl2br(htmlspecialchars($post['content'])) ?></div>
    <div class="categories">
        <strong>دسته بندی‌ها:</strong>
        <?php while($cat = $cats->fetch_assoc()): ?>
            <a href="category.php?cat_id=<?= $cat['id'] ?>"><?= htmlspecialchars($cat['title']) ?></a>
        <?php endwhile; ?>
    </div>
</article>
<p style="text-align:center"><a href="index.php">← بازگشت به صفحه اصلی</a></p>
</body>
</html>