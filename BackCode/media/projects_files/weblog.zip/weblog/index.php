<?php require 'config.php';
$cats = $conn->query("SELECT * FROM categories ORDER BY title");
?>
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <title>وبلاگ من</title>
</head>
<body>
<h1>وبلاگ من</h1>
<?php if(isset($_SESSION['user_id'])): ?>
    <p>خوش آمدی <?= htmlspecialchars($_SESSION['user_name']) ?> | <a href="dashboard.php">پنل</a> | <a href="logout.php">خروج</a></p>
<?php else: ?>
    <p><a href="login_register.php">ورود / ثبت نام</a></p>
<?php endif; ?>

<h3>دسته‌بندی‌ها</h3>
<ul>
    <?php while($cat = $cats->fetch_assoc()): ?>
        <li><a href="category.php?cat_id=<?= $cat['id'] ?>"><?= htmlspecialchars($cat['title']) ?></a></li>
    <?php endwhile; ?>
</ul>
</body>
</html>