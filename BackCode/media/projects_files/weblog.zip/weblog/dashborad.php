<?php
require 'config.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: login_register.php');
    exit;
}
?>
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <title>پنل کاربری</title>
    <style>
        body{font-family:Tahoma;background:#f0f2f5;margin:0;padding:20px;}
        .dashboard{max-width:600px;margin:auto;background:#fff;padding:20px;border-radius:8px;text-align:center;}
        a{display:inline-block;margin:10px;padding:10px 15px;background:#007bff;color:white;text-decoration:none;border-radius:5px;}
        a:hover{background:#0056b3;}
        .logout{background:#dc3545;}
        .logout:hover{background:#c82333;}
    </style>
</head>
<body>
<div class="dashboard">
    <h2>سلام <?= htmlspecialchars($_SESSION['user_name']) ?>!</h2>
    <a href="add_category.php">➕ دسته بندی جدید</a>
    <a href="add_post.php">📝 نوشتن پست جدید</a>
    <a href="logout.php" class="logout">🚪 خروج از پنل</a>
    <p><a href="index.php">← بازگشت به صفحه اصلی</a></p>
</div>
</body>
</html>