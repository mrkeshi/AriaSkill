import django.utils.timezone
from django.db import migrations, models


class Migration(migrations.Migration):
    """
    Add created_at and updated_at to the Project model.
    The initial migration (0001_initial) did not include these fields,
    even though the model defines them. This migration adds them properly.
    """

    dependencies = [
        ('projects', '0004_project_file'),
    ]

    operations = [
        migrations.AddField(
            model_name='project',
            name='created_at',
            field=models.DateTimeField(auto_now_add=True, default=django.utils.timezone.now),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='project',
            name='updated_at',
            field=models.DateTimeField(auto_now=True),
        ),
    ]
