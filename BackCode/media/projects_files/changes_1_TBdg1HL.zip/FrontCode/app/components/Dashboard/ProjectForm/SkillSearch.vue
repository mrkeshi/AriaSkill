<template>
  <div class="space-y-3">
    <div class="flex items-center justify-between">
      <label class="text-sm font-medium text-gray-300">مهارت‌ها</label>
      <span v-if="selectedSkills.length" class="text-xs text-classic-gold bg-classic-gold/10 border border-classic-gold/20 px-2 py-0.5 rounded-full">
        {{ selectedSkills.length }} مورد انتخاب شده
      </span>
    </div>

    <div class="rounded-xl border border-white/10 bg-white/5 overflow-hidden">
      <!-- Search input -->
      <div class="relative border-b border-white/10">
        <Icon name="mdi:magnify" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 text-lg pointer-events-none" />
        <input
          v-model.trim="searchQuery"
          type="text"
          class="w-full bg-transparent pr-10 pl-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none"
          placeholder="جستجوی مهارت..."
          autocomplete="off"
        >
      </div>

      <!-- Selected chips -->
      <div v-if="selectedSkills.length" class="flex flex-wrap gap-2 p-3 border-b border-white/10 bg-classic-gold/5">
        <button
          v-for="skill in selectedSkills"
          :key="skill.id"
          type="button"
          class="inline-flex items-center gap-1.5 rounded-lg border border-classic-gold/40 bg-classic-gold/15 px-2.5 py-1.5 text-xs text-classic-gold transition hover:bg-rose-500/15 hover:border-rose-500/40 hover:text-rose-400 group"
          :title="`حذف ${skill.name}`"
          @click="$emit('toggle', skill)"
        >
          <img v-if="skill.icon" :src="resolveMediaUrl(skill.icon)" class="h-4 w-4 object-contain" alt="">
          <span>{{ skill.name }}</span>
          <Icon name="mdi:close" class="text-xs group-hover:text-rose-400" />
        </button>
      </div>

      <!-- Skill list -->
      <div class="max-h-52 overflow-y-auto custom-skill-scrollbar">
        <!-- Loading -->
        <div v-if="loading" class="py-6 text-center text-sm text-gray-500 flex items-center justify-center gap-2">
          <Icon name="mdi:loading" class="animate-spin text-classic-gold" />
          <span>در حال دریافت مهارت‌ها...</span>
        </div>

        <!-- Empty -->
        <div v-else-if="skills.length === 0" class="py-6 text-center text-sm text-gray-500">
          <Icon name="mdi:emoticon-sad-outline" class="text-2xl mb-1 block mx-auto text-gray-600" />
          مهارتی پیدا نشد.
        </div>

        <!-- List -->
        <div v-else class="p-3 grid grid-cols-2 sm:grid-cols-3 gap-2">
          <button
            v-for="skill in skills"
            :key="skill.id"
            type="button"
            class="flex items-center gap-2 rounded-lg border px-3 py-2 text-xs transition text-right"
            :class="isSelected(skill.id)
              ? 'border-classic-gold/50 bg-classic-gold/15 text-classic-gold shadow-sm'
              : 'border-white/10 bg-white/5 text-gray-300 hover:bg-white/10 hover:border-white/20'"
            @click="$emit('toggle', skill)"
          >
            <img v-if="skill.icon" :src="resolveMediaUrl(skill.icon)" class="h-4 w-4 object-contain flex-shrink-0" alt="">
            <span class="truncate">{{ skill.name }}</span>
            <Icon v-if="isSelected(skill.id)" name="mdi:check" class="text-classic-gold mr-auto flex-shrink-0 text-xs" />
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, watch, onBeforeUnmount } from 'vue'
import type { skillItem } from '~/models/Skill/SkillDTO'
import { getSkillsService } from '~/services/skills/skills.Service'
import { resolveMediaUrl } from '~/utilities/urlHelpers'

const props = defineProps<{
  selectedSkills: skillItem[]
}>()

defineEmits<{
  toggle: [skill: skillItem]
}>()

const searchQuery = ref('')
const skills = ref<skillItem[]>([])
const loading = ref(false)
let debounceTimer: ReturnType<typeof setTimeout> | null = null

const isSelected = (id: number) => props.selectedSkills.some(s => s.id === id)

const loadSkills = async () => {
  loading.value = true
  try {
    const res = await getSkillsService(1, searchQuery.value)
    skills.value = res.data?.results ?? []
  } finally {
    loading.value = false
  }
}

watch(searchQuery, () => {
  if (debounceTimer) clearTimeout(debounceTimer)
  debounceTimer = setTimeout(loadSkills, 280)
}, { immediate: true })

onBeforeUnmount(() => {
  if (debounceTimer) clearTimeout(debounceTimer)
})
</script>

<style scoped>
.custom-skill-scrollbar::-webkit-scrollbar {
  width: 4px;
}
.custom-skill-scrollbar::-webkit-scrollbar-track {
  background: transparent;
}
.custom-skill-scrollbar::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.12);
  border-radius: 999px;
}
.custom-skill-scrollbar::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.22);
}
</style>
