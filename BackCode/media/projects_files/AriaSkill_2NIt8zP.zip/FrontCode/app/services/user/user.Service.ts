import type { ApiResponse } from "~/models/ApiResponseDTO";
import type {
  ActiveUserDTO,
  AuthUserDTO,
  ChangePasswordDTO,
  LoginDTO,
  RefTokenDTO,
} from "~/models/User/AuthDTO";
import type { RegisterDTO } from "~/models/User/AuthDTO";
import type { EditUserDTO } from "~/models/User/EditUserDTO";
import type { UserDTO } from "~/models/User/UserDTO";
import { FetchX } from "~/utilities/fetchX";

export const registerUserService = (data: RegisterDTO): Promise<ApiResponse<null>> => {
  return FetchX("account/register/", {
    method: "post",
    body: data,
  });
};

export const LoginUserService = (data: LoginDTO): Promise<ApiResponse<AuthUserDTO>> => {
  return FetchX("account/login/", {
    method: "post",
    body: data,
  });
};

export const googleAuthService = (credential: string): Promise<ApiResponse<AuthUserDTO>> => {
  return FetchX("account/google/", {
    method: "post",
    body: { credential },
  });
};

// ─── BUG FIX ──────────────────────────────────────────────────────────────
// refreshTokenService uses FetchX. If the refresh endpoint itself returns 401,
// FetchX would try to refresh again → infinite recursion.
//
// Passing `true` as the third argument (_isRefreshCall) tells FetchX to skip
// the 401-retry block for this specific call, breaking the loop.
// ───────────────────────────────────────────────────────────────────────────
export const refreshTokenService = (ref: string | null): Promise<ApiResponse<RefTokenDTO>> => {
  return FetchX(
    "account/token/refresh/",
    {
      method: "post",
      body: { refresh: ref },
    },
    true  // ← _isRefreshCall: disables 401-retry inside FetchX for this call
  );
};

export const sendResetLinkPassService = (email: string): Promise<ApiResponse<{ message: string }>> => {
  return FetchX("account/password_reset/request/", {
    method: "POST",
    body: { email },
  });
};

export const changePasswordService = (data: ChangePasswordDTO): Promise<ApiResponse<null>> => {
  return FetchX("account/password_reset/confirm/", {
    method: "POST",
    body: data,
  });
};

export const activeUserService = (data: ActiveUserDTO): Promise<ApiResponse<null>> => {
  return FetchX("account/register/activate/", {
    method: "POST",
    body: data,
  });
};

export const fetchUserService = (): Promise<ApiResponse<UserDTO>> => {
  return FetchX("account/profile/", {
    method: "GET",
  });
};

export const getEditUserService = (): Promise<ApiResponse<EditUserDTO>> => {
  return FetchX("account/profile/", {
    method: "GET",
  });
};

export const editUserService = (data: FormData): Promise<ApiResponse<EditUserDTO>> => {
  return FetchX("account/profile/edit/", {
    method: "PATCH",
    body: data,
  });
};
