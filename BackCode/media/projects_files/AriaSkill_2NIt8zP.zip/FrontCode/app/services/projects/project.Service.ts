import type { ApiResponse } from '~/models/ApiResponseDTO'
import type { CommentDTO, CommentListDTO, CommentManagementDTO, ProjectCommentListDTO, SendCommentDTO } from '~/models/Comment/SendCommentDTO'
import type { ProjectDTO, ProjectListDTO } from '~/models/Project/ProjectDTO'
import { FetchX } from '~/utilities/fetchX'

export const getMyProjectsService = (page = 1): Promise<ApiResponse<ProjectListDTO>> => {
  return FetchX('project/', {
    method: 'get',
    query: { page },
  })
}

export const getPublicProjectsService = (page = 1, pageSize = 6): Promise<ApiResponse<ProjectListDTO>> => {
  return FetchX('project/projects/public/', {
    method: 'get',
    query: { page, page_size: pageSize },
  })
}

export const createProjectService = (data: FormData): Promise<ApiResponse<ProjectDTO>> => {
  return FetchX('project/', {
    method: 'post',
    body: data,
  })
}

export const retrieveProjectService = (slug: string): Promise<ApiResponse<ProjectDTO>> => {
  return FetchX(`project/${slug}/`, {
    method: 'get',
  })
}

export const likeProjectService = (slug: string): Promise<ApiResponse<{ likes_count: number; liked: boolean }>> => {
  return FetchX(`project/${slug}/like/`, {
    method: 'post',
  })
}

export const unlikeProjectService = (slug: string): Promise<ApiResponse<{ likes_count: number; liked: boolean }>> => {
  return FetchX(`project/${slug}/unlike/`, {
    method: 'post',
  })
}

export const downloadProjectService = (slug: string): Promise<ApiResponse<{ download_count: number }>> => {
  return FetchX(`project/${slug}/download/`, {
    method: 'post',
  })
}

export const getProjectCommentsService = (projectId: number, page = 1): Promise<ApiResponse<ProjectCommentListDTO | CommentDTO[]>> => {
  return FetchX(`project/${projectId}/comments/`, {
    method: 'get',
    query: { page },
  })
}

export const sendProjectCommentService = (projectId: number, data: Pick<SendCommentDTO, 'message' | 'parent'>): Promise<ApiResponse<CommentDTO>> => {
  return FetchX(`project/${projectId}/comments/`, {
    method: 'post',
    body: {
      project: projectId,
      ...data,
    },
  })
}

export const getMyProjectCommentsService = (page = 1): Promise<ApiResponse<CommentListDTO>> => {
  return FetchX('project/comments/my-projects/', {
    method: 'get',
    query: { page },
  })
}

export const updateMyProjectCommentStatusService = (
  id: number,
  status: 'pending' | 'approved' | 'rejected',
): Promise<ApiResponse<CommentManagementDTO>> => {
  return FetchX(`project/comments/my-projects/${id}/`, {
    method: 'patch',
    body: { status },
  })
}

export const deleteMyProjectCommentService = (id: number): Promise<ApiResponse<null>> => {
  return FetchX(`project/comments/my-projects/${id}/`, {
    method: 'delete',
  })
}

export const updateProjectService = (slug: string, data: FormData): Promise<ApiResponse<ProjectDTO>> => {
  return FetchX(`project/${slug}/`, {
    method: 'patch',
    body: data,
  })
}

export const deleteProjectService = (slug: string): Promise<ApiResponse<null>> => {
  return FetchX(`project/${slug}/`, {
    method: 'delete',
  })
}
