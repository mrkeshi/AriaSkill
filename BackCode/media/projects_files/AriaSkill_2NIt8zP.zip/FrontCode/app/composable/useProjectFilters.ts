import type { FilterProjectDTO,ProjectCategory,FilterSort } from "~/models/Project/FilterProjectDTO"

export const useProjectFilters = () => {
  const route = useRoute()
  const router = useRouter()

  const filters = reactive<FilterProjectDTO>({
    page: 1,
    category: [],
    years: [],
    q: '',
    sort:'new',
    technology: []
  })

  const toggleItem = <T>(arr: T[], item: T) => {
    const index = arr.indexOf(item)
    if (index === -1) arr.push(item)
    else arr.splice(index, 1)
  }

  const toggleTechnology = (slug: string) => {
    toggleItem(filters.technology as string[], slug)
  }
   const toggleYears = (years: number) => {
    toggleItem(filters.years as number[], years)
  }
    const toggleCategory = (cat: ProjectCategory) => {
    toggleItem(filters.category as ProjectCategory[], cat)
  }

  const applyFilter = (): FilterProjectDTO => {
    router.replace({
      query: {
        ...route.query,
        q: filters.q || undefined,
      }
    })

    return {
      q: filters.q,
      technology: filters.technology
    }
  }

  const readFromQuery = () => {
    filters.q = Array.isArray(route.query.q)
      ? route.query.q[0]
      : (route.query.q ?? '')
  }

  const resetSearch = () => {
    filters.q = ''
    applyFilter()
  }

  onBeforeMount(readFromQuery)

  return {
    filters,
    applyFilter,
    resetSearch,
    toggleTechnology,
    toggleYears,
    toggleCategory
  }
}
