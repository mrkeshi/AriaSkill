
export interface UserDTO{
    username:string,
    email:string,
    first_name:string,
    last_name:string,
    avatar:null | string,
    is_staff:boolean,
    is_superuser:boolean,
}
export interface UserSummaryDTO{
    username:string
    id:number
    full_name:string,
    avatar:string
}
