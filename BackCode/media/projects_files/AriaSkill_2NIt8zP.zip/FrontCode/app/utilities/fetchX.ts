import type { NitroFetchOptions } from "nitropack";
import type { ApiResponse } from "~/models/ApiResponseDTO";
import { baseURL as BASE_URL } from "./ApiConfig";

// ─── BUG FIX #1 ────────────────────────────────────────────────────────────
// useCustomToastify() and useAuthStore() were called at MODULE LEVEL (outside
// any function). In Nuxt, composables that rely on the Vue/Nuxt context MUST
// be called inside a function that runs inside that context (a setup(), a
// plugin, a composable, or an async function triggered from one of those).
//
// Calling them at module-level means they run once when the module is first
// imported — before any Nuxt context exists — which throws:
//   "Maximum call stack size exceeded"  /  "Nuxt instance unavailable"
//
// FIX: move both calls inside FetchX() so they execute with a live context.
// ───────────────────────────────────────────────────────────────────────────

// ─── BUG FIX #2 ────────────────────────────────────────────────────────────
// refreshTokenService() itself calls FetchX(). If the refresh request returns
// 401, FetchX catches it, calls tryRefreshToken() again, which calls
// refreshTokenService(), which calls FetchX() … → infinite recursion.
//
// FIX: pass an optional `_isRefreshCall` flag. When true, FetchX skips the
// 401-retry block entirely, so a failed refresh just propagates the error
// without recursing.
// ───────────────────────────────────────────────────────────────────────────

export async function FetchX<T>(
  url: string,
  config: NitroFetchOptions<string> = {},
  _isRefreshCall = false   // ← internal flag; callers never set this
): Promise<ApiResponse<T>> {

  // Composables called INSIDE the function — safe in any Nuxt context.
  const { showError } = useCustomToastify();
  const authStore = useAuthStore();
  const accessTokenCookie = useCookie<string | null>("accessToken");

  config = {
    baseURL: BASE_URL,
    ...config,
    headers: {
      ...(config.headers || {}),
    },
  };

  if (accessTokenCookie.value) {
    (config.headers as Record<string, string>)["Authorization"] =
      `JWT ${accessTokenCookie.value}`;
  }

  try {
    return await $fetch<ApiResponse<T>>(url, config);
  } catch (e: any) {

    // Only attempt token refresh for non-refresh calls that get a 401.
    if (e.response?.status === 401 && !_isRefreshCall) {
      const isRefreshed = await authStore.tryRefreshToken();

      if (isRefreshed) {
        // Retry the original request with the new token.
        (config.headers as Record<string, string>)["Authorization"] =
          `JWT ${accessTokenCookie.value}`;
        return await $fetch<ApiResponse<T>>(url, config);
      } else {
        // Refresh failed — clear session without looping back into FetchX.
        authStore.logout();
      }
    }

    // ── Error toasts ──────────────────────────────────────────────────────
    const errors = e?.data?.errors;

    if (!errors) {
      showError({
        title: "خطا",
        message: e?.message || "خطای نامشخص",
      });
    } else if (typeof errors === "string") {
      showError({
        title: "خطا",
        message: errors,
      });
    } else if (typeof errors === "object") {
      Object.entries(errors).forEach(([key, value]) => {
        showError({
          title: "خطا",
          message: `${key}: ${value}`,
        });
      });
    }

    throw e;
  }
}
