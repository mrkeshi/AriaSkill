/**
 * dateHelpers.ts
 *
 * Jalali / Shamsi date utilities + Persian numeral converter + Iran-timezone greeting.
 *
 * Strategy: use the browser-native `Intl.DateTimeFormat` with
 * `calendar: 'persian'` and `numberingSystem: 'latn'` (Latin digits).
 * This requires zero external dependencies and is consistent with how
 * the project already uses Intl for locale formatting.
 */

// ─── Persian numeral map ───────────────────────────────────────────────────

const LATIN_TO_PERSIAN: Record<string, string> = {
  '0': '۰',
  '1': '۱',
  '2': '۲',
  '3': '۳',
  '4': '۴',
  '5': '۵',
  '6': '۶',
  '7': '۷',
  '8': '۸',
  '9': '۹',
}

/**
 * Convert all Latin/ASCII digit characters in a string to Persian numerals.
 * Non-digit characters are left unchanged.
 *
 * @example toPersianNumerals('123') // '۱۲۳'
 * @example toPersianNumerals('24 پروژه') // '۲۴ پروژه'
 */
export const toPersianNumerals = (value: string | number | null | undefined): string => {
  if (value === null || value === undefined) return ''
  return String(value).replace(/[0-9]/g, (d) => LATIN_TO_PERSIAN[d] ?? d)
}

// ─── Jalali month names (Persian) ──────────────────────────────────────────

const PERSIAN_MONTHS: readonly string[] = [
  'فروردین',
  'اردیبهشت',
  'خرداد',
  'تیر',
  'مرداد',
  'شهریور',
  'مهر',
  'آبان',
  'آذر',
  'دی',
  'بهمن',
  'اسفند',
]

// ─── Intl formatters (latin digits; we convert to Persian afterwards) ───────

const persianFormatter = new Intl.DateTimeFormat('fa-IR', {
  calendar: 'persian',
  numberingSystem: 'latn',
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
})

// ─── Public helpers ─────────────────────────────────────────────────────────

/**
 * Convert an ISO 8601 date string (or Date object) to a short Jalali
 * date string with Persian numerals, e.g. `۱۴۰۳/۰۹/۱۵`.
 *
 * Returns `'-'` for null / undefined / invalid input.
 */
export const toJalali = (value?: string | Date | null): string => {
  if (!value) return '-'
  const date = value instanceof Date ? value : new Date(value)
  if (isNaN(date.getTime())) return '-'
  return toPersianNumerals(persianFormatter.format(date))
}

/**
 * Convert an ISO 8601 date string (or Date object) to a long Jalali
 * date string with a Persian month name and Persian numerals,
 * e.g. `۱۲ اسفند ۱۴۰۵`.
 *
 * Returns `'-'` for null / undefined / invalid input.
 */
export const toJalaliLong = (value?: string | Date | null): string => {
  if (!value) return '-'
  const date = value instanceof Date ? value : new Date(value)
  if (isNaN(date.getTime())) return '-'

  // Use Intl to extract year / month index / day in the Persian calendar
  const parts = new Intl.DateTimeFormat('fa-IR', {
    calendar: 'persian',
    numberingSystem: 'latn',
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
  }).formatToParts(date)

  const get = (type: string) => parts.find((p) => p.type === type)?.value ?? ''

  const day = get('day')
  const monthIndex = parseInt(get('month'), 10) - 1
  const year = get('year')
  const monthName = PERSIAN_MONTHS[monthIndex] ?? ''

  // Format: "۱۲ اسفند ۱۴۰۵"
  return `${toPersianNumerals(day)} ${monthName} ${toPersianNumerals(year)}`
}

// ─── Iran-timezone greeting ─────────────────────────────────────────────────

/**
 * Returns a Persian greeting string based on the current hour in
 * Iran Standard Time (Asia/Tehran, UTC+3:30 / UTC+4:30 DST).
 *
 * Ranges:
 *   00:00 – 11:59  →  صبح بخیر
 *   12:00 – 13:59  →  ظهر بخیر
 *   14:00 – 20:59  →  عصر بخیر
 *   21:00 – 23:59  →  شب بخیر
 */
export const getIranGreeting = (): string => {
  const iranTimeStr = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Asia/Tehran',
    hour: 'numeric',
    hour12: false,
  }).format(new Date())

  const hour = parseInt(iranTimeStr, 10)

  if (hour < 12) return 'صبح بخیر،'
  if (hour < 14) return 'ظهر بخیر،'
  if (hour < 21) return 'عصر بخیر،'
  return 'شب بخیر،'
}
