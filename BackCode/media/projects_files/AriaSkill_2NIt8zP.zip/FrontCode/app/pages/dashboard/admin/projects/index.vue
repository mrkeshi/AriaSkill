<script setup lang="ts">
definePageMeta({ layout: 'dashboard' })
await navigateTo('/dashboard/projects')
</script>
