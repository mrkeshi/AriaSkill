<template>
  <UiCardBlury>
    <!-- Header & Tabs -->
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-5 gap-3">
      <h2 class="text-base font-bold text-white tracking-wide">اعلان‌ها</h2>

      <!-- Tabs -->
      <div class="flex p-0.5 bg-black/30 rounded-lg border border-white/10 backdrop-blur-sm">
        <button 
          @click="activeTab = 'unread'"
          :class="['px-4 py-1.5 rounded-md text-sm font-medium transition-all duration-200', 
            activeTab === 'unread' ? 'bg-white/15 text-white shadow-lg' : 'text-gray-400 hover:text-gray-200']"
        >
          نخوانده شده
          <span v-if="unreadCount > 0" class="mr-1.5 px-1.5 py-0.5 rounded-full bg-indigo-500 text-white text-[11px] font-bold">
            {{ unreadCount }}
          </span>
        </button>
        
        <button 
          @click="activeTab = 'read'"
          :class="['px-4 py-1.5 rounded-md text-sm font-medium transition-all duration-200', 
            activeTab === 'read' ? 'bg-white/15 text-white shadow-lg' : 'text-gray-400 hover:text-gray-200']"
        >
          خوانده شده
        </button>
      </div>
    </div>

    <!-- Notification List -->
    <div class="flex flex-col gap-2">
      
      <!-- Empty State -->
      <div v-if="filteredNotifications.length === 0" class="flex flex-col items-center justify-center py-8 text-gray-500">
        <Icon name="mdi:bell-sleep-outline" class="text-3xl mb-2 opacity-40" />
        <p class="text-sm">هیچ اعلانی در این بخش وجود ندارد.</p>
      </div>

      <!-- List Items -->
      <div 
        v-for="item in filteredNotifications" 
        :key="item.id"
        class="group flex items-center gap-2.5 p-2.5 rounded-lg border transition-all duration-200 backdrop-blur-md hover:scale-[1.01]"
        :class="[
          item.isRead 
            ? 'bg-white/5 border-white/5 opacity-50 hover:opacity-80' 
            : 'bg-gradient-to-r from-white/10 to-white/5 border-white/10 hover:border-white/20 shadow-md'
        ]"
      >
        <!-- Icon -->
        <div class="shrink-0 flex items-center justify-center w-9 h-9 rounded-lg border"
             :class="getTypeStyle(item.type).bgClass">
          <Icon :name="getTypeStyle(item.type).icon" class="text-lg" />
        </div>

        <!-- Content -->
        <div class="flex-grow min-w-0">
          <div class="flex items-center justify-between gap-2 mb-0.5">
            <h3 class="text-sm text-gray-100 font-semibold truncate">{{ item.title }}</h3>
            <span class="text-[11px] text-gray-500 whitespace-nowrap">{{ item.date }}</span>
          </div>
          <p class="text-[12px] text-gray-400 leading-relaxed line-clamp-1">{{ item.message }}</p>
        </div>

        <!-- Actions -->
        <div class="shrink-0 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
          <button 
            v-if="!item.isRead"
            @click="markAsRead(item.id)"
            title="علامت‌گذاری به عنوان خوانده شده" 
            class="p-1.5 rounded-md bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/30 transition-colors"
          >
            <Icon name="mdi:check-all" class="text-sm" />
          </button>
          
          <button 
            title="حذف" 
            class="p-1.5 rounded-md bg-rose-500/20 text-rose-400 border border-rose-500/30 hover:bg-rose-500/30 transition-colors"
          >
            <Icon name="mdi:trash-can-outline" class="text-sm" />
          </button>
        </div>
      </div>

    </div>

  </UiCardBlury>
</template>

<script setup>
definePageMeta({
  layout:'dashboard'
})

const seo = generateSeoMeta({
      title: `مدیریت نوتفیکیشن‌ها`,
      description: 'در ایند',
      image: "",
      url: ``,
      keywords: ["افزودن پروژه"],
      author:"علیرضا کشاورز",
      type: 'website'
    })
    useHead(seo)
import { ref, computed } from 'vue';
import { generateSeoMeta } from '~/utilities/seo';

const activeTab = ref('unread');

const notifications = ref([
  {
    id: 1,
    type: 'comment',
    title: 'نظر جدید در پروژه',
    message: '«محمد رضایی» برای پروژه «سلام زندگی» نظر جدیدی ثبت کرد.',
    date: '۱۰ دقیقه پیش',
    isRead: false
  },
  {
    id: 2,
    type: 'login',
    title: 'ورود به حساب کاربری',
    message: 'یک ورود موفق از دستگاه Windows (Chrome) در تهران ثبت شد.',
    date: '۱ ساعت پیش',
    isRead: false
  },
  {
    id: 3,
    type: 'update',
    title: 'تغییرات جدید سایت',
    message: 'نسخه ۲.۴ سایت منتشر شد. بخش فروشگاه به‌روزرسانی شده است.',
    date: '۳ ساعت پیش',
    isRead: false
  },
  {
    id: 4,
    type: 'success',
    title: 'خرید موفقیت‌آمیز',
    message: 'اشتراک یک‌ماهه شما با موفقیت فعال شد.',
    date: 'دیروز',
    isRead: false
  },
  {
    id: 5,
    type: 'warning',
    title: 'هشدار امنیتی',
    message: 'تلاش ناموفق برای ورود به حساب کاربری شما ثبت شده است.',
    date: '۲ روز پیش',
    isRead: true
  },
  {
    id: 6,
    type: 'danger',
    title: 'خطا در ارتباط با سرور',
    message: 'بک‌آپ‌گیری روزانه با خطا مواجه شد. لطفا بررسی کنید.',
    date: 'هفته پیش',
    isRead: true
  }
]);

const filteredNotifications = computed(() => {
  return notifications.value.filter(item => 
    activeTab.value === 'unread' ? !item.isRead : item.isRead
  );
});

const unreadCount = computed(() => {
  return notifications.value.filter(item => !item.isRead).length;
});

const getTypeStyle = (type) => {
  const styles = {
    comment: {
      bgClass: 'bg-fuchsia-500/15 text-fuchsia-400 border-fuchsia-500/20',
      icon: 'mdi:comment-text-outline'
    },
    login: {
      bgClass: 'bg-indigo-500/15 text-indigo-400 border-indigo-500/20',
      icon: 'mdi:shield-account-outline'
    },
    update: {
      bgClass: 'bg-cyan-500/15 text-cyan-400 border-cyan-500/20',
      icon: 'mdi:rocket-launch-outline'
    },
    success: {
      bgClass: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/20',
      icon: 'mdi:check-circle-outline'
    },
    warning: {
      bgClass: 'bg-amber-500/15 text-amber-400 border-amber-500/20',
      icon: 'mdi:alert-outline'
    },
    danger: {
      bgClass: 'bg-rose-500/15 text-rose-400 border-rose-500/20',
      icon: 'mdi:close-circle-outline'
    },
    info: {
      bgClass: 'bg-blue-500/15 text-blue-400 border-blue-500/20',
      icon: 'mdi:information-outline'
    }
  };
  return styles[type] || styles.info;
};

const markAsRead = (id) => {
  const index = notifications.value.findIndex(n => n.id === id);
  if (index !== -1) {
    notifications.value[index].isRead = true;
  }
};
</script>
