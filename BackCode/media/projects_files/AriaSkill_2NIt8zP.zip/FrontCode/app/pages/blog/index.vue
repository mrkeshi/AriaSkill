<template>
  <UiCardBlury class="min-h-[60vh] mt-6 lg:mt-12 flex flex-col items-center justify-center text-center">
    <!-- آیکون و افکت درخشش -->
    <div class="relative group mb-8">
      <div class="absolute -inset-2 bg-classic-gold rounded-full blur opacity-20 animate-pulse"></div>
      <div class="relative bg-white/10 border border-white/20 p-6 rounded-full shadow-2xl backdrop-blur-sm">
        <Icon name="mdi:fountain-pen-tip" class="text-6xl text-classic-gold" />
      </div>
    </div>

    <!-- متن‌ها -->
    <h1 class="text-3xl md:text-4xl font-bold text-white mb-4">
      بخش <span class="text-classic-gold">وبلاگ</span>
    </h1>
    <h2 class="text-xl text-gray-300 font-medium mb-4">
      به زودی آماده می‌شود...
    </h2>
    <p class="text-gray-400 max-w-md mx-auto text-sm leading-relaxed">
      ما در حال آماده‌سازی مقالات و محتوای جذاب برای شما هستیم. به زودی با مطالب جدید برمی‌گردیم!
    </p>

    <!-- نوار پیشرفت تزئینی -->
    <div class="w-64 h-1.5 bg-white/10 rounded-full mt-8 overflow-hidden">
      <div class="h-full bg-classic-gold w-1/3 rounded-full animate-[pulse_2s_ease-in-out_infinite]"></div>
    </div>
  </UiCardBlury>
</template>

<script setup>
import { generateSeoMeta } from '~/utilities/seo';

const seo = generateSeoMeta({
      title: `وبلاگ`,
      description: 'در ایند',
      image: "",
      url: ``,
      keywords: ["افزودن پروژه"],
      author:"علیرضا کشاورز",
      type: 'website'
    })
    useHead(seo)
</script>

<style scoped>
.bg-classic-gold { background-color: #D4AF37; }
.text-classic-gold { color: #D4AF37; }
</style>
