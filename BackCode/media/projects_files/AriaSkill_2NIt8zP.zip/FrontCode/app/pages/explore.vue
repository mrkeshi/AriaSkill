<template>
  <div>
    <SectionsHeroProject></SectionsHeroProject>
    <SectionsStats></SectionsStats>
  </div>
</template>

<script lang="ts" setup>
import { SectionsStats } from '#components';
import { generateSeoMeta } from '~/utilities/seo';


const seo = generateSeoMeta({
      title: `جستجو در پروژه‌ها`,
      description: 'در ایند',
      image: "",
      url: ``,
      keywords: ["افزودن پروژه"],
      author:"علیرضا کشاورز",
      type: 'website'
    })
    useHead(seo)

</script>

<style>

</style>