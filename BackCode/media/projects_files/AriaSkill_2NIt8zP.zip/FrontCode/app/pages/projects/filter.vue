<template>
  <div class="grid grid-cols-1 min-h-screen lg:grid-cols-3 gap-8 py-8 lg:py-24">
    

    <div class="space-y-5">

  
<ProjectFiltersBoxResult :tog :filters="filters" :toggleTechnology=toggleTechnology 
:resetSearch="resetSearch" :toggle-category :toggleYears></ProjectFiltersBoxResult>

<ProjectFiltersTechnology :filters="filters" :toggleTechnology=toggleTechnology></ProjectFiltersTechnology>

<ProjectFiltersYears :filters :toggleYears="toggleYears"></ProjectFiltersYears>

  <ProjectFiltersSearch :filters="filters" :apply-filter="applyFilter"></ProjectFiltersSearch>

<ProjectFiltersCategory :filters :toggle-category></ProjectFiltersCategory>


      <div class="text-left">
        <ui-button w-full>فیلترکردن نتایج</ui-button>
      </div>
    </div>

    <div class="lg:col-span-2">
      <div class="flex flex-col space-y-0">
        
        <ProjectFiltersSort :filters></ProjectFiltersSort>
        <SkeletonSimple v-if="pending" :repeat="6" class="h-32 mb-3" />
        <ProjectContainer v-else lg-grid="2" min :projects="projects" />
        <UiPagination :totalPages="totalPages" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { useProjectFilters } from '~/composable/useProjectFilters'
import { getPublicProjectsService } from '~/services/projects/project.Service'
import { generateSeoMeta } from '~/utilities/seo'


const {filters,applyFilter,resetSearch,toggleTechnology,toggleYears,toggleCategory}=useProjectFilters()
const route = useRoute()
const currentPage = computed(() => Number(route.query.page) || 1)

const { data, pending } = await useAsyncData(
  'public-projects',
  () => getPublicProjectsService(currentPage.value, 6),
  { watch: [currentPage] },
)

const projects = computed(() => data.value?.data?.results ?? [])
const totalPages = computed(() => Math.ceil((data.value?.data?.count ?? 0) / 6))
const seo = generateSeoMeta({
      title: `فیلترکردن پروژه‌ها`,
      description: 'در ایند',
      image: "",
      url: ``,
      keywords: ["افزودن پروژه"],
      author:"علیرضا کشاورز",
      type: 'website'
    })
    useHead(seo)



</script>
