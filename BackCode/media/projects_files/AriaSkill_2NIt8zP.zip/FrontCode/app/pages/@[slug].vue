<template>
<div class="flex flex-col relative mt-20 h-auto max-md:mt-10 lg:mx-10">
  <div class="relative profile-container">
  <img src="/images/bg-prof.jpg" class="w-full bg-prof max-lg:hidden rounded-2xl h-auto shadow-2xl transition ease-in hover:shadow-light-gold/20 hover:border-classic-gold border-2 border-transparent" alt="">
  <div class=" flex items-center lg:absolute gap-8 max-lg:flex-col max-lg:justify-center -bottom-14 right-16 ">
 <img src="/images/user1.jpg" class="rounded-full prof-user shadow-light-gold/10 shad z-10 max-lg:w-48 max-lg:h-48 shadow-2xl border-2  w-60 h-60 ease-in  transition" alt="">
 <div class="max-lg:text-center">
 <FooterSocialLink is-white="true"></FooterSocialLink>
 <h2 class="text-bone-white font-bold mt-3 mb-1 text-2xl max-lg:text-xl font-pelak l ">علیرضا کشاورز</h2>
 <h3 class="text-light-gold mb-4">ui desighner</h3>
 </div>
  </div>


  </div>
  <div class="backdrop-blur-md shadow-2xl hover:border-classic-gold  hover:shadow-light-gold/20 lg:mt-14 leading-8 bg-carb-gray/10 border border-light-gold/5 rounded-2xl p-4">
<p class="text-bone-white text-justify lg:p-4">"
  لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک است، چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است، و برای شرایط فعلی تکنولوژی مورد نیاز، و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد، کتابهای زیادی در شصت و سه درصد گذشته حال و آینده، شناخت فراوان جامعه و متخصصان را می طلبد، تا با نرم افزارها شناخت بیشتری را برای طراحان رایانه ای علی الخصوص طراحان خلائه راهکارها، و شرایط سخت تایپ به پایاقرار گیرد.
"</p>

</div>
<!-- Stats Boxes -->
<div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">

  <!-- Last Visit -->
  <div class="flex items-center justify-between backdrop-blur-md shadow-2xl 
  hover:border-classic-gold hover:shadow-light-gold/20 
  bg-carb-gray/10 border border-light-gold/5 rounded-2xl p-4 transition">

    <div class="text-right">
      <h3 class="text-bone-white font-semibold">آخرین بازدید</h3>
      <p class="text-light-gold text-sm">۲ ساعت پیش</p>
    </div>

    <Icon name="mdi:clock-outline" class="text-light-gold text-3xl"/>
  </div>


  <!-- Projects Count -->
  <div class="flex items-center justify-between backdrop-blur-md shadow-2xl 
  hover:border-classic-gold hover:shadow-light-gold/20 
  bg-carb-gray/10 border border-light-gold/5 rounded-2xl p-4 transition">

    <div class="text-right">
      <h3 class="text-bone-white font-semibold">پروژه‌ها</h3>
      <p class="text-light-gold text-sm">۱۲ پروژه</p>
    </div>

    <Icon name="mdi:folder-outline" class="text-light-gold text-3xl"/>
  </div>


  <!-- Rating -->
  <div class="flex items-center justify-between backdrop-blur-md shadow-2xl 
  hover:border-classic-gold hover:shadow-light-gold/20 
  bg-carb-gray/10 border border-light-gold/5 rounded-2xl p-4 transition">

    <div class="text-right">
      <h3 class="text-bone-white font-semibold">امتیاز</h3>
      <p class="text-light-gold text-sm">4.8 از 5</p>
    </div>

    <Icon name="mdi:star-outline" class="text-light-gold text-3xl"/>
  </div>

</div>

   <div class="lg:mt-0">
    <ProjectContainer></ProjectContainer>
  </div>


  <div class="mx-auto my-6">
    <UiButton>مشاهده همه پروژه های علیرضا</UiButton>
  </div>
</div>
</template>


<script setup>
import { useCustomToastify } from '~/composable/useCustomToasitify';
import { generateSeoMeta } from '~/utilities/seo';

const seo = generateSeoMeta({
      title: `پروژه‌های علیرضا`,
      description: 'در ایند',
      image: "",
      url: ``,
      keywords: ["افزودن پروژه"],
      author:"علیرضا کشاورز",
      type: 'website'
    })
    useHead(seo)

</script>
<style scoped>

.profile-container:hover .prof-user {
  border-color: var(--color-classic-gold);
}

</style>
