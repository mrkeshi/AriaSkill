<template>
  <UiCardBlury class="my-8 lg:my-12">
    <div class="max-w-4xl mx-auto mt-6 lg:mt-12 py-8">
      
      <!-- بخش بالایی: لوگو و عنوان -->
      <div class="flex flex-col items-center text-center mb-12">
        
        <!-- جایگاه لوگوی مشکی -->
        <div class="relative group mb-6">
          <!-- افکت درخشش پشت لوگو -->
          <div class="absolute -inset-1 bg-gradient-to-r from-classic-gold to-light-gold rounded-3xl blur opacity-30 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
          
          <!-- باکس روشن برای لوگوی مشکی -->
          <div class="relative bg-classic-gold/95 backdrop-blur-xl border border-classic-gold/40 shadow-2xl rounded-3xl p-8 flex items-center justify-center w-32 h-32 transform transition duration-500 hover:scale-105">
            <!-- جایگزین این آیکون، تصویر لوگوی خود را قرار دهید -->
            <img src="/images/logoA.png" alt="Logo" class="w-full h-full object-contain" />
            <Icon name="mdi:hexagon-multiple" class="text-6xl text-slate-900" />
          </div>
        </div>

        <h1 class="text-3xl md:text-4xl font-bold text-classic-gold mb-3 tracking-wide">درباره ما </h1>
        <p class="text-gray-400 max-w-2xl text-sm leading-relaxed">
          لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک است.
        </p>
      </div>

      <!-- بخش محتوای متنی -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        
        <!-- کارت داستان ما -->
        <div class="bg-white/5 border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-colors shadow-inner">
          <div class="flex items-center gap-3 mb-4">
            <div class="p-2 bg-classic-gold/20 rounded-lg text-classic-gold">
              <Icon name="mdi:book-open-page-variant-outline" class="text-xl" />
            </div>
            <h3 class="text-xl font-semibold text-white">داستان ما</h3>
          </div>
          <p class="text-gray-300 text-sm leading-loose text-justify">
            لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک است، چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است، و برای شرایط فعلی تکنولوژی مورد نیاز، و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد. کتابهای زیادی در شصت و سه درصد گذشته حال و آینده.
          </p>
        </div>

        <!-- کارت چشم‌انداز -->
        <div class="bg-white/5 border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-colors shadow-inner">
          <div class="flex items-center gap-3 mb-4">
            <div class="p-2 bg-classic-gold/20 rounded-lg text-classic-gold">
              <Icon name="mdi:telescope" class="text-xl" />
            </div>
            <h3 class="text-xl font-semibold text-white">چشم‌انداز</h3>
          </div>
          <p class="text-gray-300 text-sm leading-loose text-justify">
            شناخت فراوان جامعه و متخصصان را می طلبد، تا با نرم افزارها شناخت بیشتری را برای طراحان رایانه ای علی الخصوص طراحان خلاقی، و فرهنگ پیشرو در زبان فارسی ایجاد کرد، در این صورت می توان امید داشت که تمام و دشواری موجود در ارائه راهکارها، و شرایط سخت تایپ به پایان رسد و زمان مورد نیاز شامل حروفچینی دستاوردهای اصلی.
          </p>
        </div>

      </div>

      <!-- بخش ارزش‌ها / ویژگی‌ها -->
      <div class="mt-8">
        <h3 class="text-lg font-bold text-center text-white mb-8 border-b border-white/10 pb-4 inline-block w-full">ارزش‌های کلیدی ما</h3>
        
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <!-- ویژگی 1 -->
          <div class="flex flex-col items-center text-center p-4">
            <Icon name="mdi:lightbulb-on-outline" class="text-4xl text-classic-gold mb-3" />
            <h4 class="text-white font-medium mb-2">نوآوری و خلاقیت</h4>
            <p class="text-gray-400 text-xs leading-relaxed">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است.</p>
          </div>
          
          <!-- ویژگی 2 -->
          <div class="flex flex-col items-center text-center p-4">
            <Icon name="mdi:shield-check-outline" class="text-4xl text-classic-gold mb-3" />
            <h4 class="text-white font-medium mb-2">کیفیت و امنیت</h4>
            <p class="text-gray-400 text-xs leading-relaxed">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است.</p>
          </div>
          
          <!-- ویژگی 3 -->
          <div class="flex flex-col items-center text-center p-4">
            <Icon name="mdi:account-group-outline" class="text-4xl text-classic-gold mb-3" />
            <h4 class="text-white font-medium mb-2">تعهد به مشتری</h4>
            <p class="text-gray-400 text-xs leading-relaxed">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است.</p>
          </div>
        </div>
      </div>

      <!-- بخش تماس سریع (اختیاری) -->
      <div class="mt-12 bg-classic-gold/10 border border-classic-gold/20 rounded-2xl p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h4 class="text-white font-bold mb-1">آماده شروع یک پروژه جدید هستید؟</h4>
          <p class="text-classic-gold text-sm">همین حالا با ما در ارتباط باشید.</p>
        </div>
        <button class="px-6 py-2.5 rounded-xl bg-classic-gold text-slate-900 font-bold hover:bg-yellow-400 hover:shadow-[0_0_20px_rgba(212,175,55,0.3)] transition-all flex items-center gap-2 whitespace-nowrap">
          <Icon name="mdi:email-outline" class="text-lg" />
          تماس با ما
        </button>
      </div>

    </div>
  </UiCardBlury>
</template>

<style scoped>
.bg-classic-gold { background-color: #D4AF37; }
.text-classic-gold { color: #D4AF37; }
.border-classic-gold { border-color: #D4AF37; }
</style>


<script setup>
import { useProjectFilters } from '~/composable/useProjectFilters'
import { generateSeoMeta } from '~/utilities/seo'


const {filters,applyFilter,resetSearch,toggleTechnology,toggleYears,toggleCategory}=useProjectFilters()
const seo = generateSeoMeta({
      title: `درباره آریاکرفت`,
      description: 'در ایند',
      image: "",
      url: ``,
      keywords: ["افزودن پروژه"],
      author:"علیرضا کشاورز",
      type: 'website'
    })
    useHead(seo)



</script>
