<template>
 <UiAccordingCard title="تکنولوژی">

<div class="flex flex-wrap gap-2">

<a
v-for="tech in technologies"
:key="tech.id"
@click="toggleTechnology(tech.slug)"
class="backdrop-blur-md shadow-xl p-2 transition cursor-pointer border rounded-md flex items-center gap-1.5"
:class="filters.technology.includes(tech.slug)
? 'bg-classic-gold/20 border-classic-gold'
: 'bg-carb-gray/40 border-white/10 hover:bg-carb-gray'"
>

<img :src="tech.icon" class="h-5 w-5" :alt="tech.name" />

<span
class="text-sm"
:class="filters.technology.includes(tech.slug) ? 'text-classic-gold' : 'text-white'"
>
{{ tech.name }}
</span>

</a>

</div>

</UiAccordingCard>
</template>

<script lang="ts" setup>
const {filters,toggleTechnology} = defineProps<{
  filters: { q: string,technology:string[] }
  toggleTechnology: (slug:string) => void
}>()


const technologies = [
{ id:1, name: "CSS", slug: "css", icon: "/images/program/css.png" },
{ id:2,name: "Node.js", slug: "node", icon: "/images/program/node.png" },
{ id:3, name: "Laravel", slug: "laravel", icon: "/images/program/laravel.png" },
{ id:4,name: "php", slug: "vue", icon: "/images/program/php.png" },
{ id:5,name: "java", slug: "nuxt", icon: "/images/program/java.png" }
]
</script>

<style>

</style>