<template>
     <ui-card-blury>
          <div class="flex items-center flex-wrap gap-3">
            <button
              v-for="item in items"
              :key="item.value"
              @click="()=>{filters.sort=item.value}"
              class="
                px-7 py-3 min-w-[120px] rounded-lg text-sm transition-all duration-200 border
                text-center hover:bg-white/10
              "
              :class="{
                'text-yellow-400 border-yellow-400 bg-yellow-400/10': filters.sort === item.value,
                'text-gray-300 border-white/10': filters.sort !== item.value,
              }"
            >
              {{ item.label }}
            </button>
          </div>
        </ui-card-blury>

</template>

<script lang="ts" setup>
const {filters} = defineProps<{
  filters: {sort:string}

}>()
const items = [
  { label: "جدیدترین", value: "new" },
  { label: "محبوب‌ترین", value: "popular" },
  { label: "بیشترین دانلود", value: "downloads" },
  { label: "قدیمی‌ترین", value: "old" }
]
</script>

<style>

</style>