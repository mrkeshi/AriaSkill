<template>
      <ui-card-blury>
        <h2 class="text-xl font-semibold text-white mb-4">فیلتر اعمال شده</h2>
        <div class="flex flex-wrap w-full gap-3">
          <a v-if="filters.q"
            class="backdrop-blur-md transition relative hover:opacity-50 shadow-2xl p-2 bg-carb-gray/40 border border-white/10 rounded-md flex items-center gap-1.5"
          >
            <span class="text-white text-sm">
              <Icon @click="()=>{resetSearch()}"
                name="mdi:close"
                size="12"
                class="text-white absolute hover:text-light-gold -left-0 top-1"
              />
              <span class="text-light-gold">جستجو:</span> {{filters.q}}
            </span>
          </a>

        <template v-if="selectedTechObjects.length" class="backdrop-blur-md transition relative hover:opacity-50 shadow-2xl p-2 bg-carb-gray/40 border border-white/10 rounded-md flex items-center gap-4">
  <a v-for="tech in selectedTechObjects" :key="tech.slug"
     class="backdrop-blur-md transition relative hover:opacity-50 shadow-2xl p-2 bg-carb-gray/40 border border-white/10 rounded-md flex items-center gap-1.5">
     
    <Icon @click="() => toggleTechnology(tech.slug)"
          name="mdi:close"
          size="12"
          class="absolute left-0 top-1 text-white" />

    <img :src="tech.icon" class="h-4 w-4" />
    <span class=" text-white text-sm">{{ tech.name }}</span>
  </a>
</template>

       <template v-if="filters.years.length" class="backdrop-blur-md transition relative hover:opacity-50 shadow-2xl p-2 bg-carb-gray/40 border border-white/10 rounded-md flex items-center gap-4">
  <a v-for="year in filters.years" :key="year"
     class="backdrop-blur-md transition relative hover:opacity-50 shadow-2xl p-2 bg-carb-gray/40 border border-white/10 rounded-md flex items-center gap-1.5">
     
    <Icon @click="() => toggleYears(year)"
          name="mdi:close"
          size="12"
          class="absolute left-0 top-1 text-white" />


    <span class=" text-white text-sm"> <span class="text-classic-gold">سال :</span>{{ year }}</span>
  </a>
</template>

 <template v-if="filters.category.length" class="backdrop-blur-md transition relative hover:opacity-50 shadow-2xl p-2 bg-carb-gray/40 border border-white/10 rounded-md flex items-center gap-4">
  <a v-for="cat in filters.category" :key="cat"
     class="backdrop-blur-md transition relative hover:opacity-50 shadow-2xl p-2 bg-carb-gray/40 border border-white/10 rounded-md flex items-center gap-1.5">
     
    <Icon @click="() => toggleCategory(cat)"
          name="mdi:close"
          size="12"
          class="absolute left-0 top-1 text-white" />


    <span class=" text-white text-sm"> <span class="text-classic-gold">نوع :</span>{{ cat }}</span>
  </a>
</template>
        </div>
      </ui-card-blury>
</template>

<script lang="ts" setup>
import type { ProjectCategory } from '~/models/Project/FilterProjectDTO';

const selectedTechObjects = computed(() => {
  return filters.technology
    .map(slug => technologies.find(t => t.slug === slug))
    .filter((t): t is { id: number; name: string; slug: string; icon: string } => Boolean(t))
})

const technologies = [
{ id:1, name: "CSS", slug: "css", icon: "/images/program/css.png" },
{ id:2,name: "Node.js", slug: "node", icon: "/images/program/node.png" },
{ id:3, name: "Laravel", slug: "laravel", icon: "/images/program/laravel.png" },
{ id:4,name: "php", slug: "vue", icon: "/images/program/php.png" },
{ id:5,name: "java", slug: "nuxt", icon: "/images/program/java.png" }
]

const {filters,toggleTechnology,toggleYears,toggleCategory} = defineProps<{
  filters: { q: string,technology:string[],years:number[],category:ProjectCategory[] }
  resetSearch: () => void
  toggleTechnology:(slug:string)=>void
  toggleYears:(years:number)=>void
  toggleCategory:(cat:ProjectCategory)=>void
}>()

</script>

<style>

</style>