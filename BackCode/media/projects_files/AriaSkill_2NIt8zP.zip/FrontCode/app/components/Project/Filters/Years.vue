<template>
       <UiAccordingCard title="سال انتشار">



  <div class="grid grid-cols-1 gap-2 mt-3">

    <UiCheckBox v-for="y in years"
      :name="`year-${y}`"
      :label="`سال ${y}`"
      :model-value="filters.years.includes(y)"
       @update:modelValue="() => {
    toggleYears(y)
   
  }"
    />

  </div>



</UiAccordingCard>
</template>

<script lang="ts" setup>

const years=ref([
  1403 , 1404 ,1405
])
const {toggleYears,filters} = defineProps<{
  filters: { q: string,technology:string[],years:number[] }
  toggleYears: (years:number) => void
}>()

</script>

<style>

</style>