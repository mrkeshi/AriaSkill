<template>
 <div :class="nested ? 'backdrop-blur-md bg-carb-gray/10 border border-classic-gold/30 rounded-xl p-4' : 'backdrop-blur-md bg-carb-gray/10 border border-white/10 rounded-2xl p-5 shadow-2xl'">
  <div class="flex justify-between items-center mb-3">

      <div class="flex items-center gap-3">
        <img :src="avatar" :alt="comment.user_name" class="w-12 h-12 rounded-full border border-classic-gold object-cover">

        <div>
          <p class="text-white text-sm">{{ comment.user_name }}</p>
          <!-- Requirement #2: Persian date format with month name, e.g. "۱۲ اسفند ۱۴۰۵" -->
          <span class="text-gray-400 text-xs">{{ toJalaliLong(comment.created_at) }}</span>
        </div>
      </div>

      <button
        type="button"
        @click="$emit('reply', comment.id)"
        class="text-gray-400 hover:text-classic-gold text-sm transition"
      >
        پاسخ
      </button>

    </div>

    <p class="text-gray-300 leading-7 text-sm whitespace-pre-line">
      {{ comment.message }}
    </p>

    <div v-if="comment.replies?.length" class="mt-6 space-y-4 mr-10 border-r border-classic-gold/30 pr-6">
      <ProjectCommentItem
        v-for="reply in comment.replies"
        :key="reply.id"
        :comment="reply"
        nested
        @reply="$emit('reply', $event)"
      />
    </div>

 </div> 
</template>

<script lang="ts" setup>
import type { CommentDTO } from '~/models/Comment/SendCommentDTO'
import { toJalaliLong } from '~/utilities/dateHelpers'
import { resolveMediaUrl } from '~/utilities/urlHelpers'

const props = withDefaults(defineProps<{ comment: CommentDTO; nested?: boolean }>(), {
  nested: false,
})

defineEmits<{
  reply: [number]
}>()

const avatar = computed(() => resolveMediaUrl(props.comment.user_avatar) || '/images/user1.jpg')
</script>
