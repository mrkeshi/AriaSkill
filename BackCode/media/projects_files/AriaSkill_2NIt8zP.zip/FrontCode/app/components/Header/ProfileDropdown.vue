<template>
  <div  class="relative mr-3" v-click-outside="closeDropdown">
    <button v-if="auth.isLogin"
      @click="isProfileOpen = !isProfileOpen"
      class="flex cursor-pointer items-center gap-2 bg-deep-black border border-classic-gold/50 text-bone-white px-4 py-2 rounded-xl hover:border-classic-gold transition-all duration-300"
      aria-label="My Account"
    >
      <Icon name="mdi:account-circle-outline" class="text-2xl text-classic-gold" />
      <span>حساب من</span>
      <Icon 
        name="mdi:chevron-down"
        class="text-xl transition-transform duration-300"
        :class="{ 'rotate-180': isProfileOpen }"
      />
    </button>




       <UiButton :to="{name:'user-login'}" v-else variant="outline" >
 ثبت نام / ورود
        </UiButton>
  

    <Transition name="glass-dropdown">
      <div
        v-if="isProfileOpen && auth.isLogin"
        class="absolute left-0 mt-3 w-56 bg-carb-gray/30 border border-white/25 rounded-xl shadow-xl z-50 overflow-hidden glassmorphism"
      >
        <div class="p-4 border-b border-white/20 text-sm text-center">
          <p class="text-bone-white font-pelak">{{auth.user.first_name}} عزیز، خوش آمدی</p>
        </div>
        <ul class="flex flex-col pt-2">
          <li>
            <NuxtLink to="/dashboard" class="flex items-center gap-3 px-4 py-2.5 hover:bg-deep-black hover:text-light-gold transition-colors">
              <Icon name="mdi:view-dashboard-outline" class="text-classic-gold" />
              داشبورد
            </NuxtLink>
          </li>
          <li>
            <NuxtLink to="/dashboard/projects" class="flex items-center gap-3 px-4 py-2.5 hover:bg-deep-black hover:text-light-gold transition-colors">
              <Icon name="mdi:folder-outline" class="text-classic-gold" />
              پروژه‌های من
            </NuxtLink>
          </li>
          <li @click="logout=!logout" class="mt-1 border-t border-white/20 pt-1">
            <button  class="w-full cursor-pointer flex items-center gap-3 px-4 py-2.5 text-error hover:bg-error/10 transition-colors">
              <Icon name="mdi:logout" class="text-error" />
              خروج از حساب
            </button>
          </li>
        </ul>

          <Confirm
    v-model="logout"
    title="خروج"
    description="آیا برای خروج مطمئن هستید؟"
    :onConfirm="auth.logout"

  />
      </div>
    </Transition>
  </div>
</template>

<script setup lang="ts">
const auth=useAuthStore()
import { ref } from 'vue';

const isProfileOpen = ref(false);

const closeDropdown = () => {
  if (isProfileOpen.value) {
    isProfileOpen.value = false;
  }
};

const vClickOutside = {
  mounted(el: any, binding: any) {
    el.clickOutsideEvent = (event: Event) => {
      if (!(el === event.target || el.contains(event.target))) {
        binding.value(event);
      }
    };
    document.addEventListener('click', el.clickOutsideEvent);
  },
  unmounted(el: any) {
    document.removeEventListener('click', el.clickOutsideEvent);
  }
};



const logout=ref(false)

</script>

<style>


.glass-dropdown-enter-active,
.glass-dropdown-leave-active {
  transition: opacity 0.3s ease, transform 0.3s ease;
}
.glass-dropdown-enter-from,
.glass-dropdown-leave-to {
  opacity: 0;
  transform: translateY(-10px);
}
</style>
