<template>
  <li>
    <NuxtLink :to="to" class="flex items-center gap-2 hover:text-light-gold transition-colors duration-300">
      <Icon :name="icon" class="text-xl text-classic-gold" />
      <span>{{ label }}</span>
    </NuxtLink>
  </li>
</template>

<script setup lang="ts">

const props = defineProps({
  to:{type:String},
  icon:{type:String,default:''},
  label: {type:String}
});
</script>
