<template>
  <nav class="hidden md:block text-md">
    <ul class="flex items-center gap-6 text-bone-white">
      <HeaderNavMenuItem to="/" icon="mdi:home-outline" label="خانه" />
      <HeaderNavMenuItem to="/explore" icon="mdi:earth" label="اکسپلور" />
      <HeaderNavMenuItem to="/blog" icon="mdi:post-outline" label="وبلاگ" />
      <HeaderNavMenuItem to="/about" icon="mdi:account-group-outline" label="درباره ما" />
    </ul>
  </nav>
</template>

<script setup lang="ts">
// No script needed for this component
</script>
