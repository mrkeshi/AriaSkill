<template>
  <div class="relative " v-click-outside="closeDropdown">
    <button
      @click="isOpen = !isOpen"
      class="relative p-2 text-bone-white cursor-pointer hover:text-light-gold transition-colors"
      aria-label="Notifications"
    >
      <Icon name="mdi:bell-outline" class="text-2xl" />
      <span
        v-if="hasUnread"
        class="absolute top-2 right-2 w-2.5 h-2.5 bg-error rounded-full border-2 border-carb-gray"
      ></span>
    </button>

    <Transition name="glass-dropdown">
      <div
        v-if="isOpen"
        class="absolute max-md:-right-28  right-0 mt-3 w-72 bg-carb-gray/30 border border-white/30 rounded-xl shadow-xl z-50 overflow-hidden glassmorphism"
      >
        <div class="p-4 border-b border-white/20 text-sm text-center">
          <p class="text-bone-white font-pelak">اعلان‌های جدید</p>
        </div>
        <ul class="flex flex-col">
          <!-- Example Notification Item -->
          <li class="px-4 py-3 hover:bg-white/10 transition-colors cursor-pointer">
            <div class="flex items-center gap-3">
              <Icon name="mdi:bell-badge-outline" class="text-xl text-classic-gold flex-shrink-0" />
              <div>
                <p class="text-bone-white font-medium text-sm">پروژه جدید اضافه شد!</p>
                <p class="text-xs text-bone-white/70">پروژه "طراحی اپلیکیشن" با موفقیت ثبت شد.</p>
              </div>
            </div>
          </li>
          <!-- Add more notification items here -->
          <li class="px-4 py-3 text-center text-sm text-bone-white/60 border-t border-white/20">
            <button class="hover:text-light-gold cursor-pointer transition-colors">مشاهده همه</button>
          </li>
        </ul>
      </div>
    </Transition>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';

const isOpen = ref<Boolean>(false);
const hasUnread = ref<Boolean>(true); 

const closeDropdown = () => {
  if (isOpen.value) {
    isOpen.value = false;
  }
};

const vClickOutside = {
  mounted(el: any, binding: any) {
    el.clickOutsideEvent = (event: Event) => {
      if (!(el === event.target || el.contains(event.target))) {
        binding.value(event);
      }
    };
    document.addEventListener('click', el.clickOutsideEvent);
  },
  unmounted(el: any) {
    document.removeEventListener('click', el.clickOutsideEvent);
  }
};
</script>

<style>
.glassmorphism {
  background: rgba(255, 255, 255, 0.15); /* Increased opacity for better visibility */
  box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
  backdrop-filter: blur(8px); /* Adjusted blur */
  -webkit-backdrop-filter: blur(8px); /* For Safari compatibility */
  border: 1px solid rgba(255, 255, 255, 0.3);
}

.glass-dropdown-enter-active,
.glass-dropdown-leave-active {
  transition: opacity 0.3s ease, transform 0.3s ease;
}
.glass-dropdown-enter-from,
.glass-dropdown-leave-to {
  opacity: 0;
  transform: translateY(-10px);
}
</style>
