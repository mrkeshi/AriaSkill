<template>
  <header class="border-b border-dark-gray/30 shadow-md">

    <div class="container mx-auto px-4 h-20 flex justify-between items-center">
      <div class="flex items-center gap-8">
        <HeaderTheLogo />
        <HeaderTheNavbar/>
      </div>

      <div class="flex items-center gap-1 relative">
        <HeaderNotificationDropdown />
        <div class="w-px h-8 bg-dark-gray/50 hidden md:block"></div>
        <HeaderProfileDropdown/>
      </div>
    </div>

  </header>
</template>

<script setup lang="ts">
import { ref } from 'vue';

</script>

<style scoped>
/* Global styles for Tailwind classes and transitions are applied in global CSS or component styles */
</style>
