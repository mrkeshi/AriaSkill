<template>
  <NuxtLink to="/" class="logo shrink-0">
    <h1 class="text-2xl font-bold hover:text-classic-gold text-bone-white transition ease-linear">
      Aria Craft
    </h1>
  </NuxtLink>
</template>

<script setup lang="ts">
// No script needed for this simple component
</script>

<style scoped>
/* Add any specific logo styles if needed */
</style>
