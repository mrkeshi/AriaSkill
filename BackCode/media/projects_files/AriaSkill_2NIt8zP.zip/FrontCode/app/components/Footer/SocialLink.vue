<template>
  <div class="flex gap-3.5 items-center justify-start sm:justify-end">
    
    <!-- Instagram -->
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
      :stroke="isWhite ? '#fff' : 'url(#ig-grad-footer)'"
      fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"
      class="w-6 h-6 cursor-pointer transition-all duration-300 hover:scale-110 hover:drop-shadow-[0_0_8px_rgba(226,104,60,0.4)]"
    >
      <defs>
        <linearGradient id="ig-grad-footer" x1="0%" y1="100%" x2="100%" y2="0%">
          <stop offset="0%" stop-color="#f09433"/>
          <stop offset="50%" stop-color="#dc2743"/>
          <stop offset="100%" stop-color="#bc1888"/>
        </linearGradient>
      </defs>
      <rect x="2" y="2" width="20" height="20" rx="5" ry="5"/>
      <circle cx="12" cy="12" r="4"/>
      <circle cx="17.5" cy="6.5" r="0.8" :fill="isWhite ? '#fff' : '#dc2743'" stroke="none"/>
    </svg>

    <!-- Telegram -->
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" 
      :fill="isWhite ? '#fff' : '#29a8e8'" 
      class="w-6 h-6 cursor-pointer transition-all duration-300 hover:scale-110 hover:drop-shadow-[0_0_8px_rgba(41,168,232,0.4)]"
    >
      <path d="M21.93 3.24L2.46 10.9c-1.3.52-1.29 1.25-.24 1.57l4.84 1.51 11.2-7.07c.53-.32 1.01-.15.61.21L8.8 16.16l-.36 5.05c.52 0 .75-.24 1.04-.51l2.5-2.43 4.9 3.62c.9.5 1.55.24 1.78-.84l3.22-15.17c.33-1.32-.5-1.92-1.95-1.64z"/>
    </svg>

    <!-- YouTube -->
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" 
      :fill="isWhite ? '#fff' : '#ed1c24'" 
      class="w-6 h-6 cursor-pointer transition-all duration-300 hover:scale-110 hover:drop-shadow-[0_0_8px_rgba(237,28,36,0.4)]"
    >
      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3.5a6.5 6.5 0 1 1 0 13 6.5 6.5 0 0 1 0-13zm0 2a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9zm0 2a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5z"/>
    </svg>

    <!-- Discord -->
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" 
      :fill="isWhite ? '#fff' : '#5865f2'" 
      class="w-6 h-6 cursor-pointer transition-all duration-300 hover:scale-110 hover:drop-shadow-[0_0_8px_rgba(88,101,242,0.4)]"
    >
      <path d="M20.32 4.37A19.8 19.8 0 0 0 15.65 3c-.21.38-.45.88-.62 1.28a18.3 18.3 0 0 0-5.98 0C8.88 3.88 8.63 3.38 8.42 3A19.7 19.7 0 0 0 3.74 4.38C.54 9.2-.33 13.9.1 18.54a20.1 20.1 0 0 0 6.17 3.12c.5-.68.94-1.4 1.32-2.16a12.97 12.97 0 0 1-2.08-1c.17-.13.34-.26.5-.4a14.3 14.3 0 0 0 12.24 0c.16.14.33.27.5.4-.66.39-1.36.72-2.09 1 .38.76.82 1.48 1.32 2.16a20.06 20.06 0 0 0 6.18-3.13c.51-5.28-.87-9.94-3.64-14.16zM8.02 15.67c-1.29 0-2.35-1.18-2.35-2.64 0-1.45 1.03-2.64 2.35-2.64 1.31 0 2.37 1.19 2.35 2.64 0 1.46-1.04 2.64-2.35 2.64zm7.96 0c-1.29 0-2.35-1.18-2.35-2.64 0-1.45 1.03-2.64 2.35-2.64 1.31 0 2.37 1.19 2.35 2.64 0 1.46-1.03 2.64-2.35 2.64z"/>
    </svg>

  </div>
</template>

<script lang="ts" setup>
defineProps({
  isWhite: {
    type: Boolean,
    default: false
  }
})
</script>