<template>
     <div class="flex flex-col gap-4">
  <h3 class="text-classic-gold font-semibold text-lg">
    حامیان ما
  </h3>

  <p class="text-bone-white/70 text-sm leading-7">
    با حمایت برندهای معتبر، تلاش می‌کنیم بهترین خدمات را ارائه دهیم.
  </p>

 <div class=" flex flex-wrap gap-3">

  <div class="w-20 h-14 bg-carb-gray rounded-lg flex items-center justify-center
              hover:bg-classic-gold transition">
    <img src="/images/logos/l1.png"
         class="max-h-8 max-w-[80%] object-contain opacity-80 hover:opacity-100 transition">
  </div>

  <div class="w-20 h-14 bg-carb-gray rounded-lg flex items-center justify-center
              hover:bg-classic-gold transition">
    <img src="/images/logos/l2.png"
         class="max-h-8 max-w-[80%] object-contain opacity-80 hover:opacity-100 transition">
  </div>

  <div class="w-20 h-14 bg-carb-gray rounded-lg flex items-center justify-center
              hover:bg-classic-gold transition">
    <img src="/images/logos/l3.png"
         class="max-h-8 max-w-[80%] object-contain opacity-80 hover:opacity-100 transition">
  </div>

  <div class="w-20 h-14 bg-carb-gray rounded-lg flex items-center justify-center
              hover:bg-classic-gold transition">
    <img src="/images/logos/l4.png"
         class="max-h-8 max-w-[80%] object-contain opacity-80 hover:opacity-100 transition">
  </div>

  <div class="w-20 h-14 bg-carb-gray rounded-lg flex items-center justify-center
              hover:bg-classic-gold transition">
    <img src="/images/logos/l5.png"
         class="max-h-8 max-w-[80%] object-contain opacity-80 hover:opacity-100 transition">
  </div>

  <div class="w-20 h-14 bg-carb-gray rounded-lg flex items-center justify-center
              hover:bg-classic-gold transition">
    <img src="/images/logos/l6.png"
         class="max-h-8 max-w-[80%] object-contain opacity-80 hover:opacity-100 transition">
  </div>
   <div class="w-20 h-14 bg-carb-gray rounded-lg flex items-center justify-center
              hover:bg-classic-gold transition">
    <img src="/images/logos/l3.png"
         class="max-h-8 max-w-[80%] object-contain opacity-80 hover:opacity-100 transition">
  </div>

</div>

</div>

</template>

<script lang="ts" setup>
const user=ref()
</script>

<style>

</style>