<template>
    <footer class="w-full bg-dark-gray/20 border-t-1 shadow-xl border-classic-gold/90 mt-16">
    <div class="container mx-auto pb-8 px-8 py-12 max-md:px-4">

      <div class="grid grid-cols-3 gap-10 max-lg:grid-cols-2 max-md:grid-cols-1">

    <FooterAboutFooter></FooterAboutFooter>


  <FooterLinks></FooterLinks>


 <FooterSponsor></FooterSponsor>

      </div>


      <div
        class="border-t border-dark-gray/40 mt-10 pt-6 text-center
               text-bone-white/60 text-sm"
      >
        © 2026 Aria Craft - تمامی حقوق محفوظ است
      </div>

    </div>
  </footer>
</template>

<script lang="ts" setup>
import { FooterSocialLink } from '#components';


</script>

<style>

</style>