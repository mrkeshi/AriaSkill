<template>
   <div class="flex justify-around">
          <div class="flex flex-col gap-5">
          <h3 class="text-classic-gold font-semibold text-lg">
            دسترسی سریع
          </h3>

          <ul class="flex flex-col gap-5 text-bone-white/80 text-sm">
            <li class="hover:text-classic-gold transition cursor-pointer">خانه</li>
            <li class="hover:text-classic-gold transition cursor-pointer">فروشگاه</li>
            <li class="hover:text-classic-gold transition cursor-pointer">محصولات ویژه</li>
            <li class="hover:text-classic-gold transition cursor-pointer">درباره ما</li>
            <li class="hover:text-classic-gold transition cursor-pointer">تماس با ما</li>
          </ul>
        </div>


        <div class="flex flex-col gap-5">
          <h3 class="text-classic-gold font-semibold text-lg">
            لینک های مفید
          </h3>

          <ul class="flex flex-col gap-5 text-bone-white/80 text-sm">
            <li class="hover:text-classic-gold transition cursor-pointer">قوانین و مقررات</li>
            <li class="hover:text-classic-gold transition cursor-pointer">حریم خصوصی</li>
            <li class="hover:text-classic-gold transition cursor-pointer">راهنمای خرید</li>
            <li class="hover:text-classic-gold transition cursor-pointer">سوالات متداول</li>
            <li class="hover:text-classic-gold transition cursor-pointer">پشتیبانی</li>
          </ul>
        </div>
    </div>
</template>

<script lang="ts" setup>

</script>

<style>

</style>