<template>
  <div class="flex flex-col gap-4 text-right" dir="rtl">
    <!-- برندینگ اصلی -->
    <div class="flex items-center gap-2">
      <div class="w-1.5 h-6 bg-gradient-to-b from-cyan-400 to-classic-gold rounded-full shadow-[0_0_10px_rgba(212,175,55,0.3)]"></div>
      <h2 class="text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-300 text-2xl font-black tracking-wide">
        Aria Craft
      </h2>
    </div>

    <!-- توضیحات پلتفرم -->
    <p class="text-bone-white/70 text-xs leading-6 text-justify">
      توسعه و بومی‌سازی راهکارهای نوین مبتنی بر هوش مصنوعی، پلتفرم‌های ارکستریشن و سیستم‌های مدیریت هوشمند اسناد با تکیه بر معماری‌های ماژولار و پایدار.
    </p>

    <!-- شعار و بخش شبکه‌های اجتماعی -->
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mt-2 pt-4 border-t border-white/[0.03]">
      <span class="text-xs font-semibold text-gray-400">
        با آریاکرفت <span class="text-classic-gold drop-shadow-[0_0_8px_rgba(212,175,55,0.2)]">هوآشمندتر گام بردارید.</span>
      </span>
      <div class="flex justify-end">
        <FooterSocialLink />
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
// توسعه و شخصی‌سازی کامپوننت درباره ما فوتر
</script>