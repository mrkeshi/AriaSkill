<template>
<section class="relative min-h-screen flex items-center px-4 md:px-8 pb-6">

  <div class="relative max-w-4xl mx-auto w-full">

    <h2 class="text-4xl md:text-5xl font-bold text-bone-white text-center mb-4">
      روند کار در <span class="text-classic-gold">SkillSphere</span>
    </h2>

    <p class="text-center text-dark-gray max-w-2xl mx-auto mb-16 text-lg">
      چهار گام ساده تا شروع همکاری روی پروژه‌های واقعی.
    </p>

    <div class="absolute left-1/2 top-40 bottom-12 w-[2px] bg-classic-gold/30 transform -translate-x-1/2"></div>

    <!-- Step 1 -->
    <div class="relative flex flex-col md:flex-row-reverse items-center md:items-start mb-8">
      <div class="w-full md:w-5/12  backdrop-blur-xl border border-classic-gold rounded-2xl p-6 shadow-lg md:mr-auto transition-all duration-300 hover:bg-white/10 hover:-translate-y-1 hover:border-classic-gold/80">
        <div class="flex items-center gap-3 mb-3">
          <Icon name="mdi:account-plus-outline" class="text-classic-gold text-3xl" />
          <h3 class="text-2xl font-bold text-bone-white">ایجاد حساب کاربری</h3>
        </div>
        <p class="text-dark-gray leading-relaxed">
          ثبت‌نام سریع و تنظیم مهارت‌ها برای شروع کار.
        </p>
      </div>

      <div class="hidden md:flex absolute right-[52%] ">
        <div class="w-10 h-10 rounded-full bg-carb-gray/70 backdrop-blur-xl border border-classic-gold flex items-center justify-center text-classic-gold font-bold text-lg shadow-md">
          ۱
        </div>
      </div>
    </div>

    <!-- Step 2 -->
    <div class="relative flex flex-col md:flex-row items-center md:items-start mb-8">
      <div class="w-full md:w-5/12  backdrop-blur-xl border border-classic-gold rounded-2xl p-6 shadow-lg md:ml-auto transition-all duration-300 hover:bg-white/10 hover:-translate-y-1 hover:border-classic-gold/80">
        <div class="flex items-center gap-3 mb-3">
          <Icon name="mdi:magnify" class="text-classic-gold text-3xl" />
          <h3 class="text-2xl font-bold text-bone-white">جستجو و انتخاب پروژه</h3>
        </div>
        <p class="text-dark-gray leading-relaxed">
          پروژه مناسب را بر اساس تکنولوژی و سطح مهارت پیدا کن.
        </p>
      </div>

      <div class="hidden md:flex absolute left-[52%] ">
        <div class="w-10 h-10 rounded-full bg-carb-gray/70 backdrop-blur-xl border border-classic-gold flex items-center justify-center text-classic-gold font-bold text-lg shadow-md">
          ۲
        </div>
      </div>
    </div>

    <!-- Step 3 -->
    <div class="relative flex flex-col md:flex-row-reverse items-center md:items-start mb-8">
      <div class="w-full md:w-5/12  backdrop-blur-xl border border-classic-gold rounded-2xl p-6 shadow-lg md:mr-auto transition-all duration-300 hover:bg-white/10 hover:-translate-y-1 hover:border-classic-gold/80">
        <div class="flex items-center gap-3 mb-3">
          <Icon name="mdi:account-group-outline" class="text-classic-gold text-3xl" />
          <h3 class="text-2xl font-bold text-bone-white">همکاری با تیم</h3>
        </div>
        <p class="text-dark-gray leading-relaxed">
          با تیم‌های واقعی کار کن، تجربه بگیر و رشد کن.
        </p>
      </div>

      <div class="hidden md:flex absolute right-[52%] ">
        <div class="w-10 h-10 rounded-full bg-carb-gray/70 backdrop-blur-xl border border-classic-gold flex items-center justify-center text-classic-gold font-bold text-lg shadow-md">
          ۳
        </div>
      </div>
    </div>

    <!-- Step 4 -->
    <div class="relative flex flex-col md:flex-row items-center md:items-start">
      <div class="w-full md:w-5/12  backdrop-blur-xl border border-classic-gold rounded-2xl p-6 shadow-lg md:ml-auto transition-all duration-300 hover:bg-white/10 hover:-translate-y-1 hover:border-classic-gold/80">
        <div class="flex items-center gap-3 mb-3">
          <Icon name="mdi:trophy-outline" class="text-classic-gold text-3xl" />
          <h3 class="text-2xl font-bold text-bone-white">ساخت رزومه حرفه‌ای</h3>
        </div>
        <p class="text-dark-gray leading-relaxed">
          تجربه‌ها و پروژه‌ها در پروفایلت ذخیره می‌شوند و رزومه‌ات را قوی‌تر می‌کنند.
        </p>
      </div>

      <div class="hidden md:flex absolute left-[52%] ">
        <div class="w-10 h-10 rounded-full bg-carb-gray/70 backdrop-blur-xl border border-classic-gold flex items-center justify-center text-classic-gold font-bold text-lg shadow-md">
          ۴
        </div>
      </div>
    </div>

  </div>
</section>

</template>

<script lang="ts" setup>

</script>

<style>

</style>