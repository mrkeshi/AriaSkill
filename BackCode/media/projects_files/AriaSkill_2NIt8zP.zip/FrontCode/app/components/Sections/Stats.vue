<template>
  <section class="pb-12">
    <div
      class="w-full bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl px-10 py-8 shadow-lg"
    >
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">

        <!-- کاربران -->
        <div class="flex items-center justify-between">
          
          <div class="text-right">
            <p class="text-2xl font-bold text-bone-white">
              ۴۰۰
            </p>
            <p class="text-dark-gray text-base mt-1">
              کاربر
            </p>
          </div>

          <div
            class="w-14 h-14 flex items-center justify-center rounded-xl bg-classic-gold/10 text-classic-gold"
          >
            <Icon name="mdi:account-group-outline" size="30" />
          </div>

        </div>

        <!-- مخازن -->
        <div class="flex items-center justify-between">

          <div class="text-right">
            <p class="text-2xl font-bold text-bone-white">
              ۳۵۰۰
            </p>
            <p class="text-dark-gray text-base mt-1">
              مخزن
            </p>
          </div>

          <div
            class="w-14 h-14 flex items-center justify-center rounded-xl bg-classic-gold/10 text-classic-gold"
          >
            <Icon name="mdi:source-repository-multiple" size="30" />
          </div>

        </div>

        <!-- دانلود -->
        <div class="flex items-center justify-between">

          <div class="text-right">
            <p class="text-2xl font-bold text-bone-white">
              ۲۴,۵۰۰
            </p>
            <p class="text-dark-gray text-base mt-1">
              دانلود
            </p>
          </div>

          <div
            class="w-14 h-14 flex items-center justify-center rounded-xl bg-classic-gold/10 text-classic-gold"
          >
            <Icon name="mdi:download-outline" size="30" />
          </div>

        </div>

        <!-- حوزه تخصصی -->
        <div class="flex items-center justify-between">

          <div class="text-right">
            <p class="text-2xl font-bold text-bone-white">
              ۲۵
            </p>
            <p class="text-dark-gray text-base mt-1">
              حوزه تخصصی
            </p>
          </div>

          <div
            class="w-14 h-14 flex items-center justify-center rounded-xl bg-classic-gold/10 text-classic-gold"
          >
            <Icon name="mdi:book-outline" size="30" />
          </div>

        </div>

      </div>
    </div>
  </section>
</template>
