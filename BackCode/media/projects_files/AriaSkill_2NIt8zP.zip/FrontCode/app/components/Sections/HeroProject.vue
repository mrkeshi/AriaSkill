<template>
  <section
    class="flex flex-col-reverse md:flex-row items-center justify-between gap-12 py-12 md:py-1 overflow-hidden"
  >
    <div class="flex-1 text-center md:text-right space-y-8">

      <h1
        class="text-classic-gold text-4xl md:text-6xl font-pelak font-bold leading-tight text-shine"
      >
        اکتشاف پروژه‌ها
        <br />
        <span
          class="text-bone-white text-2xl md:text-4xl font-light"
        >
          دنیای بی‌پایان ایده‌ها، یادگیری و خلاقیت
        </span>
      </h1>

      <p
        class="text-dark-gray text-lg md:text-xl max-w-2xl leading-relaxed  mx-auto md:mx-0"
      >
        با جستجو در هزاران پروژه واقعی، مسیر یادگیری خود را
        هوشمندانه و هدفمند بسازید.
      </p>

      <div class="w-full max-w-xl mx-auto md:mx-0 pt-4">
        <div
          class="relative group bg-white/5 border border-white/10 hover:border-classic-gold transition-all duration-300 rounded-2xl backdrop-blur-xl p-4 flex flex-row-reverse items-center gap-3"
        >
            <div
              class="w-12 h-12 flex items-center justify-center rounded-full bg-classic-gold/20 text-classic-gold group-hover:bg-classic-gold/30 transition"
            >
              <Icon name="mdi:magnify" size="28" class="cursor-pointer" />
            </div>

            <input
              type="text"
              placeholder="جستجو بین پروژه‌ها، تکنولوژی‌ها و ایده‌ها..."
              class="flex-1 bg-transparent border-none outline-none text-bone-white placeholder-gray-400  text-lg"
            />
          </div>
      </div>
    </div>


    <div class="flex-1 flex justify-center md:justify-end relative">
      <img
        src="/images/hero/2.png"
        alt="Explore Projects Hero"
        class="hero-image relative z-10 w-full max-w-[620px] md:max-w-[720px] object-contain"
      />
    </div>
  </section>
</template>

<script lang="ts" setup>
</script>

<style>
.hero-image {
  animation: heroFloat 10s ease-in-out infinite;
}

@keyframes heroFloat {
  0% {
    transform: scale(1) rotate(0deg);
  }
  50% {
    transform: scale(1.03) rotate(0.8deg);
  }
  100% {
    transform: scale(1) rotate(0deg);
  }
}
</style>
