<template>
  <div class="space-y-6 select-none" dir="rtl">
    
    <!-- هدر بخش داشبورد -->
    <div class="flex items-start gap-3">
      <div class="w-1.5 h-8 bg-gradient-to-b from-cyan-400 to-classic-gold rounded-full shadow-[0_0_12px_rgba(6,182,212,0.4)] mt-1"></div>
      <div>
        <h1 class="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-l from-white via-gray-100 to-gray-300 tracking-wide">
          پیشخوان سیستم
        </h1>
        <p class="text-xs text-gray-400 mt-1">مرور کلی و خلاصه فعالیت‌های جاری معماری پلتفرم شما</p>
      </div>
    </div>

    <!-- گرید کارت‌های آماری داینامیک -->
    <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6" dir="rtl">
      <div 
        v-for="stat in stats" 
        :key="stat.id"
        class="group relative bg-white/[0.02] backdrop-blur-xl border border-white/10 rounded-2xl p-5 flex items-center gap-5 transition-all duration-500 hover:-translate-y-1.5 hover:bg-white/[0.04] overflow-hidden"
        :class="stat.shadowColor"
      >
        <!-- افکت نوری ماتی در لایه عمق هر کارت که در هوور روشن‌تر می‌شود -->
        <div 
          class="absolute -right-10 -bottom-10 w-28 h-28 rounded-full blur-3xl opacity-20 group-hover:opacity-40 transition-opacity duration-500 pointer-events-none"
          :class="stat.bgGlow"
        ></div>

        <!-- باکس آیکون نئونی -->
        <div 
          class="flex items-center justify-center w-14 h-14 rounded-2xl border transition-all duration-500 group-hover:scale-110"
          :class="stat.iconStyle"
        >
          <Icon :name="stat.icon" size="28" />
        </div>

        <!-- محتوای متنی و عددی (چپ‌چین برای اعداد، راست‌چین برای برچسب) -->
        <div class="flex flex-col gap-1 flex-1 min-w-0 text-right">
          <p class="text-2xl font-black text-white tracking-wider font-mono">
            {{ stat.value }}
          </p>
          <p class="text-xs font-medium text-gray-400 group-hover:text-gray-300 transition-colors">
            {{ stat.label }}
          </p>
        </div>

        <!-- لبه‌ی نوری خطی بسیار ظریف در سمت راست کارت -->
        <div 
          class="absolute right-0 top-1/4 bottom-1/4 w-[2px] rounded-r-full opacity-40 group-hover:opacity-100 transition-opacity duration-500"
          :class="stat.lineStyle"
        ></div>
      </div>
    </div>

  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'

interface StatCard {
  id: number
  label: string
  value: string
  icon: string
  iconStyle: string
  shadowColor: string
  bgGlow: string
  lineStyle: string
}

// دیتای کارت‌ها با ترکیب رنگ‌های مدرن و لوکس
const stats = ref<StatCard[]>([
  {
    id: 1,
    label: 'پروژه‌های توسعه‌یافته',
    value: '24',
    icon: 'mdi:folder-outline',
    iconStyle: 'bg-cyan-500/10 border-cyan-500/20 text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.1)] group-hover:shadow-[0_0_25px_rgba(6,182,212,0.3)]',
    shadowColor: 'hover:shadow-[0_10px_30px_rgba(6,182,212,0.08)] hover:border-cyan-500/20',
    bgGlow: 'bg-cyan-500',
    lineStyle: 'bg-cyan-400'
  },
  {
    id: 2,
    label: 'کل دانلودهای ثبت‌شده',
    value: '2,430',
    icon: 'mdi:download-outline',
    iconStyle: 'bg-purple-500/10 border-purple-500/20 text-purple-400 shadow-[0_0_15px_rgba(168,85,247,0.1)] group-hover:shadow-[0_0_25px_rgba(168,85,247,0.3)]',
    shadowColor: 'hover:shadow-[0_10px_30px_rgba(168,85,247,0.08)] hover:border-purple-500/20',
    bgGlow: 'bg-purple-500',
    lineStyle: 'bg-purple-400'
  },
  {
    id: 3,
    label: 'نظرات و بازخوردها',
    value: '86',
    icon: 'mdi:comment-outline',
    iconStyle: 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.1)] group-hover:shadow-[0_0_25px_rgba(16,185,129,0.3)]',
    shadowColor: 'hover:shadow-[0_10px_30px_rgba(16,185,129,0.08)] hover:border-emerald-500/20',
    bgGlow: 'bg-emerald-500',
    lineStyle: 'bg-emerald-400'
  },
  {
    id: 4,
    label: 'اعلان‌های جدید سیستم',
    value: '5',
    icon: 'mdi:bell-outline',
    iconStyle: 'bg-amber-500/10 border-amber-500/20 text-classic-gold shadow-[0_0_15px_rgba(212,175,55,0.1)] group-hover:shadow-[0_0_25px_rgba(212,175,55,0.3)]',
    shadowColor: 'hover:shadow-[0_10px_30px_rgba(212,175,55,0.08)] hover:border-amber-500/20',
    bgGlow: 'bg-amber-500',
    lineStyle: 'bg-classic-gold'
  }
])
</script>

<style scoped>
/* حفظ ثبات استایل تم طلایی اختصاصی پروژه */
.text-classic-gold {
  color: #d4af37;
}
.bg-classic-gold {
  background-color: #d4af37;
}
.from-classic-gold {
  --tw-gradient-from: #d4af37 var(--tw-gradient-from-position);
  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to, rgb(212 175 55 / 0));
}
.to-classic-gold {
  --tw-gradient-to: #d4af37 var(--tw-gradient-to-position);
}
</style>