<template>
  <div class="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6  overflow-hidden relative select-none">
    
    <div class="absolute -top-24 -left-24 w-48 h-48 bg-purple-500/10 rounded-full blur-3xl pointer-events-none"></div>
    <div class="absolute -bottom-24 -right-24 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>

    <div class="flex items-center justify-between mb-8 relative z-10" dir="rtl">
      <div class="flex items-center gap-3">
        <div class="w-2 h-5 bg-gradient-to-b from-amber-400 to-classic-gold rounded-full shadow-[0_0_10px_rgba(212,175,55,0.5)]"></div>
        <h2 class="text-lg font-black text-white tracking-wide">مرکز اعلان‌ها</h2>
      </div>
      <button 
        @click="markAllAsRead"
        class="text-xs font-semibold px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-classic-gold hover:text-amber-300 transition-all duration-300 flex items-center gap-1.5"
      >
        <Icon name="mdi:check-all" size="14" />
        خواندن همه
      </button>
    </div>

    <div class="space-y-3 relative z-10" dir="rtl">
      <div 
        v-for="notification in notifications" 
        :key="notification.id"
        class="group relative flex items-center justify-between p-4 rounded-xl border transition-all duration-300 bg-slate-950/20 backdrop-blur-md"
        :class="[
          notification.isRead ? 'border-white/5 opacity-60' : 'border-white/10 hover:border-white/20 hover:bg-white/[0.04]',
          statusStyles[notification.type].borderHover
        ]"
      >
        <div 
          v-if="!notification.isRead"
          class="absolute right-0 top-0 bottom-0 w-[3px] rounded-r-full transition-all duration-300"
          :class="statusStyles[notification.type].sideLine"
        ></div>

        <div class="flex items-center gap-4 flex-1 min-w-0">
          <div 
            class="w-10 h-10 flex items-center justify-center rounded-xl border shrink-0 transition-transform duration-300 group-hover:scale-105"
            :class="statusStyles[notification.type].iconBox"
          >
            <Icon :name="notification.icon" size="18" />
          </div>

          <div class="flex flex-col gap-1 min-w-0 text-right">
            <p class="text-sm font-bold text-gray-100 group-hover:text-white transition-colors truncate">
              {{ notification.title }}
            </p>
            <p class="text-xs text-gray-400 leading-relaxed truncate pl-4">
              {{ notification.message }}
            </p>
          </div>
        </div>

        <div class="flex items-center gap-4 shrink-0 mr-4">
          <span class="text-[10px] font-medium text-gray-500 whitespace-nowrap">{{ notification.time }}</span>
          
          <button 
            @click="removeNotification(notification.id)"
            class="opacity-0 group-hover:opacity-100 text-gray-500 hover:text-rose-400 p-1 rounded-lg hover:bg-rose-500/10 transition-all duration-300"
            title="حذف اعلان"
          >
            <Icon name="mdi:delete-outline" size="16" />
          </button>
        </div>

      </div>
    </div>

  </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue'

interface NotificationItem {
  id: number
  title: string
  message: string
  time: string
  icon: string
  type: 'download' | 'comment' | 'star' | 'security' | 'system'
  isRead: boolean
}

// ۶ آیتم خفن، دیتامحور و کاملاً مرتبط با پروژه شما
const notifications = ref<NotificationItem[]>([
  {
    id: 1,
    title: 'دانلود سورس‌کد پروژه',
    message: 'سورس‌کد پروژه «پردازش هوشمند اسناد» توسط یک کاربر ویژه دانلود شد.',
    time: '۲ دقیقه پیش',
    icon: 'mdi:download',
    type: 'download',
    isRead: false
  },
  {
    id: 2,
    title: 'دیدگاه جدید ثبت شد',
    message: 'علیرضا کشاورز یک نظر جدید برای کامپوننت سایدبار شیشه‌ای ثبت کرد.',
    time: '۲۵ دقیقه پیش',
    icon: 'mdi:comment-outline',
    type: 'comment',
    isRead: false
  },
  {
    id: 3,
    title: 'پروژه شما استار گرفت!',
    message: 'اکوسیستم هوش مصنوعی شما امتیاز ۵ ستاره را از پورتفولیوی کاربران دریافت کرد.',
    time: '۲ ساعت پیش',
    icon: 'mdi:star-outline',
    type: 'star',
    isRead: false
  },
  {
    id: 4,
    title: 'هشدار امنیتی سیستم',
    message: 'یک تلاش مشکوک برای ورود به پنل ادمین از آی‌پـی ناشناس مسدود شد.',
    time: '۵ ساعت پیش',
    icon: 'mdi:shield-alert-outline',
    type: 'security',
    isRead: false
  },
  {
    id: 5,
    title: 'بهینه‌سازی معماری ماژولار',
    message: 'هسته سیستم هگزاگونال با موفقیت به آخرین نسخه فریم‌ورک سینک شد.',
    time: 'دیروز',
    icon: 'mdi:cpu-64-bit',
    type: 'system',
    isRead: true
  },

])

// استایل‌های نئونی اختصاصی برای هر نوع نوتیفیکیشن
const statusStyles = {
  download: {
    iconBox: 'border-purple-500/30 bg-purple-500/10 text-purple-400 shadow-[0_0_15px_rgba(168,85,247,0.1)]',
    sideLine: 'bg-purple-500',
    borderHover: 'hover:border-purple-500/30'
  },
  comment: {
    iconBox: 'border-cyan-500/30 bg-cyan-500/10 text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.1)]',
    sideLine: 'bg-cyan-500',
    borderHover: 'hover:border-cyan-500/30'
  },
  star: {
    iconBox: 'border-amber-500/30 bg-amber-500/10 text-classic-gold shadow-[0_0_15px_rgba(212,175,55,0.1)]',
    sideLine: 'bg-classic-gold',
    borderHover: 'hover:border-classic-gold/30'
  },
  security: {
    iconBox: 'border-rose-500/40 bg-rose-500/10 text-rose-400 shadow-[0_0_15px_rgba(244,63,94,0.15)]',
    sideLine: 'bg-rose-500',
    borderHover: 'hover:border-rose-500/30'
  },
  system: {
    iconBox: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.1)]',
    sideLine: 'bg-emerald-500',
    borderHover: 'hover:border-emerald-500/30'
  }
}

// متدهای هندلینگ لاجیک
const markAllAsRead = () => {
  notifications.value.forEach(n => n.isRead = true)
}

const removeNotification = (id: number) => {
  notifications.value = notifications.value.filter(n => n.id !== id)
}
</script>

<style scoped>
/* افزودن تم رنگی متغیر متناسب با سایدبار لوکس شما */
.text-classic-gold {
  color: #d4af37;
}
.bg-classic-gold {
  background-color: #d4af37;
}
.from-classic-gold {
  --tw-gradient-from: #d4af37 var(--tw-gradient-from-position);
  --tw-gradient-to: rgb(212 175 55 / 0) var(--tw-gradient-to-position);
  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);
}
.to-classic-gold {
  --tw-gradient-to: #d4af37 var(--tw-gradient-to-position);
}
</style>