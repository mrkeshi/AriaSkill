<template>
  <div class="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-5 mt-6 overflow-hidden relative select-none">
    
    <div class="absolute -top-24 -right-24 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>
    <div class="absolute -bottom-24 -left-24 w-48 h-48 bg-purple-500/10 rounded-full blur-3xl pointer-events-none"></div>

    <div class="flex items-center justify-between mb-5 relative z-10" dir="rtl">
      <div class="flex items-center gap-3">
<div class="w-2 h-5 bg-gradient-to-b from-amber-400 to-classic-gold rounded-full shadow-[0_0_10px_rgba(212,175,55,0.5)]" data-v-52aeec73=""></div>        <h3 class="text-base font-black text-white tracking-wide">مرور فعالیت‌های اخیر</h3>
      </div>
      <span class="text-[10px] font-semibold text-gray-500 bg-white/[0.02] border border-white/5 px-2 py-1 rounded-md">بروزرسانی زنده</span>
    </div>

    <div class="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-3" dir="rtl">
      <div 
        v-for="activity in activities" 
        :key="activity.id" 
        class="group relative bg-slate-950/20 hover:bg-white/[0.03] border border-white/5 hover:border-white/10 rounded-xl p-4 flex items-start gap-3.5 transition-all duration-300 transform hover:-translate-y-0.5"
      >
        <div 
          class="absolute right-0 top-3 bottom-3 w-[2.5px] rounded-l-full opacity-60 group-hover:opacity-100 transition-opacity"
          :class="statusClasses[activity.status].line"
        ></div>

        <div 
          class="w-9 h-9 flex items-center justify-center rounded-lg border shrink-0 transition-all duration-500 group-hover:scale-105"
          :class="statusClasses[activity.status].iconContainer"
        >
          <Icon :name="activity.icon" size="16" />
        </div>

        <div class="flex flex-col justify-between flex-1 min-w-0 h-full gap-2 text-right">
          <div>
            <div class="flex items-center gap-2 flex-wrap">
              <h4 class="text-xs font-bold text-gray-200 group-hover:text-white transition-colors truncate">
                {{ activity.title }}
              </h4>
              <span 
                v-if="activity.badge" 
                class="text-[9px] px-1.5 py-0.5 rounded font-bold whitespace-nowrap"
                :class="statusClasses[activity.status].badge"
              >
                {{ activity.badge }}
              </span>
            </div>
            <p class="text-[11px] text-gray-400 leading-relaxed mt-1 line-clamp-2 pl-2">
              {{ activity.description }}
            </p>
          </div>

          <div class="flex items-center gap-1 text-gray-500 text-[10px] font-medium pt-1.5 border-t border-white/[0.03]">
            <Icon name="mdi:clock-outline" size="12" />
            <span>{{ activity.time }}</span>
          </div>
        </div>

      </div>
    </div>

  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'

interface ActivityItem {
  id: number
  title: string
  description: string
  time: string
  icon: string
  status: 'success' | 'info' | 'warning' | 'danger' | 'purple'
  badge: string
}

const activities = ref<ActivityItem[]>([
  {
    id: 1,
    title: 'انتشار پروژه جدید',
    description: 'پروژه «طراحی سیستم هوشمند پردازش اسناد» با موفقیت آپلود و در بخش پورتفولیو منتشر شد.',
    time: '۱۰ دقیقه پیش',
    icon: 'mdi:cloud-upload',
    status: 'success',
    badge: 'Core'
  },
  {
    id: 2,
    title: 'ثبت دیدگاه جدید',
    description: 'امین علوی روی پروژه «داشبورد مدیریتی Vue.js» کامنت گذاشت: "بخش معماری ماژولار عالی کار شده..."',
    time: '۲ ساعت پیش',
    icon: 'mdi:comment-text-multiple-outline',
    status: 'info',
    badge: 'تعاملات'
  },
  {
    id: 3,
    title: 'تلاش برای ورود ناموفق!',
    description: 'یک درخواست ورود ناموفق با رمز عبور اشتباه از آی‌پی (185.204.12.5) مسدود شد.',
    time: '۵ ساعت پیش',
    icon: 'mdi:shield-alert-outline',
    status: 'danger',
    badge: 'امنیت'
  },
  {
    id: 4,
    title: 'تغییر گذرواژه حساب کاربر',
    description: 'رمز عبور پنل کاربری شما با موفقیت تغییر کرد. جلسات فعال دیگر منقضی شدند.',
    time: 'دیروز',
    icon: 'mdi:lock-reset',
    status: 'warning',
    badge: 'امنیت'
  },
  {
    id: 5,
    title: 'دانلود مستندات پروژه',
    description: 'شما فایل سورس‌کد ZIP پروژه «اکوسیستم هوش مصنوعی SkillSphere» را دانلود کردید.',
    time: '۳ روز پیش',
    icon: 'mdi:file-download-outline',
    status: 'purple',
    badge: 'دانلود'
  },
  {
    id: 6,
    title: 'ورود موفق به سیستم',
    description: 'احراز هویت از طریق اکانت گوگل با آی‌پی (94.101.54.2) روی مرورگر Chrome انجام شد.',
    time: '۴ روز پیش',
    icon: 'mdi:login',
    status: 'success',
    badge: 'جلسه فعال'
  }
])

const statusClasses = {
  success: {
    iconContainer: 'border-emerald-500/20 bg-emerald-500/10 text-emerald-400 shadow-[0_0_12px_rgba(16,185,129,0.1)]',
    badge: 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/10',
    line: 'bg-emerald-500'
  },
  info: {
    iconContainer: 'border-cyan-500/20 bg-cyan-500/10 text-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.1)]',
    badge: 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/10',
    line: 'bg-cyan-400'
  },
  warning: {
    iconContainer: 'border-amber-500/20 bg-amber-500/10 text-amber-400 shadow-[0_0_12px_rgba(245,158,11,0.1)]',
    badge: 'bg-amber-500/10 text-amber-400 border border-amber-500/10',
    line: 'bg-amber-500'
  },
  danger: {
    iconContainer: 'border-rose-500/30 bg-rose-500/10 text-rose-400 shadow-[0_0_12px_rgba(244,63,94,0.15)]',
    badge: 'bg-rose-500/10 text-rose-400 border border-rose-500/10',
    line: 'bg-rose-500'
  },
  purple: {
    iconContainer: 'border-purple-500/20 bg-purple-500/10 text-purple-400 shadow-[0_0_12px_rgba(168,85,247,0.1)]',
    badge: 'bg-purple-500/10 text-purple-400 border border-purple-500/10',
    line: 'bg-purple-500'
  }
}
</script>

<style scoped>
/* کلاس رنگ طلایی امضای پورتفولیو */
.text-classic-gold {
  color: #d4af37;
}
.from-classic-gold {
  --tw-gradient-from: #d4af37 var(--tw-gradient-from-position);
  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to, rgb(212 175 55 / 0));
}
</style>