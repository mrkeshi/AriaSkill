from django.urls import path

from projects.admin_views import SkillListCreateView, SkillRetrieveUpdateDestroyView
from projects.views import ProjectListCreateView, ProjectDetailView, ProjectLikeView, ProjectDownloadView, \
    ProjectUnlikeView, CommentListCreateView, CommentDetailView, PublicProjectListView, MyProjectCommentsView, \
    MyProjectCommentModerationView

urlpatterns = [
    path('skills/', SkillListCreateView.as_view(), name='skill-list-create'),
    path('skills/<int:id>/', SkillRetrieveUpdateDestroyView.as_view(), name='skill-detail'),
    path('', ProjectListCreateView.as_view(), name='project-list'),
    path('projects/public/', PublicProjectListView.as_view(), name='public-project-list'),
    path('comments/my-projects/', MyProjectCommentsView.as_view(), name='my-project-comments'),
    path('comments/my-projects/<int:pk>/', MyProjectCommentModerationView.as_view(), name='my-project-comment-manage'),
    path('comments/<int:pk>/', CommentDetailView.as_view(), name='comment-detail'),
    path('<int:project_id>/comments/', CommentListCreateView.as_view(), name='project-comments'),
    path('<str:slug>/', ProjectDetailView.as_view(), name='project-detail'),
    path('<str:slug>/like/', ProjectLikeView.as_view(), name='project-like'),
    path('<str:slug>/unlike/', ProjectUnlikeView.as_view(), name='project-unlike'),
    path('<str:slug>/download/', ProjectDownloadView.as_view(), name='project-download'),

]
