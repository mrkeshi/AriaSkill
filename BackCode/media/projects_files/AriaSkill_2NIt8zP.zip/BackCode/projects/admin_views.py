from rest_framework import generics, filters
from rest_framework.permissions import IsAdminUser, IsAuthenticatedOrReadOnly, AllowAny
from .models import Skill
from .serializers import SkillSerializer
from drf_spectacular.utils import extend_schema, extend_schema_view, OpenApiResponse

class SkillListCreateView(generics.ListCreateAPIView):
    queryset = Skill.objects.all().order_by('-id')
    serializer_class = SkillSerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ['name']

    def get_permissions(self):
        if self.request.method == 'POST':
            return [IsAdminUser()]
        return [AllowAny()]

    @extend_schema(
        summary="List or Search Skills",
        description="Everyone can view and search skills by name.",
        tags=["Skills"]
    )
    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)

    @extend_schema(
        summary="Create a new Skill",
        description="Only staff/admin users can create new skills.",
        tags=["Skills"]
    )
    def post(self, request, *args, **kwargs):
        return super().post(request, *args, **kwargs)


@extend_schema_view(
    get=extend_schema(summary="Retrieve a skill", tags=["Skills"]),
    put=extend_schema(summary="Update a skill (Admin)", tags=["Skills"]),
    patch=extend_schema(summary="Partial update a skill (Admin)", tags=["Skills"]),
    delete=extend_schema(summary="Delete a skill (Admin)", tags=["Skills"]),
)
class SkillRetrieveUpdateDestroyView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Skill.objects.all()
    serializer_class = SkillSerializer
    lookup_field = 'id'

    def get_permissions(self):

        if self.request.method == 'GET':
            return [AllowAny()]

        return [IsAdminUser()]