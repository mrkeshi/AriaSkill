from django.urls import path

from accounts.views import UserRegistrationAPIView, CustomTokenObtainPairView, ActivateAccountView, \
    RequestPasswordResetView, PasswordResetConfirmView, ChangePasswordView, UserProfileView, UserProfileUpdateView, \
    GoogleAuthView

urlpatterns = [
    path('register/', UserRegistrationAPIView.as_view(), name='register'),
    path('register/activate/', ActivateAccountView.as_view(), name='activate'),
    path('password_reset/request/', RequestPasswordResetView.as_view(), name='password_reset_request'),
    path('password_reset/confirm/', PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('change_password/', ChangePasswordView.as_view(), name='user_change_password'),
    path('login/', CustomTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('google/', GoogleAuthView.as_view(), name='google_auth'),
    path('profile/', UserProfileView.as_view(), name="fetch_user"),
    path('profile/edit/', UserProfileUpdateView.as_view(), name="edit_user_profile"),
]
