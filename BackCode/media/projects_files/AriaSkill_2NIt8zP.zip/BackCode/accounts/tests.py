from django.contrib.auth import get_user_model
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase

User = get_user_model()


class UserProfileAPITests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='test-password',
            first_name='Test',
            last_name='User',
            job_title='Backend Developer',
            about_me='I build APIs.',
            instagram_link='https://instagram.com/testuser',
            telegram_link='https://t.me/testuser',
            discord_link='https://discord.gg/testuser',
            linkedin_link='https://linkedin.com/in/testuser',
        )
        self.client.force_authenticate(user=self.user)

    def test_profile_response_includes_social_links(self):
        response = self.client.get(reverse('fetch_user'))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['job_title'], 'Backend Developer')
        self.assertEqual(response.data['about_me'], 'I build APIs.')
        self.assertEqual(response.data['instagram_link'], 'https://instagram.com/testuser')
        self.assertEqual(response.data['telegram_link'], 'https://t.me/testuser')
        self.assertEqual(response.data['discord_link'], 'https://discord.gg/testuser')
        self.assertEqual(response.data['linkedin_link'], 'https://linkedin.com/in/testuser')

    def test_user_can_edit_own_profile(self):
        response = self.client.patch(reverse('edit_user_profile'), {
            'first_name': 'Updated',
            'job_title': 'API Engineer',
            'about_me': 'Updated profile text.',
            'instagram_link': 'https://instagram.com/updated',
            'telegram_link': 'https://t.me/updated',
            'discord_link': 'https://discord.gg/updated',
            'linkedin_link': 'https://linkedin.com/in/updated',
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.user.refresh_from_db()
        self.assertEqual(self.user.first_name, 'Updated')
        self.assertEqual(self.user.job_title, 'API Engineer')
        self.assertEqual(self.user.about_me, 'Updated profile text.')
        self.assertEqual(self.user.instagram_link, 'https://instagram.com/updated')
        self.assertEqual(self.user.telegram_link, 'https://t.me/updated')
        self.assertEqual(self.user.discord_link, 'https://discord.gg/updated')
        self.assertEqual(self.user.linkedin_link, 'https://linkedin.com/in/updated')
