from django.contrib.auth import get_user_model
from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_decode
from rest_framework import generics, status
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework_simplejwt.views import TokenObtainPairView

from accounts.serializers import UserRegistrationSerializer, CustomTokenObtainPairSerializer, ActivationSerializer, \
    RequestPasswordResetSerializer, PasswordResetConfirmSerializer, ChangePasswordSerializer, UserProfileSerializer, \
    UserProfileUpdateSerializer, GoogleAuthSerializer
from accounts.services.activation_service import send_activation_register_email, send_activation_change_pass_email

User = get_user_model()


class UserRegistrationAPIView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserRegistrationSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            try:
                user = serializer.save()
                send_activation_register_email(user)

                return Response({
                    'message': 'registration successful and sent activation link',
                    'user': serializer.data,
                }, status=status.HTTP_201_CREATED)
            except Exception as e:
                return Response({
                    'message': 'registration failed',
                    'details': str(e)
                }, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class CustomTokenObtainPairView(TokenObtainPairView):
    permission_classes = (AllowAny,)
    serializer_class = CustomTokenObtainPairSerializer


class GoogleAuthView(generics.GenericAPIView):
    permission_classes = (AllowAny,)
    serializer_class = GoogleAuthSerializer

    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        return Response(serializer.save(), status=status.HTTP_200_OK)


class ActivateAccountView(generics.GenericAPIView):
    serializer_class = ActivationSerializer
    permission_classes = (AllowAny,)

    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            uid64 = serializer.validated_data['uid']
            token = serializer.validated_data['token']

            try:
                uid = urlsafe_base64_decode(uid64).decode()
                user = User.objects.get(pk=uid)

            except (ValueError, TypeError, User.DoesNotExist):
                return Response({'error': 'Invalid UID or user does not exist'},
                                status=status.HTTP_400_BAD_REQUEST)

            if user.is_active:
                return Response({'message': 'Account already active'},
                                status=status.HTTP_200_OK)

            if default_token_generator.check_token(user, token):
                user.is_active = True
                user.save()
                return Response({'message': 'Account activated successfully'},
                                status=status.HTTP_200_OK)
            return Response({'error': 'Invalid or expired token'},
                            status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class RequestPasswordResetView(generics.GenericAPIView):
    permission_classes = (AllowAny,)
    serializer_class = RequestPasswordResetSerializer

    def post(self, request):

        serializer = self.get_serializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        email = serializer.validated_data['email']
        if not email:
            return Response({'error': 'Email required'}, status=status.HTTP_400_BAD_REQUEST)

        user = User.objects.filter(email=email).first()

        if user:
            uid, token = send_activation_change_pass_email(user)
            print(f"{uid} \n {token}")

        return Response({'message': 'If an account exists, Password reset email sent'}, status=status.HTTP_200_OK)


class PasswordResetConfirmView(generics.GenericAPIView):
    permission_classes = (AllowAny,)
    serializer_class = PasswordResetConfirmSerializer

    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        uid64 = serializer.validated_data['uid']
        token = serializer.validated_data['token']
        password = serializer.validated_data['password']
        password_confirm = serializer.validated_data['password_confirm']

        if password != password_confirm:
            return Response({'error': 'Passwords do not match'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            uid = urlsafe_base64_decode(uid64).decode()
            user = User.objects.get(pk=uid)
        except:
            return Response({'error': 'Invalid UID'}, status=status.HTTP_400_BAD_REQUEST)

        if not default_token_generator.check_token(user, token):
            return Response({'error': 'Invalid or expired token'}, status=status.HTTP_400_BAD_REQUEST)

        user.set_password(password)
        user.save()

        return Response({'message': 'Password reset successful'}, status=status.HTTP_200_OK)


class ChangePasswordView(generics.GenericAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = ChangePasswordSerializer

    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        user = request.user
        old_password = serializer.validated_data['old_password']
        new_password = serializer.validated_data['new_password']
        if not user.check_password(old_password):
            return Response({'error': 'Invalid old password'}, status=status.HTTP_400_BAD_REQUEST)

        user.set_password(new_password)
        user.save()

        return Response({'message': 'Password updated successfully'}, status=status.HTTP_200_OK)

class UserProfileView(generics.RetrieveAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = UserProfileSerializer

    def get_object(self):
        return self.request.user


class UserProfileUpdateView(generics.UpdateAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = UserProfileUpdateSerializer

    def get_object(self):
        return self.request.user
        
        
import json
from django.http import JsonResponse
from django.shortcuts import render
import arabic_reshaper
from bidi.algorithm import get_display

import json
import unicodedata
import arabic_reshaper
from bidi.algorithm import get_display
from django.shortcuts import render
from django.http import JsonResponse


def reshape_page(request):
    return render(request, 'reshape_page.html')


from django.shortcuts import render
from django.http import JsonResponse
import json
import arabic_reshaper
from bidi.algorithm import get_display
import unicodedata
from deep_translator import GoogleTranslator

def reshape_page(request):
    return render(request, 'reshape_page.html')

def api_reshape(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            text = data.get('text', '')
            reshaped_text = arabic_reshaper.reshape(text)
            bidi_text = get_display(reshaped_text)
            return JsonResponse({'reshaped_text': bidi_text})
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)
    return JsonResponse({'error': 'Invalid request'}, status=400)

def api_unreshape(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            text = data.get('text', '')
            # برای بازگردانی: ابتدا معکوس کردن رشته برای خنثی سازی bidi
            reversed_text = text[::-1]
            # سپس نرمال سازی یونیکد برای خنثی سازی reshaper
            unreshaped_text = unicodedata.normalize('NFKC', reversed_text)
            return JsonResponse({'unreshaped_text': unreshaped_text})
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)
    return JsonResponse({'error': 'Invalid request'}, status=400)

def api_translate(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            text = data.get('text', '')
            if text.strip():
                # ترجمه به فارسی به صورت رایگان
                translated = GoogleTranslator(source='auto', target='fa').translate(text)
                return JsonResponse({'translated_text': translated})
            return JsonResponse({'translated_text': ''})
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)
    return JsonResponse({'error': 'Invalid request'}, status=400)
