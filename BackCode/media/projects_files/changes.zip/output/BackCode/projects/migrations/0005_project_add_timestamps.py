import django.utils.timezone
from django.db import migrations, models


class Migration(migrations.Migration):
    """
    Adds created_at and updated_at to the Project table.

    The initial migration (0001_initial) omitted these fields, so the
    database table was created without them.  This migration adds them
    with safe defaults so that existing rows are not broken:

    - created_at: auto_now_add is emulated by using a default of
      django.utils.timezone.now and setting editable=False.
      We cannot use auto_now_add=True when adding a field to an existing
      table because Django requires a one-time default for the backfill.

    - updated_at: auto_now is also emulated with a default and the field
      is kept non-editable.  Django will set it on every save() call
      once the model is in sync with the database.
    """

    dependencies = [
        ("projects", "0004_project_file"),
    ]

    operations = [
        migrations.AddField(
            model_name="project",
            name="created_at",
            field=models.DateTimeField(
                auto_now_add=True,
                default=django.utils.timezone.now,
            ),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name="project",
            name="updated_at",
            field=models.DateTimeField(
                auto_now=True,
            ),
        ),
    ]
