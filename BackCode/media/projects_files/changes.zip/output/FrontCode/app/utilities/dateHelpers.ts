/**
 * dateHelpers.ts
 *
 * Lightweight Jalali (Shamsi) date formatting utilities.
 * Uses the built-in Intl.DateTimeFormat with the 'fa-IR' locale and
 * 'persian' calendar — no external package required.
 *
 * Usage:
 *   import { toJalali, toJalaliLong } from '~/utilities/dateHelpers'
 *   toJalali('2026-06-01T10:00:00Z')  // → '۱۴۰۵/۰۳/۱۱'
 *   toJalaliLong('2026-06-01')        // → '۱۱ خرداد ۱۴۰۵'
 */

const persianShortFormatter = new Intl.DateTimeFormat('fa-IR', {
  calendar: 'persian',
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
})

const persianLongFormatter = new Intl.DateTimeFormat('fa-IR', {
  calendar: 'persian',
  year: 'numeric',
  month: 'long',
  day: 'numeric',
})

/**
 * Converts an ISO date string or Date object to a short Jalali string.
 * e.g. ۱۴۰۵/۰۳/۱۱
 */
export const toJalali = (date: string | Date | null | undefined): string => {
  if (!date) return '—'
  try {
    return persianShortFormatter.format(new Date(date))
  } catch {
    return '—'
  }
}

/**
 * Converts an ISO date string or Date object to a long Jalali string.
 * e.g. ۱۱ خرداد ۱۴۰۵
 */
export const toJalaliLong = (date: string | Date | null | undefined): string => {
  if (!date) return '—'
  try {
    return persianLongFormatter.format(new Date(date))
  } catch {
    return '—'
  }
}
