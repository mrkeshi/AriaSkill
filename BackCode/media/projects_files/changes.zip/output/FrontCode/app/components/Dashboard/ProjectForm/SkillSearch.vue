<template>
  <div class="space-y-3">
    <!-- Header row -->
    <div class="flex items-center justify-between">
      <label class="text-sm font-medium text-gray-300">مهارت‌ها</label>
      <span
        v-if="modelValue.length"
        class="text-xs px-2 py-0.5 rounded-full bg-classic-gold/20 text-classic-gold border border-classic-gold/30"
      >
        {{ modelValue.length }} مورد انتخاب شده
      </span>
    </div>

    <!-- Selected skill chips -->
    <div v-if="modelValue.length" class="flex flex-wrap gap-2">
      <button
        v-for="skill in modelValue"
        :key="skill.id"
        type="button"
        class="inline-flex items-center gap-1.5 rounded-lg border border-classic-gold/40 bg-classic-gold/10 px-3 py-1.5 text-sm text-classic-gold transition hover:bg-classic-gold/20 group"
        @click="remove(skill)"
      >
        <img v-if="skill.icon" :src="resolveMediaUrl(skill.icon)" class="h-4 w-4 object-contain" alt="">
        {{ skill.name }}
        <Icon name="mdi:close" class="text-xs opacity-60 group-hover:opacity-100 transition" />
      </button>
    </div>

    <!-- Search input + dropdown wrapper -->
    <div class="relative" ref="containerRef">
      <div
        class="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 focus-within:border-classic-gold/40 transition"
      >
        <Icon name="mdi:magnify" class="text-gray-400 shrink-0" />
        <input
          v-model.trim="query"
          type="text"
          class="flex-1 bg-transparent text-sm text-white placeholder-gray-500 focus:outline-none"
          placeholder="جستجوی مهارت..."
          @focus="open = true"
        >
        <button
          v-if="query"
          type="button"
          class="text-gray-500 hover:text-gray-300 transition"
          @click="query = ''"
        >
          <Icon name="mdi:close-circle" class="text-base" />
        </button>
      </div>

      <!-- Dropdown list -->
      <Transition name="dropdown">
        <div
          v-if="open"
          class="absolute z-20 mt-1 w-full rounded-xl border border-white/10 bg-slate-900/95 backdrop-blur-md shadow-xl overflow-hidden"
        >
          <!-- Loading -->
          <div v-if="loading" class="px-4 py-3 text-sm text-gray-400 text-center">
            <Icon name="mdi:loading" class="animate-spin mr-1" />
            در حال دریافت...
          </div>

          <!-- Empty -->
          <div v-else-if="skills.length === 0" class="px-4 py-3 text-sm text-gray-500 text-center">
            مهارتی پیدا نشد.
          </div>

          <!-- Items -->
          <ul v-else class="max-h-52 overflow-y-auto custom-scrollbar py-1">
            <li
              v-for="skill in skills"
              :key="skill.id"
              class="flex items-center gap-2.5 px-3 py-2.5 text-sm cursor-pointer transition select-none"
              :class="isSelected(skill.id)
                ? 'bg-classic-gold/15 text-classic-gold'
                : 'text-gray-200 hover:bg-white/8'"
              @mousedown.prevent="toggle(skill)"
            >
              <img v-if="skill.icon" :src="resolveMediaUrl(skill.icon)" class="h-5 w-5 object-contain shrink-0" alt="">
              <span class="flex-1 truncate">{{ skill.name }}</span>
              <Icon
                v-if="isSelected(skill.id)"
                name="mdi:check"
                class="text-classic-gold shrink-0"
              />
            </li>
          </ul>
        </div>
      </Transition>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, watch, onBeforeUnmount, onMounted } from 'vue'
import type { skillItem } from '~/models/Skill/SkillDTO'
import { getSkillsService } from '~/services/skills/skills.Service'
import { resolveMediaUrl } from '~/utilities/urlHelpers'

const props = defineProps<{
  modelValue: skillItem[]
}>()

const emit = defineEmits<{
  'update:modelValue': [skills: skillItem[]]
}>()

const query = ref('')
const skills = ref<skillItem[]>([])
const loading = ref(false)
const open = ref(false)
const containerRef = ref<HTMLElement | null>(null)

let debounceTimer: ReturnType<typeof setTimeout> | null = null

const isSelected = (id: number) => props.modelValue.some(s => s.id === id)

const toggle = (skill: skillItem) => {
  const updated = isSelected(skill.id)
    ? props.modelValue.filter(s => s.id !== skill.id)
    : [...props.modelValue, skill]
  emit('update:modelValue', updated)
}

const remove = (skill: skillItem) => {
  emit('update:modelValue', props.modelValue.filter(s => s.id !== skill.id))
}

const loadSkills = async () => {
  loading.value = true
  try {
    const res = await getSkillsService(1, query.value)
    skills.value = res.data?.results ?? []
  } finally {
    loading.value = false
  }
}

// Close dropdown when clicking outside
const onClickOutside = (event: MouseEvent) => {
  if (containerRef.value && !containerRef.value.contains(event.target as Node)) {
    open.value = false
  }
}

onMounted(() => {
  document.addEventListener('mousedown', onClickOutside)
  loadSkills()
})

onBeforeUnmount(() => {
  document.removeEventListener('mousedown', onClickOutside)
  if (debounceTimer) clearTimeout(debounceTimer)
})

watch(query, () => {
  if (debounceTimer) clearTimeout(debounceTimer)
  debounceTimer = setTimeout(loadSkills, 250)
  open.value = true
})
</script>

<style scoped>
.custom-scrollbar::-webkit-scrollbar { width: 4px; }
.custom-scrollbar::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.15);
  border-radius: 999px;
}

.dropdown-enter-active,
.dropdown-leave-active {
  transition: opacity 0.15s ease, transform 0.15s ease;
}
.dropdown-enter-from,
.dropdown-leave-to {
  opacity: 0;
  transform: translateY(-4px);
}

/* Tailwind-incompatible class used in template */
.hover\:bg-white\/8:hover {
  background-color: rgba(255, 255, 255, 0.08);
}
</style>
