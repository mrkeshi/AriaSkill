<template>
  <div class="space-y-2">
    <label class="text-sm font-medium text-gray-300">{{ label }}</label>
    <label
      class="relative flex aspect-video cursor-pointer items-center justify-center overflow-hidden rounded-xl border-2 border-dashed border-white/15 bg-white/5 hover:border-classic-gold/40 transition"
    >
      <input
        class="absolute inset-0 opacity-0 cursor-pointer"
        type="file"
        accept="image/*"
        @change="onSelect"
      >
      <img v-if="preview" :src="preview" class="h-full w-full object-cover" alt="تصویر کاور">
      <span v-else class="flex flex-col items-center gap-2 text-sm text-gray-400">
        <Icon name="mdi:image-outline" class="text-4xl" />
        انتخاب تصویر
      </span>
    </label>
  </div>
</template>

<script setup lang="ts">
withDefaults(defineProps<{
  preview?: string
  label?: string
}>(), {
  preview: '',
  label: 'تصویر کاور',
})

const emit = defineEmits<{ select: [file: File] }>()

const onSelect = (event: Event) => {
  const file = (event.target as HTMLInputElement).files?.[0]
  if (file) emit('select', file)
}
</script>
