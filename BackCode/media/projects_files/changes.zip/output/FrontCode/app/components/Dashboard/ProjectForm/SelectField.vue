<template>
  <div class="space-y-2">
    <label class="text-sm font-medium text-gray-300">{{ label }}</label>
    <select
      :value="modelValue"
      :required="required"
      class="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-classic-gold/50 [&>option]:bg-slate-900"
      @change="$emit('update:modelValue', ($event.target as HTMLSelectElement).value)"
    >
      <option value="" disabled>{{ placeholder }}</option>
      <option v-for="opt in options" :key="opt.value" :value="opt.value">
        {{ opt.label }}
      </option>
    </select>
  </div>
</template>

<script setup lang="ts">
withDefaults(defineProps<{
  modelValue: string
  label: string
  placeholder?: string
  required?: boolean
  options: { value: string; label: string }[]
}>(), {
  placeholder: 'انتخاب کنید',
  required: false,
})

defineEmits<{ 'update:modelValue': [value: string] }>()
</script>
