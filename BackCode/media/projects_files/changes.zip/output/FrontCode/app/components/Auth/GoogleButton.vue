<template>
  <div>
    <button
      v-if="!googleClientId"
      type="button"
      disabled
      class="w-full rounded-lg border border-white/10 px-6 py-3 text-sm text-gray-500"
    >
      ورود با گوگل پیکربندی نشده است
    </button>

    <div v-else ref="buttonRef" class="flex justify-center" />
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'

const emit = defineEmits<{
  credential: [credential: string]
}>()

const config = useRuntimeConfig()
const googleClientId = computed(() => config.public.googleClientId as string)
const buttonRef = ref<HTMLDivElement | null>(null)

const loadGoogleScript = () => new Promise<void>((resolve, reject) => {
  if ((window as any).google?.accounts?.id) {
    resolve()
    return
  }

  const existingScript = document.querySelector<HTMLScriptElement>('script[src="https://accounts.google.com/gsi/client"]')
  if (existingScript) {
    existingScript.addEventListener('load', () => resolve(), { once: true })
    existingScript.addEventListener('error', () => reject(), { once: true })
    return
  }

  const script = document.createElement('script')
  script.src = 'https://accounts.google.com/gsi/client'
  script.async = true
  script.defer = true
  script.onload = () => resolve()
  script.onerror = () => reject()
  document.head.appendChild(script)
})

onMounted(async () => {
  if (!googleClientId.value || !buttonRef.value) return

  await loadGoogleScript()

  ;(window as any).google.accounts.id.initialize({
    client_id: googleClientId.value,
    callback: (response: { credential?: string }) => {
      if (response.credential) emit('credential', response.credential)
    },
  })

  ;(window as any).google.accounts.id.renderButton(buttonRef.value, {
    theme: 'outline',
    size: 'large',
    width: buttonRef.value.offsetWidth || 360,
  })
})
</script>
