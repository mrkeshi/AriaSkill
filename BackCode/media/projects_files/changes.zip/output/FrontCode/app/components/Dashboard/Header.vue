<template>
  <header
    class="sticky top-0 z-30 h-20
    backdrop-blur-md shadow-2xl bg-carb-gray/10
    border-b border-white/10"
  >
    <div class="flex h-full items-center justify-between px-6">

      <div class="flex flex-col max-lg:hidden">
        <h1 class="font-bold text-white text-2xl">
          {{ greetingText }} 👋
        </h1>
      </div>

      <NuxtLink
        to="/dashboard/profile"
        class="flex items-center gap-3 rounded-2xl text-white"
      >
        <img
          v-if="auth.user.avatar"
          :src="auth.user.avatar"
          class="h-14 w-14 border-classic-gold border-4 rounded-full object-cover"
          alt="تصویر پروفایل"
        >
        <div
          v-else
          class="h-14 w-14 border-classic-gold border-4 rounded-full bg-white/10 flex items-center justify-center text-classic-gold text-xl font-bold"
        >
          {{ userInitial }}
        </div>
      </NuxtLink>

    </div>
  </header>
</template>

<script setup lang="ts">
import { computed } from 'vue'

const auth = useAuthStore()

const displayName = computed(() => {
  const { first_name, last_name, username } = auth.user
  const full = `${first_name} ${last_name}`.trim()
  return full || username || 'کاربر'
})

const greetingText = computed(() => `سلام ${displayName.value} عزیز، خوش آمدی`)

const userInitial = computed(() => {
  const name = displayName.value
  return name.charAt(0).toUpperCase()
})
</script>
