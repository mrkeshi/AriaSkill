<template>
  <div class="space-y-2">
    <label class="text-sm font-medium text-gray-300">{{ label }}</label>
    <textarea
      v-if="type === 'textarea'"
      :value="modelValue"
      :placeholder="placeholder"
      :rows="rows"
      :required="required"
      class="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-classic-gold/50 resize-none"
      @input="$emit('update:modelValue', ($event.target as HTMLTextAreaElement).value)"
    />
    <input
      v-else
      :type="type"
      :value="modelValue"
      :placeholder="placeholder"
      :required="required"
      class="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-classic-gold/50"
      @input="$emit('update:modelValue', ($event.target as HTMLInputElement).value)"
    >
  </div>
</template>

<script setup lang="ts">
withDefaults(defineProps<{
  modelValue: string
  label: string
  placeholder?: string
  type?: 'text' | 'textarea'
  rows?: number
  required?: boolean
}>(), {
  type: 'text',
  rows: 7,
  placeholder: '',
  required: false,
})

defineEmits<{ 'update:modelValue': [value: string] }>()
</script>
