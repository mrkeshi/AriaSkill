<template>
  <form dir="rtl" class="grid grid-cols-1 lg:grid-cols-3 gap-6" @submit.prevent="submit">

    <!-- ─── Left column: main fields ─── -->
    <div class="lg:col-span-2 space-y-5">

      <DashboardProjectFormFormField
        v-model="form.title"
        label="عنوان پروژه"
        placeholder="مثلا: سامانه مدیریت فروشگاه"
        required
      />

      <DashboardProjectFormSelectField
        v-model="form.project_type"
        label="نوع پروژه"
        placeholder="نوع پروژه را انتخاب کنید"
        :options="projectTypes"
        required
      />

      <DashboardProjectFormFormField
        v-model="form.description"
        type="textarea"
        label="توضیحات پروژه"
        placeholder="توضیحات واضحی درباره هدف، امکانات و تکنولوژی‌های پروژه بنویسید."
        :rows="7"
        required
      />

      <DashboardProjectFormSkillSearch
        v-model="selectedSkills"
      />

    </div>

    <!-- ─── Right column: media + actions ─── -->
    <div class="space-y-5">

      <DashboardProjectFormImageUpload
        :preview="imagePreview"
        @select="onImageSelect"
      />

      <DashboardProjectFormFileUpload
        :file-name="fileName"
        @select="onFileSelect"
      />

      <div class="flex flex-col gap-3 pt-2">
        <UiButton type="submit" variant="gold" full :disabled="loading">
          {{ loading ? 'در حال ذخیره...' : submitLabel }}
        </UiButton>
        <UiButton type="button" variant="outline" full :disabled="loading" @click="$emit('cancel')">
          انصراف
        </UiButton>
      </div>

    </div>
  </form>
</template>

<script setup lang="ts">
import { reactive, ref, watch, onBeforeUnmount } from 'vue'
import type { ProjectDTO } from '~/models/Project/ProjectDTO'
import type { skillItem } from '~/models/Skill/SkillDTO'
import { resolveMediaUrl } from '~/utilities/urlHelpers'

// ─── Props & emits ───────────────────────────────────────────────────────────

const props = withDefaults(defineProps<{
  initialProject?: ProjectDTO | null
  loading?: boolean
  submitLabel?: string
}>(), {
  initialProject: null,
  loading: false,
  submitLabel: 'ذخیره پروژه',
})

const emit = defineEmits<{
  submit: [formData: FormData]
  cancel: []
}>()

// ─── Static data ─────────────────────────────────────────────────────────────

const projectTypes = [
  { value: 'UI/UX',        label: 'طراحی UI/UX' },
  { value: 'Frontend',     label: 'توسعه فرانت‌اند' },
  { value: 'Backend',      label: 'توسعه بک‌اند' },
  { value: 'Mobile',       label: 'توسعه موبایل' },
  { value: 'AI_Data',      label: 'هوش مصنوعی و داده' },
  { value: 'DevOps_Cloud', label: 'DevOps و فضای ابری' },
  { value: 'Game',         label: 'توسعه بازی' },
  { value: 'Cyber_Sec',    label: 'امنیت سایبری' },
]

// ─── Reactive state ───────────────────────────────────────────────────────────

const form = reactive({
  title: '',
  project_type: '',
  description: '',
  image: null as File | null,
  file: null as File | null,
})

const selectedSkills = ref<skillItem[]>([])
const imagePreview   = ref('')
const fileName       = ref('')
let imageObjectUrl   = ''

// ─── Helpers ─────────────────────────────────────────────────────────────────

const hydrate = (project?: ProjectDTO | null) => {
  form.title        = project?.title        ?? ''
  form.project_type = project?.project_type ?? ''
  form.description  = project?.description  ?? ''
  form.image        = null
  form.file         = null
  selectedSkills.value = project?.skills ? [...project.skills] : []
  imagePreview.value   = resolveMediaUrl(project?.image)
  fileName.value       = project?.file ? project.file.split('/').pop() ?? '' : ''
}

const onImageSelect = (file: File) => {
  if (imageObjectUrl) URL.revokeObjectURL(imageObjectUrl)
  form.image       = file
  imageObjectUrl   = URL.createObjectURL(file)
  imagePreview.value = imageObjectUrl
}

const onFileSelect = (file: File) => {
  form.file      = file
  fileName.value = file.name
}

const submit = () => {
  const formData = new FormData()
  formData.append('title',        form.title)
  formData.append('project_type', form.project_type)
  formData.append('description',  form.description)

  selectedSkills.value.forEach(skill => {
    formData.append('skill_ids', String(skill.id))
  })

  if (form.image) formData.append('image', form.image)
  if (form.file)  formData.append('file',  form.file)

  emit('submit', formData)
}

// ─── Watchers & lifecycle ─────────────────────────────────────────────────────

watch(() => props.initialProject, hydrate, { immediate: true })

onBeforeUnmount(() => {
  if (imageObjectUrl) URL.revokeObjectURL(imageObjectUrl)
})
</script>
