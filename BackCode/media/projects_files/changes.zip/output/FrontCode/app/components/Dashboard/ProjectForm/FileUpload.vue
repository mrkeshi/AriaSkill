<template>
  <div class="space-y-2">
    <label class="text-sm font-medium text-gray-300">{{ label }}</label>
    <label
      class="flex cursor-pointer items-center justify-between gap-3 rounded-xl border border-white/10 bg-white/5 px-4 py-3 hover:bg-white/10 transition"
    >
      <input class="hidden" type="file" :accept="accept" @change="onSelect">
      <span class="flex min-w-0 items-center gap-2 text-sm text-gray-300">
        <Icon name="mdi:folder-zip-outline" class="text-xl text-classic-gold shrink-0" />
        <span class="truncate">{{ fileName || placeholder }}</span>
      </span>
      <Icon name="mdi:upload" class="text-gray-500 shrink-0" />
    </label>
  </div>
</template>

<script setup lang="ts">
withDefaults(defineProps<{
  fileName?: string
  label?: string
  placeholder?: string
  accept?: string
}>(), {
  fileName: '',
  label: 'فایل پروژه',
  placeholder: 'انتخاب فایل ZIP، RAR، TAR.GZ یا PDF',
  accept: '.zip,.rar,.tar.gz,.pdf',
})

const emit = defineEmits<{ select: [file: File] }>()

const onSelect = (event: Event) => {
  const file = (event.target as HTMLInputElement).files?.[0]
  if (file) emit('select', file)
}
</script>
